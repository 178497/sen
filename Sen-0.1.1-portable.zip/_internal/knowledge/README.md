# 个人知识库目录

把需要检索的 `.md`、`.txt` 或 `.rst` 文件放在这里。根目录下的这份 `README.md` 不会被索引。

建议按主题拆分文件，例如：

```text
knowledge/
  项目说明.md
  常见问题.md
  个人资料.txt
```

修改文件后，在项目目录运行：

```powershell
python .\rag.py index
```

也可以在聊天服务启动后调用重建接口：

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/api/reindex
```

不要放入密钥、密码或身份令牌。虽然模型在本机运行，但知识内容仍可能出现在模型上下文中。
