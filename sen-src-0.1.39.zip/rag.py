"""A dependency-free BM25 retriever optimized for small local knowledge bases."""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


DEFAULT_INDEX = Path("data/knowledge_index.json")
TEXT_SUFFIXES = {".md", ".txt", ".rst"}
TOKEN_PATTERN = re.compile(r"[A-Za-z0-9_./:+#-]+|[\u4e00-\u9fff]+")


def tokenize(text: str) -> list[str]:
    """Tokenize Chinese into overlapping bigrams and keep code terms whole."""
    tokens: list[str] = []
    for match in TOKEN_PATTERN.finditer(text.lower()):
        piece = match.group(0)
        if re.fullmatch(r"[\u4e00-\u9fff]+", piece):
            if len(piece) == 1:
                tokens.append(piece)
            else:
                tokens.extend(piece[index : index + 2] for index in range(len(piece) - 1))
        else:
            tokens.append(piece)
    return tokens


def split_into_chunks(
    text: str,
    chunk_size: int = 320,
    overlap: int = 40,
) -> list[str]:
    paragraphs = [
        paragraph.strip()
        for paragraph in re.split(r"\n\s*\n", text)
        if paragraph.strip()
    ]
    chunks: list[str] = []
    current = ""

    for paragraph in paragraphs:
        if len(current) + len(paragraph) + 2 <= chunk_size:
            current = f"{current}\n\n{paragraph}".strip()
            continue

        if current:
            chunks.append(current)

        if len(paragraph) <= chunk_size:
            current = paragraph
            continue

        start = 0
        while start < len(paragraph):
            end = min(len(paragraph), start + chunk_size)
            chunks.append(paragraph[start:end].strip())
            if end == len(paragraph):
                current = ""
                break
            start = max(start + 1, end - overlap)
        current = ""

    if current:
        chunks.append(current)
    return [chunk for chunk in chunks if chunk]


@dataclass
class SearchResult:
    source: str
    text: str
    score: float


class BM25Index:
    def __init__(self, data: dict) -> None:
        self.data = data
        self.chunks = data["chunks"]
        self.document_tokens = [tokenize(chunk["text"]) for chunk in self.chunks]
        self.term_frequencies = [Counter(tokens) for tokens in self.document_tokens]
        self.document_frequencies = Counter(
            term
            for frequencies in self.term_frequencies
            for term in frequencies
        )
        self.average_length = (
            sum(len(tokens) for tokens in self.document_tokens)
            / max(1, len(self.document_tokens))
        )

    @classmethod
    def load(cls, path: Path = DEFAULT_INDEX) -> "BM25Index":
        if not path.exists():
            return cls({"chunks": [], "files": []})
        return cls(json.loads(path.read_text(encoding="utf-8")))

    def search(
        self,
        query: str,
        top_k: int = 2,
        max_total_chars: int = 900,
        k1: float = 1.5,
        b: float = 0.75,
    ) -> list[SearchResult]:
        query_tokens = set(tokenize(query))
        if not query_tokens or not self.chunks:
            return []

        scored: list[tuple[float, int]] = []
        chunk_count = len(self.chunks)
        for index, frequencies in enumerate(self.term_frequencies):
            document_length = len(self.document_tokens[index])
            score = 0.0
            for term in query_tokens:
                frequency = frequencies.get(term, 0)
                if frequency == 0:
                    continue
                document_frequency = self.document_frequencies[term]
                inverse_document_frequency = math.log(
                    1.0 + (chunk_count - document_frequency + 0.5)
                    / (document_frequency + 0.5)
                )
                length_normalization = 1.0 - b + b * document_length / max(
                    1.0, self.average_length
                )
                score += inverse_document_frequency * (
                    frequency * (k1 + 1.0)
                    / (frequency + k1 * length_normalization)
                )
            if score > 0:
                scored.append((score, index))

        scored.sort(reverse=True)
        results: list[SearchResult] = []
        used_chars = 0
        for score, index in scored:
            chunk = self.chunks[index]
            remaining = max_total_chars - used_chars
            if remaining <= 0 or len(results) >= top_k:
                break
            text = chunk["text"][:remaining].strip()
            if not text:
                continue
            results.append(
                SearchResult(
                    source=chunk["source"],
                    text=text,
                    score=score,
                )
            )
            used_chars += len(text)
        return results


def iter_source_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        if path.name.lower() == "readme.md" and path.parent == root:
            continue
        yield path


def build_index(
    knowledge_dir: Path,
    index_path: Path = DEFAULT_INDEX,
    chunk_size: int = 320,
    overlap: int = 40,
) -> dict:
    if not knowledge_dir.exists():
        knowledge_dir.mkdir(parents=True, exist_ok=True)

    files: list[str] = []
    chunks: list[dict[str, str]] = []
    for path in iter_source_files(knowledge_dir):
        relative_path = path.relative_to(knowledge_dir).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        for chunk in split_into_chunks(text, chunk_size, overlap):
            chunks.append({"source": relative_path, "text": chunk})
        files.append(relative_path)

    data = {
        "version": 1,
        "chunk_size": chunk_size,
        "overlap": overlap,
        "files": files,
        "chunks": chunks,
    }
    index_path.parent.mkdir(parents=True, exist_ok=True)
    index_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description="Index or search local documents.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    index_parser = subparsers.add_parser("index", help="Rebuild the BM25 index.")
    index_parser.add_argument("--knowledge", type=Path, default=Path("knowledge"))
    index_parser.add_argument("--index", type=Path, default=DEFAULT_INDEX)

    search_parser = subparsers.add_parser("search", help="Test a query.")
    search_parser.add_argument("query")
    search_parser.add_argument("--index", type=Path, default=DEFAULT_INDEX)
    search_parser.add_argument("--top-k", type=int, default=3)

    args = parser.parse_args()
    if args.command == "index":
        data = build_index(args.knowledge, args.index)
        print(
            f"Indexed {len(data['chunks'])} chunks from "
            f"{len(data['files'])} files into {args.index}"
        )
        return

    results = BM25Index.load(args.index).search(args.query, args.top_k)
    if not results:
        print("No matching context.")
        return
    for index, result in enumerate(results, start=1):
        print(f"[{index}] {result.source} | score={result.score:.3f}")
        print(result.text)
        print()


if __name__ == "__main__":
    main()
