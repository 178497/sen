"""平台差异集中在这里。

Windows 用 win32 / PowerShell，macOS 用 AppKit / open / bash。
目前 macOS 分支只写了实现，尚未在真机上验证。
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

IS_WINDOWS = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


# ---------------------------------------------------------------- 进程与路径
def venv_python(venv_root: Path) -> Path:
    """虚拟环境里的解释器位置：Windows 是 Scripts/python.exe，类 Unix 是 bin/python。"""
    if IS_WINDOWS:
        return venv_root / "Scripts" / "python.exe"
    return venv_root / "bin" / "python"


def hidden_flags() -> int:
    """启动子进程时不弹黑窗（只有 Windows 需要）。"""
    return 0x08000000 if IS_WINDOWS else 0


def open_path(path: Path) -> None:
    """用系统默认方式打开文件或目录。"""
    target = str(path)
    if IS_WINDOWS:
        os.startfile(target)  # type: ignore[attr-defined]
    elif IS_MAC:
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])


def open_path_supported() -> bool:
    return IS_WINDOWS or IS_MAC or IS_LINUX


# ---------------------------------------------------------------- 窗口
def set_app_user_model_id(app_id: str) -> None:
    """Windows 任务栏图标分组用；其他平台无需处理。"""
    if not IS_WINDOWS:
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)  # type: ignore[attr-defined]
    except Exception:
        pass


def set_window_icon(window: object, icon_path: Path) -> None:
    """Windows 用 WinForms 的 Icon，macOS 由 .app 的 Info.plist 决定。"""
    if not IS_WINDOWS:
        return
    try:
        import System.Drawing

        window.native.Icon = System.Drawing.Icon(str(icon_path))  # type: ignore[attr-defined]
    except Exception:
        pass


def work_area_size() -> tuple[int, int]:
    """可用桌面尺寸（逻辑像素）。"""
    if IS_WINDOWS:
        try:
            import ctypes
            from ctypes import wintypes

            rect = wintypes.RECT()
            if not ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0):
                raise OSError("SystemParametersInfoW failed")
            width = max(900, rect.right - rect.left)
            height = max(640, rect.bottom - rect.top)
            return width, height
        except Exception:
            return 1280, 860
    if IS_MAC:
        try:
            from AppKit import NSScreen  # type: ignore[import-not-found]

            frame = NSScreen.mainScreen().visibleFrame()
            width = int(frame.size.width)
            height = int(frame.size.height)
            return max(900, width), max(640, height)
        except Exception:
            return 1280, 860
    return 1280, 860


# ---------------------------------------------------------------- 训练
def training_script(base_dir: Path) -> Path:
    if IS_WINDOWS:
        return base_dir / "train.ps1"
    return base_dir / "train.sh"


def training_command(script: Path, arguments: list[str]) -> list[str]:
    """把脚本和参数包成可执行的命令行。"""
    if IS_WINDOWS:
        return [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
            *arguments,
        ]
    return ["/bin/bash", str(script), *arguments]


def setup_script(base_dir: Path) -> Path:
    if IS_WINDOWS:
        return base_dir / "setup_train.ps1"
    return base_dir / "setup_train.sh"


def setup_command(script: Path) -> list[str]:
    return training_command(script, [])


def adapter_python_flags() -> list[str]:
    """训练脚本在无 CUDA 机器上的附加参数（macOS 走 MPS）。"""
    return [] if IS_WINDOWS else ["--device", "mps", "--no-4bit"]


# ---------------------------------------------------------------- 运行时安装
def uv_binary_name() -> str:
    return "uv.exe" if IS_WINDOWS else "uv"


def uv_cache_dir() -> Path:
    if IS_WINDOWS:
        return Path(os.getenv("LOCALAPPDATA", "")) / "uv" / "cache"
    if IS_MAC:
        return Path.home() / "Library" / "Caches" / "uv"
    return Path.home() / ".cache" / "uv"


def uv_install_script_url() -> str:
    return "https://astral.sh/uv/install.sh"


def torch_index_args(cuda: bool) -> list[str]:
    """Windows 用镜像加速；macOS 直接用 PyPI 的 arm64 轮子（带 MPS 支持）。"""
    if IS_WINDOWS:
        index = (
            "https://mirrors.aliyun.com/pytorch-wheels/cu124"
            if cuda
            else "https://mirrors.aliyun.com/pytorch-wheels/cpu"
        )
        return ["--index-url", index]
    return []


# ---------------------------------------------------------------- 更新
def installer_suffix() -> str:
    return ".exe" if IS_WINDOWS else ".dmg"
