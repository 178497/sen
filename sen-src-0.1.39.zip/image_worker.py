"""Persistent local text-to-image worker (JSON lines over stdin/stdout)."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Local diffusion worker")
    parser.add_argument("--model", default="stabilityai/sd-turbo")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--local-files-only", action="store_true")
    args = parser.parse_args()

    import torch
    from diffusers import AutoPipelineForText2Image

    device = args.device
    if device == "cuda" and not torch.cuda.is_available():
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            device = "mps"
        else:
            device = "cpu"
    if device == "mps" and not (
        getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()
    ):
        device = "cpu"

    # 权重只有 fp16 一份：CUDA / MPS 直接用 fp16，CPU 上转 fp32（fp16 算子不支持）
    dtype = torch.float16 if device in {"cuda", "mps"} else torch.float32
    variant = "fp16"

    pipe = AutoPipelineForText2Image.from_pretrained(
        args.model,
        torch_dtype=dtype,
        variant=variant,
        local_files_only=args.local_files_only,
    )
    pipe = pipe.to(device)
    pipe.set_progress_bar_config(disable=True)
    try:
        pipe.enable_attention_slicing()
    except Exception:
        pass
    try:
        pipe.enable_vae_slicing()
    except Exception:
        pass

    print(json.dumps({"event": "ready", "model": args.model}), flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        started = time.perf_counter()
        try:
            request = json.loads(line)
            prompt = str(request["prompt"]).strip()
            steps = int(request.get("steps", 4))
            size = int(request.get("size", 512))
            target = Path(request["out"])
            if not prompt:
                raise ValueError("empty prompt")
            image = pipe(
                prompt=prompt,
                num_inference_steps=max(1, min(20, steps)),
                guidance_scale=0.0,
                width=size,
                height=size,
            ).images[0]
            target.parent.mkdir(parents=True, exist_ok=True)
            image.save(target)
            print(
                json.dumps(
                    {
                        "ok": True,
                        "path": str(target),
                        "ms": round((time.perf_counter() - started) * 1000),
                    }
                ),
                flush=True,
            )
        except Exception as error:  # noqa: BLE001 - reported to the caller
            print(json.dumps({"ok": False, "error": str(error)[:300]}), flush=True)


if __name__ == "__main__":
    main()
