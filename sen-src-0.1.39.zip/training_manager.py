"""Background training orchestration for the desktop application."""

from __future__ import annotations

import json
import hashlib
import html
import io
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path

import platform_layer
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


class TrainingManager:
    HF_ENDPOINT = os.getenv("HF_ENDPOINT", "https://hf-mirror.com").rstrip("/")
    ALLOWED_LICENSES = {
        "apache-2.0",
        "mit",
        "bsd-3-clause",
        "cc0-1.0",
        "cc-by-4.0",
        "cc-by-sa-4.0",
        "openrail",
        "bigscience-openrail-m",
        "odc-by",
    }

    def __init__(self, base_dir: Path, work_dir: Path | None = None) -> None:
        self.base_dir = base_dir
        # base_dir 放脚本（随包分发、只读），work_dir 放日志/数据/产物（可写）
        self.work_dir = Path(work_dir) if work_dir else base_dir
        self.work_dir.mkdir(parents=True, exist_ok=True)
        local_data = self.work_dir / "data" / "train.jsonl"
        online_data = self.work_dir / "data" / "online_train.jsonl"
        self.data_path = (
            local_data
            if local_data.exists()
            else online_data
            if online_data.exists()
            else local_data
        )
        self.adapter_dir = self.work_dir / "outputs" / "lora-adapter"
        import os as _os

        train_root = Path(_os.getenv("CHAT_VENV_TRAIN", str(base_dir / ".venv-train")))
        self.train_python = platform_layer.venv_python(train_root)
        base_python = (
            Path(os.getenv("LOCALAPPDATA", str(Path.home())))
            / "Programs"
            / "Python"
            / "Python313"
            / "python.exe"
        )
        self.desktop_python = (
            base_python
            if base_python.exists()
            else platform_layer.venv_python(base_dir / ".venv-desktop")
        )
        if platform_layer.IS_MAC:
            self.ollama_exe = Path("/usr/local/bin/ollama")
            for candidate in (
                Path("/opt/homebrew/bin/ollama"),
                Path("/Applications/Ollama.app/Contents/Resources/ollama"),
            ):
                if candidate.exists():
                    self.ollama_exe = candidate
                    break
        else:
            self.ollama_exe = (
                Path(os.getenv("LOCALAPPDATA", str(Path.home())))
                / "Programs"
                / "Ollama"
                / "ollama.exe"
            )
        self.log_path = self.work_dir / "training.log"
        self.pause_flag = self.work_dir / "data" / "training_pause.flag"
        self.throttle_file = self.work_dir / "data" / "training_throttle.txt"
        self._throttle = 80
        self.checkpoint_dir = self.adapter_dir / "checkpoints"
        self._pause_requested = False
        self.history_path = self.work_dir / "data" / "training_history.json"
        self._history_run_id = ""
        self._lock = threading.Lock()
        self._logs: list[str] = []
        self._process: subprocess.Popen[str] | None = None
        self._busy = False
        self._phase = "idle"
        self._last_error = ""
        self._started_at = 0.0
        self._epochs = 3
        self._diagnostics: dict[str, Any] | None = None
        self._progress: dict[str, Any] = {
            "stage": "idle",
            "step": 0,
            "total_steps": 0,
            "percent": 0.0,
            "loss": None,
            "elapsed_seconds": 0.0,
            "eta_seconds": 0.0,
        }

    @property
    def busy(self) -> bool:
        with self._lock:
            return self._busy

    def append_log(self, text: str) -> None:
        clean = text.rstrip()
        if not clean:
            return
        with self._lock:
            self._logs.extend(clean.splitlines() or [""])
            self._logs = self._logs[-2_000:]
        try:
            with self.log_path.open("a", encoding="utf-8") as file:
                file.write(clean + "\n")
        except OSError:
            pass

    def _history_load(self) -> list[dict[str, Any]]:
        try:
            payload = json.loads(self.history_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        if not isinstance(payload, list):
            return []
        return [item for item in payload if isinstance(item, dict)]

    def _history_save(self, records: list[dict[str, Any]]) -> None:
        try:
            self.history_path.parent.mkdir(parents=True, exist_ok=True)
            trimmed = records[-80:]
            self.history_path.write_text(
                json.dumps(trimmed, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError:
            pass

    def _history_begin(self, epochs: int, kind: str = "train") -> None:
        count, _ = self.data_summary()
        record = {
            "id": time.strftime("%Y%m%d-%H%M%S"),
            "kind": kind,
            "started_at": time.time(),
            "finished_at": None,
            "status": "running",
            "epochs": int(epochs),
            "samples": int(count),
            "dataset": self.data_path.name,
            "duration_seconds": 0,
            "loss": None,
            "model": "qwen3-local",
            "error": "",
        }
        records = self._history_load()
        records.append(record)
        self._history_save(records)
        self._history_run_id = record["id"]

    def _history_finish(self, status: str, error: str = "") -> None:
        run_id = getattr(self, "_history_run_id", "")
        if not run_id:
            return
        records = self._history_load()
        now = time.time()
        for item in reversed(records):
            if item.get("id") == run_id and item.get("status") == "running":
                item["status"] = status
                item["finished_at"] = now
                item["duration_seconds"] = round(
                    now - float(item.get("started_at") or now), 1
                )
                item["loss"] = self._progress.get("loss")
                if error:
                    item["error"] = str(error)[:400]
                break
        self._history_save(records)
        self._history_run_id = ""

    def history(self, limit: int = 20) -> dict[str, Any]:
        records = self._history_load()
        changed = False
        now = time.time()
        for item in records:
            if item.get("status") != "running":
                continue
            if self._busy:
                continue
            started = float(item.get("started_at") or 0)
            if now - started > 120:
                item["status"] = "interrupted"
                item["finished_at"] = started + float(item.get("duration_seconds") or 0)
                changed = True
        if changed:
            self._history_save(records)
        ordered = sorted(
            records, key=lambda item: float(item.get("started_at") or 0), reverse=True
        )
        return {
            "records": ordered[: max(1, int(limit))],
            "total": len(ordered),
        }

    def set_phase(self, phase: str, error: str = "") -> None:
        with self._lock:
            self._phase = phase
            self._last_error = error
            self._progress["stage"] = phase
        if phase == "paused":
            self._history_finish("paused")
        if phase == "complete":
            self._history_finish("complete")
            self._clear_checkpoints()

    def update_progress(self, event: dict[str, Any]) -> None:
        with self._lock:
            for key in (
                "stage",
                "step",
                "total_steps",
                "percent",
                "loss",
                "elapsed_seconds",
                "eta_seconds",
            ):
                if key in event:
                    self._progress[key] = event[key]

    def data_summary(self) -> tuple[int, str]:
        if not self.data_path.exists():
            return 0, ""
        count = 0
        try:
            with self.data_path.open("r", encoding="utf-8") as file:
                for line_number, line in enumerate(file, start=1):
                    if not line.strip():
                        continue
                    value = json.loads(line)
                    messages = value.get("messages")
                    if not isinstance(messages, list) or not messages:
                        raise ValueError(
                            f"Line {line_number} has no messages array"
                        )
                    count += 1
        except Exception as error:
            return count, str(error)
        return count, ""

    def checkpoints(self) -> list[Path]:
        root = self.checkpoint_dir
        if not root.exists():
            return []
        found: list[tuple[int, Path]] = []
        for child in root.glob("checkpoint-*"):
            if not child.is_dir():
                continue
            try:
                step = int(child.name.rsplit("-", 1)[-1])
            except ValueError:
                continue
            found.append((step, child))
        found.sort(key=lambda item: item[0])
        return [path for _, path in found]

    @property
    def can_resume(self) -> bool:
        if self._busy:
            return False
        found = self.checkpoints()
        if not found:
            return False
        summary = self.adapter_dir / "training_summary.json"
        try:
            if summary.exists() and summary.stat().st_mtime >= found[-1].stat().st_mtime:
                return False
        except OSError:
            pass
        return True

    def _resume_epochs(self) -> int | None:
        for record in reversed(self._history_load()):
            if record.get("status") == "paused" and record.get("epochs"):
                try:
                    return int(record["epochs"])
                except (TypeError, ValueError):
                    continue
        return None

    def latest_checkpoint(self) -> str | None:
        found = self.checkpoints()
        return str(found[-1]) if found else None

    def latest_checkpoint_step(self) -> int:
        found = self.checkpoints()
        if not found:
            return 0
        try:
            return int(found[-1].name.rsplit("-", 1)[-1])
        except ValueError:
            return 0

    def _clear_checkpoints(self) -> None:
        shutil.rmtree(self.checkpoint_dir, ignore_errors=True)

    def set_throttle(self, value: int) -> dict[str, Any]:
        throttle = max(10, min(100, int(value)))
        self._throttle = throttle
        try:
            self.throttle_file.parent.mkdir(parents=True, exist_ok=True)
            self.throttle_file.write_text(str(throttle), encoding="utf-8")
        except OSError:
            pass
        if self._busy:
            self.append_log(f"性能占用已调整为 {throttle}%（下一步生效）。")
        return self.status()

    def pause(self) -> dict[str, Any]:
        if not self._busy:
            raise RuntimeError("当前没有正在进行的训练")
        try:
            self.pause_flag.parent.mkdir(parents=True, exist_ok=True)
            self.pause_flag.write_text(str(time.time()), encoding="utf-8")
        except OSError as error:
            raise RuntimeError(f"无法写入暂停标记：{error}") from error
        self._pause_requested = True
        self.append_log("已请求暂停：当前 step 结束后保存检查点并停止。")
        return self.status()

    def status(self) -> dict[str, Any]:
        count, error = self.data_summary()
        with self._lock:
            elapsed = (
                round(time.time() - self._started_at, 1)
                if self._busy and self._started_at
                else 0
            )
            return {
                "busy": self._busy,
                "phase": self._phase,
                "last_error": self._last_error,
                "data_path": str(self.data_path),
                "data_count": count,
                "data_error": error,
                "env_ready": self.train_python.exists(),
                "adapter_ready": (
                    self.adapter_dir / "adapter_config.json"
                ).exists(),
                "elapsed_seconds": elapsed,
                "progress": dict(self._progress),
                "diagnostics": self._diagnostics,
                "can_resume": self.can_resume,
                "resume_step": self.latest_checkpoint_step() if self.can_resume else 0,
                "pause_requested": self._pause_requested,
                "throttle": self._throttle,
            }

    def read_logs(self, cursor: int = 0) -> dict[str, Any]:
        with self._lock:
            start = max(0, min(cursor, len(self._logs)))
            lines = self._logs[start:]
            return {
                "lines": lines,
                "cursor": len(self._logs),
            }

    def diagnose_failure(self, error: Exception) -> dict[str, Any]:
        with self._lock:
            log_tail = "\n".join(self._logs[-120:])

        checks: list[dict[str, Any]] = []
        environment_ready = self.train_python.exists()
        checks.append(
            {
                "name": "训练环境",
                "ok": environment_ready,
                "detail": (
                    "Python 与训练依赖目录存在"
                    if environment_ready
                    else "训练虚拟环境不存在"
                ),
            }
        )

        count, data_error = self.data_summary()
        checks.append(
            {
                "name": "训练数据",
                "ok": count > 0 and not data_error,
                "detail": (
                    f"{count} 条可用样本"
                    if count > 0 and not data_error
                    else data_error or "没有训练样本"
                ),
            }
        )

        adapter_ready = (self.adapter_dir / "adapter_config.json").exists()
        checks.append(
            {
                "name": "LoRA 适配器",
                "ok": adapter_ready,
                "detail": (
                    "适配器文件已经生成"
                    if adapter_ready
                    else "没有找到完整的适配器文件"
                ),
            }
        )

        try:
            free_gb = shutil.disk_usage(self.work_dir).free / 1024**3
            checks.append(
                {
                    "name": "磁盘空间",
                    "ok": free_gb >= 3,
                    "detail": f"D 盘剩余 {free_gb:.1f} GiB",
                }
            )
        except OSError as disk_error:
            checks.append(
                {
                    "name": "磁盘空间",
                    "ok": False,
                    "detail": str(disk_error),
                }
            )

        gpu_ok = False
        gpu_detail = "未执行 GPU 检查"
        if environment_ready:
            try:
                result = subprocess.run(
                    [str(self.train_python), str(self.base_dir / "check_env.py")],
                    cwd=self.base_dir,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=45,
                    creationflags=(
                        subprocess.CREATE_NO_WINDOW
                        if os.name == "nt"
                        else 0
                    ),
                )
                gpu_ok = (
                    result.returncode == 0
                    and "CUDA available: True" in result.stdout
                )
                gpu_detail = next(
                    (
                        line
                        for line in result.stdout.splitlines()
                        if line.startswith(("GPU:", "PyTorch:"))
                    ),
                    "CUDA 检查未通过",
                )
            except Exception as gpu_error:
                gpu_detail = str(gpu_error)
        checks.append(
            {
                "name": "CUDA / GPU",
                "ok": gpu_ok,
                "detail": gpu_detail,
            }
        )

        combined = f"{error}\n{log_tail}".lower()
        if "out of memory" in combined or "cuda oom" in combined:
            reason = "显存不足，训练过程中 GPU 内存溢出。"
            suggestions = [
                "将最大序列长度从 1024 降到 768 或 512。",
                "关闭占用显存的游戏、视频和其他模型。",
                "保持微批次为 1，并增加梯度累积步数。",
            ]
        elif (
            "handshake" in combined
            or "ssl" in combined
            or "connection" in combined
            or "timed out" in combined
            or "huggingface" in combined
        ):
            reason = "训练期间访问 Hugging Face 镜像时连接超时。"
            suggestions = [
                "检查网络连接，稍后从现有检查点重试。",
                "确认 HF_ENDPOINT 设置为 https://hf-mirror.com。",
                "避免同时进行大文件下载或在线视频。",
            ]
        elif "lora adapters are no longer supported" in combined:
            reason = "训练已完成，但当前 Ollama 不支持直接导入 LoRA。"
            suggestions = [
                "先合并 LoRA 与 Qwen3-1.7B 基础模型。",
                "把合并后的模型导入 Ollama，而不是直接导入适配器。",
                "无需重新训练，可以复用现有适配器。",
            ]
        elif "no space" in combined or "disk" in combined or "磁盘" in combined:
            reason = "磁盘空间不足，模型或检查点无法继续写入。"
            suggestions = [
                "确认 D 盘至少剩余 10 GiB。",
                "清理不用的旧检查点和临时模型。",
            ]
        elif "json" in combined or "messages" in combined:
            reason = "训练数据格式不正确。"
            suggestions = [
                "每行必须是合法 JSON。",
                "最后两条消息必须是用户问题和助手回答。",
                "修正数据或重新准备在线样本后重试。",
            ]
        elif "bitsandbytes" in combined or "4-bit" in combined or "4bit" in combined:
            reason = "4-bit 量化训练组件初始化失败。"
            suggestions = [
                "运行环境检查，确认 CUDA PyTorch 与 bitsandbytes 正常。",
                "关闭其他 GPU 程序后重试。",
            ]
        elif "mlx runtime" in combined:
            reason = (
                "Ollama 在 Windows 上错误地尝试使用 MLX 运行时，"
                "因此无法直接导入 Safetensors 模型。"
            )
            suggestions = [
                "使用 GGUF 格式导入合并后的模型。",
                "重新点击“导入已有适配器”让森自动转换 GGUF。",
                "训练适配器和合并模型都已保留，不需要重新训练。",
            ]
        elif "gguf conversion failed" in combined:
            reason = "合并模型转换为 GGUF 时失败。"
            suggestions = [
                "确认 GGUF 转换器和 gguf 依赖下载成功。",
                "检查 outputs/merged-model 目录是否完整。",
                "重新点击“导入已有适配器”再次尝试。",
            ]
        elif "conversion.py" in combined or "converter modules" in combined:
            reason = "无法获得完整的 llama.cpp 转换器组件。"
            suggestions = [
                "检查网络是否可以访问 GitHub 或 Hugging Face 镜像。",
                "重新点击“导入已有适配器”会自动重试多个下载源。",
                "合并模型已经保留，不需要重新训练。",
            ]
        elif "ollama import failed" in combined or "import failed" in combined:
            reason = "合并后的模型无法导入当前 Ollama。"
            suggestions = [
                "确认 Ollama 正在运行且版本支持 Safetensors 导入。",
                "若仍不支持，将合并模型转换为 GGUF Q4_K_M 后导入。",
                "训练适配器已经保留，不需要重新训练。",
            ]
        else:
            reason = str(error) or "训练在未分类阶段中止。"
            suggestions = [
                "查看技术详情中的最后一段堆栈。",
                "检查数据、显存和 Ollama 服务。",
            ]

        return {
            "reason": reason,
            "checks": checks,
            "suggestions": suggestions,
            "technical_details": log_tail[-8_000:],
        }

    def set_failure(self, error: Exception) -> None:
        diagnostic = self.diagnose_failure(error)
        with self._lock:
            self._phase = "failed"
            self._last_error = str(error)
            self._diagnostics = diagnostic
            self._progress["stage"] = "failed"
        self._history_finish("failed", str(error))
        self.append_log(f"[error] {error}")

    def choose_data(self, path: str) -> None:
        candidate = Path(path).expanduser().resolve()
        self.data_path = candidate

    def ensure_dataset_template(self) -> Path:
        example = self.base_dir / "data" / "train.example.jsonl"
        if not self.data_path.exists():
            self.data_path.parent.mkdir(parents=True, exist_ok=True)
            self.data_path.write_bytes(example.read_bytes())
        return self.data_path

    def _request_json(self, url: str, timeout: float = 20.0) -> Any:
        request = Request(
            url,
            headers={"User-Agent": "Sen-Local-Assistant/1.0"},
        )
        with urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))

    def _dataset_detail(self, repo_id: str) -> dict[str, Any]:
        return self._request_json(
            f"{self.HF_ENDPOINT}/api/datasets/{quote(repo_id, safe='/')}"
        )

    @staticmethod
    def _dataset_license(detail: dict[str, Any]) -> str:
        card = detail.get("cardData") or {}
        license_name = card.get("license")
        if isinstance(license_name, list):
            license_name = license_name[0] if license_name else ""
        if not license_name:
            for tag in detail.get("tags") or []:
                if isinstance(tag, str) and tag.startswith("license:"):
                    license_name = tag.split(":", 1)[1]
                    break
        return str(license_name or "").strip().lower()

    def search_datasets(self, query: str, limit: int = 8) -> list[dict[str, Any]]:
        query = query.strip()
        if not query:
            raise ValueError("Search keywords cannot be empty")
        if re.search(r"[\u4e00-\u9fff]", query):
            if re.search(r"编程|代码|程序|开发", query):
                query = "chinese code programming instruction"
            elif re.search(r"数学", query):
                query = "chinese math instruction"
            elif re.search(r"医疗|医学", query):
                query = "chinese medical instruction"
            elif re.search(r"客服", query):
                query = "chinese customer service instruction"
            elif re.search(r"翻译", query):
                query = "chinese translation instruction"
            else:
                query = "chinese instruction"
        search_url = (
            f"{self.HF_ENDPOINT}/api/datasets?"
            f"search={quote(query)}&limit=24"
        )
        candidates = self._request_json(search_url)
        if not isinstance(candidates, list):
            raise RuntimeError("Unexpected dataset search response")

        results: list[dict[str, Any]] = []
        for item in candidates:
            repo_id = str(item.get("id", ""))
            if (
                not repo_id
                or item.get("private")
                or item.get("gated")
                or item.get("disabled")
            ):
                continue
            try:
                detail = self._dataset_detail(repo_id)
            except (HTTPError, URLError, TimeoutError, ValueError):
                continue
            license_name = self._dataset_license(detail)
            if license_name not in self.ALLOWED_LICENSES:
                continue
            files = [
                sibling.get("rfilename", "")
                for sibling in detail.get("siblings", [])
                if sibling.get("rfilename", "").lower().endswith(".jsonl")
                and "readme" not in sibling.get("rfilename", "").lower()
            ]
            if not files:
                continue
            language_zh = any(
                str(tag).lower() in {"language:zh", "language:zh-cn"}
                for tag in (detail.get("tags") or [])
            )
            results.append(
                {
                    "id": repo_id,
                    "license": license_name,
                    "language_zh": language_zh,
                    "downloads": int(item.get("downloads") or 0),
                    "likes": int(item.get("likes") or 0),
                    "files": files[:5],
                }
            )

        results.sort(
            key=lambda item: (
                item["language_zh"],
                item["likes"],
                item["downloads"],
            ),
            reverse=True,
        )
        return results[:limit]

    @staticmethod
    def _clean_text(value: Any) -> str:
        if not isinstance(value, str):
            return ""
        value = html.unescape(re.sub(r"<[^>]+>", " ", value))
        value = re.sub(r"\s+", " ", value).strip()
        return value

    def _normalize_record(self, record: dict[str, Any]) -> list[dict[str, str]] | None:
        messages = record.get("messages")
        if isinstance(messages, list):
            normalized = []
            for message in messages:
                if not isinstance(message, dict):
                    continue
                role = message.get("role")
                content = self._clean_text(message.get("content"))
                if role in {"system", "user", "assistant"} and content:
                    normalized.append({"role": role, "content": content})
            if (
                len(normalized) >= 2
                and normalized[-2]["role"] == "user"
                and normalized[-1]["role"] == "assistant"
            ):
                return normalized

        conversations = record.get("conversations")
        if isinstance(conversations, list):
            normalized = []
            for message in conversations:
                if not isinstance(message, dict):
                    continue
                role = message.get("role") or message.get("from")
                content = self._clean_text(
                    message.get("content") or message.get("value")
                )
                role = "assistant" if role in {"assistant", "gpt", "bot"} else "user"
                if content:
                    normalized.append({"role": role, "content": content})
            if (
                len(normalized) >= 2
                and normalized[-2]["role"] == "user"
                and normalized[-1]["role"] == "assistant"
            ):
                return normalized

        instruction = self._clean_text(record.get("instruction"))
        context = self._clean_text(record.get("input"))
        answer = self._clean_text(
            record.get("output") or record.get("response") or record.get("answer")
        )
        question = self._clean_text(
            record.get("question") or record.get("prompt")
        )
        if question and answer:
            return [
                {"role": "user", "content": question},
                {"role": "assistant", "content": answer},
            ]
        if context and answer and not instruction:
            return [
                {"role": "user", "content": context},
                {"role": "assistant", "content": answer},
            ]
        if instruction and answer:
            user_content = (
                f"{instruction}\n\n{context}"
                if context
                else instruction
            )
            return [
                {"role": "user", "content": user_content},
                {"role": "assistant", "content": answer},
            ]
        return None

    def start_online_dataset(
        self,
        repo_id: str,
        max_samples: int = 1000,
    ) -> dict[str, Any]:
        repo_id = repo_id.strip()
        max_samples = max(20, min(int(max_samples), 20_000))
        if not repo_id:
            raise ValueError("Dataset ID cannot be empty")
        with self._lock:
            if self._busy:
                raise RuntimeError("A dataset or training task is already running")
            self._busy = True
            self._phase = "preparing_dataset"
            self._last_error = ""
            self._started_at = time.time()
            self._logs = []
            self._diagnostics = None
            self._progress = {
                "stage": "preparing_dataset",
                "step": 0,
                "total_steps": 0,
                "percent": 0.0,
                "loss": None,
                "elapsed_seconds": 0.0,
                "eta_seconds": 0.0,
            }
        thread = threading.Thread(
            target=self._run_online_dataset,
            args=(repo_id, max_samples),
            daemon=True,
        )
        thread.start()
        return self.status()

    def _run_online_dataset(self, repo_id: str, max_samples: int) -> None:
        try:
            detail = self._dataset_detail(repo_id)
            license_name = self._dataset_license(detail)
            if license_name not in self.ALLOWED_LICENSES:
                raise RuntimeError(
                    f"Dataset license is not allowed: {license_name or 'unknown'}"
                )
            files = [
                sibling.get("rfilename", "")
                for sibling in detail.get("siblings", [])
                if sibling.get("rfilename", "").lower().endswith(".jsonl")
                and "readme" not in sibling.get("rfilename", "").lower()
            ]
            if not files:
                raise RuntimeError("Dataset has no downloadable JSONL files")

            output_path = self.work_dir / "data" / "online_train.jsonl"
            output_path.parent.mkdir(parents=True, exist_ok=True)
            temporary_path = output_path.with_suffix(".jsonl.tmp")
            seen: set[str] = set()
            written = 0
            skipped = 0
            pii_pattern = re.compile(
                r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|(?<!\d)1[3-9]\d{9}(?!\d)"
            )

            with temporary_path.open("w", encoding="utf-8") as output:
                for filename in files:
                    if written >= max_samples:
                        break
                    file_url = (
                        f"{self.HF_ENDPOINT}/datasets/{quote(repo_id, safe='/')}"
                        f"/resolve/main/{quote(filename, safe='/')}"
                    )
                    self.append_log(f"Downloading {repo_id}/{filename}")
                    request = Request(
                        file_url,
                        headers={"User-Agent": "Sen-Local-Assistant/1.0"},
                    )
                    with urlopen(request, timeout=90) as response:
                        import io

                        for raw_line in io.TextIOWrapper(
                            response,
                            encoding="utf-8",
                            errors="replace",
                        ):
                            if written >= max_samples:
                                break
                            try:
                                record = json.loads(raw_line)
                            except json.JSONDecodeError:
                                skipped += 1
                                continue
                            if not isinstance(record, dict):
                                skipped += 1
                                continue
                            messages = self._normalize_record(record)
                            if not messages:
                                skipped += 1
                                continue
                            joined = "\n".join(
                                message["content"] for message in messages
                            )
                            chinese_count = len(
                                re.findall(r"[\u4e00-\u9fff]", joined)
                            )
                            if (
                                chinese_count < 8
                                or re.search(r"[\u3040-\u30ff]", joined)
                                or len(joined) < 20
                                or len(joined) > 12_000
                                or pii_pattern.search(joined)
                            ):
                                skipped += 1
                                continue
                            digest = hashlib.sha256(joined.encode("utf-8")).hexdigest()
                            if digest in seen:
                                skipped += 1
                                continue
                            seen.add(digest)
                            output.write(
                                json.dumps(
                                    {
                                        "messages": messages,
                                        "source": repo_id,
                                        "license": license_name,
                                    },
                                    ensure_ascii=False,
                                )
                                + "\n"
                            )
                            written += 1
                            if written % 100 == 0:
                                self.append_log(f"Prepared {written} samples")

            if written == 0:
                temporary_path.unlink(missing_ok=True)
                raise RuntimeError("No usable samples were extracted")
            if written < 20:
                temporary_path.unlink(missing_ok=True)
                raise RuntimeError(
                    f"Only {written} usable Chinese samples were found; "
                    "at least 20 are required"
                )
            os.replace(temporary_path, output_path)
            self.data_path = output_path
            metadata = {
                "source": repo_id,
                "license": license_name,
                "files": files,
                "samples": written,
                "skipped": skipped,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "endpoint": self.HF_ENDPOINT,
            }
            (self.work_dir / "data" / "online_source.json").write_text(
                json.dumps(metadata, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            self.append_log(
                f"Dataset ready: {written} samples from {repo_id} "
                f"({license_name}), skipped {skipped}."
            )
            self.set_phase("dataset_ready")
        except Exception as error:
            self.set_failure(error)
        finally:
            with self._lock:
                self._busy = False
                self._process = None

    def run_command(
        self,
        command: list[str],
        extra_env: dict[str, str] | None = None,
    ) -> int:
        self.append_log("$ " + " ".join(command))
        environment = os.environ.copy()
        environment["PYTHONUNBUFFERED"] = "1"
        environment["PYTHONUTF8"] = "1"
        environment["PYTHONIOENCODING"] = "utf-8"
        environment.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
        if extra_env:
            environment.update(extra_env)
        creation_flags = (
            subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        process = subprocess.Popen(
            command,
            cwd=self.base_dir,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
        )
        with self._lock:
            self._process = process
        assert process.stdout is not None
        for line in process.stdout:
            clean_line = line.rstrip()
            marker_index = clean_line.rfind("SEN_EVENT ")
            if marker_index >= 0:
                try:
                    payload = clean_line[
                        marker_index + len("SEN_EVENT ") :
                    ]
                    event, _ = json.JSONDecoder().raw_decode(payload.lstrip())
                except (json.JSONDecodeError, ValueError):
                    self.append_log(clean_line)
                    continue
                self.update_progress(event)
                step = event.get("step", 0)
                total = event.get("total_steps", 0)
                loss = event.get("loss")
                loss_text = (
                    f" | loss {float(loss):.4f}"
                    if isinstance(loss, (int, float))
                    else ""
                )
                self.append_log(
                    f"Training progress: {step}/{total}{loss_text}"
                )
            else:
                self.append_log(clean_line)
        return process.wait()

    def start(
        self,
        data_path: str,
        epochs: int,
        resume: bool = False,
        throttle: int | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            if self._busy:
                raise RuntimeError("Training is already running")
            self._busy = True
            self._phase = "preparing"
            self._last_error = ""
            self._started_at = time.time()
            self._logs = []
            self._diagnostics = None
            self._progress = {
                "stage": "preparing",
                "step": 0,
                "total_steps": 0,
                "percent": 0.0,
                "loss": None,
                "elapsed_seconds": 0.0,
                "eta_seconds": 0.0,
            }
        checkpoint: str | None = None
        try:
            self.choose_data(data_path)
            if epochs < 1 or epochs > 10:
                raise ValueError("Epochs must be between 1 and 10")
            self._epochs = epochs
            count, error = self.data_summary()
            if count == 0:
                raise ValueError(error or "Training data is empty")
            if resume:
                if not self.can_resume:
                    raise RuntimeError("没有可继续的训练检查点")
                checkpoint = self.latest_checkpoint()
                if checkpoint is None:
                    raise RuntimeError("没有可继续的训练检查点")
                resumed_epochs = self._resume_epochs()
                if resumed_epochs:
                    epochs = resumed_epochs
                    self._epochs = resumed_epochs
            else:
                self._clear_checkpoints()
        except Exception:
            with self._lock:
                self._busy = False
                self._phase = "failed"
            raise

        try:
            if self.pause_flag.exists():
                self.pause_flag.unlink()
        except OSError:
            pass
        self._pause_requested = False
        if throttle is not None:
            self.set_throttle(throttle)
        else:
            try:
                self.throttle_file.parent.mkdir(parents=True, exist_ok=True)
                self.throttle_file.write_text(str(self._throttle), encoding="utf-8")
            except OSError:
                pass
        self._history_begin(epochs, "resume" if checkpoint else "train")
        thread = threading.Thread(
            target=self._run,
            args=(checkpoint,),
            daemon=True,
        )
        thread.start()
        return self.status()

    def import_existing_adapter(self) -> dict[str, Any]:
        with self._lock:
            if self._busy:
                raise RuntimeError("A training task is already running")
            self._busy = True
            self._phase = "preparing_import"
            self._last_error = ""
            self._started_at = time.time()
            self._logs = []
            self._diagnostics = None
            self._progress = {
                "stage": "preparing_import",
                "step": 0,
                "total_steps": 0,
                "percent": 0.0,
                "loss": None,
                "elapsed_seconds": 0.0,
                "eta_seconds": 0.0,
            }
        self._history_begin(self._epochs, "import")
        thread = threading.Thread(target=self._run_import_existing, daemon=True)
        thread.start()
        return self.status()

    def _run_import_existing(self) -> None:
        try:
            self._merge_and_import()
        except Exception as error:
            self.set_failure(error)
        finally:
            with self._lock:
                self._busy = False
                self._process = None

    def _ensure_gguf_converter(self) -> Path:
        tools_dir = self.work_dir / "tools"
        tools_dir.mkdir(parents=True, exist_ok=True)
        converter_path = tools_dir / "convert_hf_to_gguf.py"
        conversion_module_path = tools_dir / "conversion.py"

        if converter_path.exists():
            existing_converter = converter_path.read_bytes().lower()
            if (
                len(existing_converter) < 50_000
                or b"from conversion import" in existing_converter
            ):
                converter_path.unlink()

        if not converter_path.exists():
            urls = [
                "https://hf-mirror.com/ggml-org/llama.cpp/resolve/main/"
                "convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggml-org/llama.cpp/"
                "master/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "master/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b8000/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b7000/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b6500/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b6000/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b5800/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b5600/convert_hf_to_gguf.py",
                "https://raw.githubusercontent.com/ggerganov/llama.cpp/"
                "b5400/convert_hf_to_gguf.py",
            ]
            last_error: Exception | None = None
            for url in urls:
                try:
                    self.append_log(f"Downloading GGUF converter from {url}")
                    request = Request(
                        url,
                        headers={"User-Agent": "Sen-Local-Assistant/1.0"},
                    )
                    with urlopen(request, timeout=60) as response:
                        content = response.read()
                    lowered = content.lower()
                    if (
                        len(content) < 50_000
                        or b"<html" in lowered
                        or b"gguf" not in lowered
                        or b"class" not in lowered
                        or b"from conversion import" in lowered
                    ):
                        raise ValueError(
                            "Downloaded content is not a valid converter script"
                        )
                    converter_path.write_bytes(content)
                    break
                except Exception as download_error:
                    last_error = download_error
                    self.append_log(f"Converter source failed: {download_error}")
            else:
                raise RuntimeError(
                    f"Could not download GGUF converter: {last_error}"
                )

        converter_bytes = converter_path.read_bytes().lower()
        needs_conversion_module = b"from conversion import" in converter_bytes
        if needs_conversion_module and not conversion_module_path.exists():
            conversion_paths = [
                "tools/conversion.py",
                "convert_hf_to_gguf/conversion.py",
                "conversion/conversion.py",
                "conversion/__init__.py",
                "tools/convert_hf_to_gguf/conversion.py",
                "gguf-py/conversion.py",
                "converters/conversion.py",
            ]
            conversion_urls = [
                "https://raw.githubusercontent.com/ggml-org/llama.cpp/"
                f"master/{quote(path, safe='/')}"
                for path in conversion_paths
            ]
            last_error = None
            for url in conversion_urls:
                try:
                    self.append_log(f"Downloading GGUF conversion module from {url}")
                    request = Request(
                        url,
                        headers={"User-Agent": "Sen-Local-Assistant/1.0"},
                    )
                    with urlopen(request, timeout=15) as response:
                        content = response.read()
                    lowered = content.lower()
                    if (
                        len(content) < 10_000
                        or b"<html" in lowered
                        or b"class modelbase" not in lowered
                    ):
                        raise ValueError(
                            "Downloaded content is not a valid conversion module"
                        )
                    conversion_module_path.write_bytes(content)
                    break
                except Exception as download_error:
                    last_error = download_error
                    self.append_log(
                        f"Conversion module source failed: {download_error}"
                    )
            else:
                try:
                    tree_url = (
                        "https://api.github.com/repos/ggml-org/llama.cpp/"
                        "git/trees/master?recursive=1"
                    )
                    self.append_log("Locating conversion.py through GitHub API")
                    tree_data = self._request_json(tree_url, timeout=60)
                    conversion_paths = [
                        item["path"]
                        for item in tree_data.get("tree", [])
                        if item.get("path", "").endswith("/conversion.py")
                        or item.get("path", "") == "conversion.py"
                    ]
                    if not conversion_paths:
                        raise RuntimeError("conversion.py was not listed")
                    for relative_path in conversion_paths:
                        raw_url = (
                            "https://raw.githubusercontent.com/ggml-org/"
                            "llama.cpp/master/"
                            + quote(relative_path, safe="/")
                        )
                        self.append_log(
                            f"Downloading GGUF conversion module from {raw_url}"
                        )
                        request = Request(
                            raw_url,
                            headers={"User-Agent": "Sen-Local-Assistant/1.0"},
                        )
                        with urlopen(request, timeout=60) as response:
                            content = response.read()
                        if b"class modelbase" in content.lower():
                            conversion_module_path.write_bytes(content)
                            break
                    else:
                        raise RuntimeError(
                            "No valid conversion.py candidate was found"
                        )
                except Exception as discovery_error:
                    last_error = discovery_error
                    self.append_log(
                        f"GitHub module discovery failed: {discovery_error}"
                    )

            if not conversion_module_path.exists():
                archive_urls = [
                    "https://codeload.github.com/ggml-org/llama.cpp/"
                    "zip/refs/heads/master",
                    "https://github.com/ggml-org/llama.cpp/"
                    "archive/refs/heads/master.zip",
                ]
                source_dir = tools_dir / "llama.cpp-source"
                archive_success = False
                for url in archive_urls:
                    try:
                        self.append_log(
                            f"Downloading llama.cpp source archive from {url}"
                        )
                        request = Request(
                            url,
                            headers={"User-Agent": "Sen-Local-Assistant/1.0"},
                        )
                        with urlopen(request, timeout=120) as response:
                            archive_data = response.read()
                        if not archive_data.startswith(b"PK"):
                            raise ValueError(
                                "Downloaded source archive is not a ZIP file"
                            )
                        source_dir.mkdir(parents=True, exist_ok=True)
                        with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
                            for member in archive.namelist():
                                if not member.endswith(".py"):
                                    continue
                                parts = Path(member).parts
                                if not parts or ".." in parts:
                                    continue
                                relative = Path(*parts[1:])
                                target = source_dir / relative
                                target.parent.mkdir(parents=True, exist_ok=True)
                                target.write_bytes(archive.read(member))
                        conversion_candidates = list(
                            source_dir.rglob("conversion.py")
                        )
                        converter_candidates = list(
                            source_dir.rglob("convert_hf_to_gguf.py")
                        )
                        for converter in converter_candidates:
                            matching_conversion = converter.parent / "conversion.py"
                            if matching_conversion in conversion_candidates:
                                converter_path = converter
                                conversion_module_path = matching_conversion
                                archive_success = True
                                break
                        if archive_success:
                            break
                    except Exception as archive_error:
                        last_error = archive_error
                        self.append_log(
                            f"Source archive failed: {archive_error}"
                        )
                if not archive_success:
                    raise RuntimeError(
                        "Could not download llama.cpp converter modules: "
                        f"{last_error}"
                    )

        check = self.run_command(
            [str(self.train_python), "-c", "import gguf"]
        )
        if check != 0:
            install = self.run_command(
                [
                    str(self.train_python),
                    "-m",
                    "pip",
                    "install",
                    "--index-url",
                    "https://pypi.tuna.tsinghua.edu.cn/simple",
                    "gguf",
                ]
            )
            if install != 0:
                raise RuntimeError("Could not install the gguf conversion package")

        check_mistral = self.run_command(
            [str(self.train_python), "-c", "import mistral_common"]
        )
        if check_mistral != 0:
            install_mistral = self.run_command(
                [
                    str(self.train_python),
                    "-m",
                    "pip",
                    "install",
                    "--index-url",
                    "https://pypi.tuna.tsinghua.edu.cn/simple",
                    "mistral-common",
                ]
            )
            if install_mistral != 0:
                raise RuntimeError(
                    "Could not install the mistral-common conversion package"
                )
        return converter_path

    def _merge_and_import(self) -> None:
        self.set_phase("merging_model")
        if not (self.adapter_dir / "adapter_config.json").exists():
            raise RuntimeError("Adapter files were not created")
        merged_dir = self.work_dir / "outputs" / "merged-model"
        merged_weights = merged_dir / "model.safetensors"
        adapter_weights = self.adapter_dir / "adapter_model.safetensors"
        if (
            not merged_weights.exists()
            or merged_weights.stat().st_mtime
            < adapter_weights.stat().st_mtime
        ):
            code = self.run_command(
                [
                    str(self.train_python),
                    str(self.base_dir / "merge_adapter.py"),
                    "--adapter",
                    str(self.adapter_dir),
                    "--output",
                    str(merged_dir),
                ],
                extra_env={"HF_HUB_OFFLINE": "1"},
            )
            if code != 0:
                raise RuntimeError("LoRA merge failed")
        else:
            self.append_log("Existing merged model is up to date; skipping merge.")

        self.set_phase("converting_gguf")
        converter_path = self._ensure_gguf_converter()
        gguf_path = self.work_dir / "outputs" / "qwen3-local-f16.gguf"
        code = self.run_command(
            [
                str(self.train_python),
                str(converter_path),
                str(merged_dir),
                "--outfile",
                str(gguf_path),
                "--outtype",
                "f16",
            ],
            extra_env={
                "HF_HUB_OFFLINE": "1",
                "TRANSFORMERS_OFFLINE": "1",
            },
        )
        if code != 0 or not gguf_path.exists():
            raise RuntimeError("GGUF conversion failed")

        self.set_phase("importing_model")
        merged_modelfile = self.work_dir / "Modelfile.merged"
        merged_modelfile.write_text(
            "FROM ./outputs/qwen3-local-f16.gguf\n"
            "PARAMETER num_ctx 2048\n"
            "PARAMETER num_predict 256\n"
            "PARAMETER temperature 0.55\n"
            "PARAMETER top_p 0.9\n"
            "PARAMETER repeat_penalty 1.05\n",
            encoding="utf-8",
        )
        code = self.run_command(
            [
                str(self.ollama_exe),
                "create",
                "qwen3-local",
                "--quantize",
                "q4_K_M",
                "-f",
                str(merged_modelfile),
            ]
        )
        if code != 0:
            self.append_log(
                "Q4 quantization import failed; retrying with F16 GGUF."
            )
            code = self.run_command(
                [
                    str(self.ollama_exe),
                    "create",
                    "qwen3-local",
                    "-f",
                    str(merged_modelfile),
                ]
            )
        if code != 0:
            raise RuntimeError("Ollama import failed")

        # 跑 select_model.py 需要一个真正的解释器：
        # 打包后的 sys.executable 是 .app / .exe 本体，传脚本参数会重开应用。
        python = Path(sys.executable)
        for candidate in (self.desktop_python, self.train_python):
            if candidate and Path(candidate).exists():
                python = Path(candidate)
                break
        code = self.run_command(
            [
                str(python),
                str(self.base_dir / "select_model.py"),
                "qwen3-local",
            ]
        )
        if code != 0:
            raise RuntimeError("Model selection failed")
        self.set_phase("complete")
        self.append_log(
            "LoRA merged and imported. Restart Sen to use qwen3-local."
        )

    def _run(self, resume_from: str | None = None) -> None:
        try:
            if not self.train_python.exists():
                self.set_phase("installing_environment")
                code = self.run_command(
                    platform_layer.setup_command(
                        platform_layer.setup_script(self.base_dir)
                    )
                )
                if code != 0 or not self.train_python.exists():
                    raise RuntimeError("Training environment installation failed")

            self.set_phase("training")
            arguments = [
                "-Data",
                str(self.data_path),
                "-Epochs",
                str(self._epochs),
                "-PauseFile",
                str(self.pause_flag),
                "-SaveSteps",
                "50",
                "-Throttle",
                str(self._throttle),
                "-ThrottleFile",
                str(self.throttle_file),
                "-Output",
                str(self.adapter_dir),
            ]
            if resume_from:
                arguments.extend(["-ResumeFrom", resume_from])
            if resume_from:
                self.append_log(f"Resuming training from {resume_from}")
            command = platform_layer.training_command(
                platform_layer.training_script(self.base_dir), arguments
            )
            code = self.run_command(
                command,
                extra_env={"HF_HUB_OFFLINE": "1"},
            )
            if code != 0:
                raise RuntimeError("QLoRA training failed")

            if self._progress.get("stage") == "paused":
                self.set_phase("paused")
                self.append_log(
                    "训练已暂停，检查点已保存。可在训练舱点「继续上次训练」。"
                )
                return

            self._merge_and_import()
        except Exception as error:
            self.set_failure(error)
        finally:
            with self._lock:
                self._busy = False
                self._process = None
