"""Select the Ollama model used by the local desktop assistant."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def config_paths() -> list[Path]:
    """写入所有可能的配置位置，避免装完后读不到。"""
    paths: list[Path] = []
    env_path = os.getenv("CHAT_MODEL_CONFIG", "").strip()
    if env_path:
        paths.append(Path(env_path))
    if sys.platform == "darwin":
        paths.append(
            Path.home() / "Library" / "Application Support" / "Sen" / "model_config.json"
        )
    local = os.getenv("LOCALAPPDATA", "").strip()
    if local:
        paths.append(Path(local) / "Sen" / "model_config.json")
    paths.append(Path(__file__).resolve().parent / "model_config.json")
    unique: list[Path] = []
    for path in paths:
        if path not in unique:
            unique.append(path)
    return unique


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python select_model.py <ollama-model>")

    model = sys.argv[1].strip()
    if not model:
        raise SystemExit("Model name cannot be empty")

    payload = json.dumps({"model": model}, ensure_ascii=False, indent=2) + "\n"
    written = []
    for path in config_paths():
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(payload, encoding="utf-8")
            written.append(path)
        except OSError:
            continue
    if not written:
        raise SystemExit("Could not write model_config.json")

    print(f"Selected Ollama model: {model}")
    for path in written:
        print(f"  wrote {path}")
    print("Restart the desktop application to apply the change.")


if __name__ == "__main__":
    main()
