"""按需安装「本地生图」运行时：uv + Python + venv + PyTorch/diffusers + sd-turbo 模型。

全部安装到 %LOCALAPPDATA%\\Sen\\runtime 与 %LOCALAPPDATA%\\Sen\\models，
装好后 image_gen.LocalImageService 就能直接使用。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

import platform_layer

PYPI = "https://pypi.tuna.tsinghua.edu.cn/simple"
UV_INDEX = "https://pypi.tuna.tsinghua.edu.cn/simple/uv/"
TORCH_CUDA_MIRRORS = [
    "https://mirrors.aliyun.com/pytorch-wheels/cu124",
    "https://download.pytorch.org/whl/cu124",
]
TORCH_CPU_MIRRORS = [
    "https://mirrors.aliyun.com/pytorch-wheels/cpu",
    "https://download.pytorch.org/whl/cpu",
]
MODEL_BASE = "https://modelscope.cn/models/AI-ModelScope/sd-turbo/resolve/master"
MODEL_FILES = [
    "model_index.json",
    "scheduler/scheduler_config.json",
    "tokenizer/vocab.json",
    "tokenizer/merges.txt",
    "tokenizer/special_tokens_map.json",
    "tokenizer/tokenizer_config.json",
    "text_encoder/config.json",
    "text_encoder/model.fp16.safetensors",
    "unet/config.json",
    "unet/diffusion_pytorch_model.fp16.safetensors",
    "vae/config.json",
    "vae/diffusion_pytorch_model.fp16.safetensors",
]
MODEL_APPROX_BYTES = 2_500_000_000

STEPS = [
    ("uv", "下载安装器", 3),
    ("python", "准备 Python 环境", 4),
    ("venv", "创建虚拟环境", 4),
    ("torch", "安装 PyTorch", 34),
    ("deps", "安装 diffusers 等依赖", 10),
    ("model", "下载绘图模型", 45),
]

_STATE = {
    "requested": False,
    "attempt": 0,
    "running": False,
    "step": "",
    "step_index": 0,
    "percent": 0,
    "detail": "",
    "error": "",
    "done": False,
}
_LOCK = threading.Lock()


class RuntimeInstaller:
    def __init__(self, data_root: Path) -> None:
        self.data_root = Path(data_root)
        self.state_path = self.data_root / "data" / "runtime-install.json"
        self.runtime_dir = self.data_root / "runtime"
        self.venv = self.runtime_dir / "venv-train"
        self.uv_exe = self.runtime_dir / platform_layer.uv_binary_name()
        self.models = self.data_root / "models" / "sd-turbo"
        self.log_path = self.data_root / "data" / "runtime-install.log"

    # ------------------------------------------------------------------ 状态
    def python_exe(self) -> Path:
        return platform_layer.venv_python(self.venv)

    def model_ready(self) -> bool:
        unet = self.models / "unet"
        if not unet.is_dir():
            return False
        return any(
            item.stat().st_size > 100 * 1024 * 1024 for item in unet.glob("*.safetensors")
        )

    def status(self) -> dict:
        with _LOCK:
            state = dict(_STATE)
        state["venv_ready"] = self.python_exe().is_file()
        state["model_ready"] = self.model_ready()
        state["ready"] = state["venv_ready"] and state["model_ready"]
        return state


    def _save(self) -> None:
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            with _LOCK:
                payload = dict(_STATE)
            payload["venv_ready"] = self.python_exe().is_file()
            payload["model_ready"] = self.model_ready()
            self.state_path.write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8"
            )
        except OSError:
            pass

    def load_saved(self) -> bool:
        """恢复上次的安装意愿：返回 True 表示需要继续安装。"""
        if not self.state_path.is_file():
            return False
        try:
            saved = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        with _LOCK:
            _STATE["requested"] = bool(saved.get("requested"))
            _STATE["attempt"] = int(saved.get("attempt") or 0)
            _STATE["percent"] = int(saved.get("percent") or 0)
            _STATE["step"] = str(saved.get("step") or "")
            _STATE["done"] = bool(saved.get("done"))
        return bool(saved.get("requested")) and not self.status()["ready"]

    # ------------------------------------------------------------------ 入口
    def start(self) -> dict:
        with _LOCK:
            if _STATE["running"]:
                return {"ok": False, "error": "正在安装中"}
            _STATE.update(
                running=True, requested=True, step="", step_index=0,
                percent=0, detail="", error="", done=False, attempt=0,
            )
        self._save()
        threading.Thread(target=self._run, daemon=True).start()
        return {"ok": True}

    def resume_if_pending(self) -> bool:
        """应用启动时调用：上次没装完就接着装。"""
        if not self.load_saved():
            return False
        with _LOCK:
            if _STATE["running"]:
                return False
            _STATE["running"] = True
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _log(self, message: str) -> None:
        try:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"{time.strftime('%H:%M:%S')} {message}\n")
        except OSError:
            pass

    def _set(self, **kwargs) -> None:
        with _LOCK:
            _STATE.update(kwargs)

    def _progress_for(self, index: int, fraction: float) -> int:
        base = sum(weight for _, _, weight in STEPS[:index])
        return int(base + STEPS[index][2] * max(0.0, min(1.0, fraction)))

    def _run(self) -> None:
        for attempt in range(1, 41):
            try:
                for index, (key, label, _weight) in enumerate(STEPS):
                    self._set(
                        step=label, step_index=index, detail="",
                        percent=self._progress_for(index, 0.02), attempt=attempt,
                    )
                    self._save()
                    getattr(self, f"_step_{key}")(index)
                self._set(
                    running=False, done=True, requested=False, percent=100,
                    step="完成", detail="本地生图已就绪", error="",
                )
                self._save()
                return
            except Exception as error:  # noqa: BLE001
                self._log(f"attempt {attempt} failed: {error!r}")
                self._set(error=str(error), detail=f"下载中断，{60} 秒后重试（第 {attempt} 次）")
                self._save()
                if attempt >= 40:
                    self._set(running=False, detail="多次失败，请检查网络后重试")
                    self._save()
                    return
                time.sleep(60)

    # ------------------------------------------------------------------ 步骤

    def _ticker(self, index: int, stop: threading.Event, expect_bytes: int) -> None:
        """在长步骤进行时按磁盘增长估算百分比。"""
        cache = platform_layer.uv_cache_dir()
        while not stop.wait(2.0):
            total = self._dir_size(self.venv) + self._dir_size(cache)
            fraction = min(0.95, total / max(1, expect_bytes))
            with _LOCK:
                _STATE["percent"] = self._progress_for(index, 0.05 + fraction * 0.9)
                _STATE["detail"] = f"已下载 {total // 1048576} MB"

    @staticmethod
    def _dir_size(path: Path) -> int:
        total = 0
        try:
            for item in path.rglob("*"):
                if item.is_file():
                    total += item.stat().st_size
        except OSError:
            return total
        return total

    def _long_run(self, index: int, command: list[str], expect_bytes: int, timeout: int) -> subprocess.CompletedProcess:
        stop = threading.Event()
        thread = threading.Thread(target=self._ticker, args=(index, stop, expect_bytes), daemon=True)
        thread.start()
        try:
            return subprocess.run(
                command, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=timeout,
            )
        finally:
            stop.set()

    def _curl(self, args: list[str], timeout: int) -> None:
        self._log("curl " + " ".join(args))
        result = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(f"下载失败（curl {result.returncode}）{result.stderr[:200]}")

    def _step_uv(self, index: int) -> None:
        if self.uv_exe.is_file():
            self._set(percent=self._progress_for(index, 1))
            return
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        if not platform_layer.IS_WINDOWS:
            existing = shutil.which("uv")
            if existing:
                shutil.copy2(existing, self.uv_exe)
                self.uv_exe.chmod(0o755)
                self._set(percent=self._progress_for(index, 1))
                return
            self._log("installing uv via astral.sh")
            subprocess.run(
                ["/bin/bash", "-lc", "curl -LsSf https://astral.sh/uv/install.sh | sh"],
                capture_output=True, text=True, timeout=600,
            )
            found = shutil.which("uv") or str(Path.home() / ".local" / "bin" / "uv")
            if Path(found).is_file():
                shutil.copy2(found, self.uv_exe)
                self.uv_exe.chmod(0o755)
                self._set(percent=self._progress_for(index, 1))
                return
            raise RuntimeError("uv 安装失败，请手动安装 uv 后重试")
        with urllib.request.urlopen(UV_INDEX, timeout=60) as response:
            html = response.read().decode("utf-8", "replace")
        wheels = re.findall(r'href="([^"]*uv-[0-9.]+-py3-none-win_amd64\.whl)', html)
        if not wheels:
            raise RuntimeError("找不到 uv 的安装包")
        url = wheels[-1]
        if url.startswith("../../"):
            url = "https://pypi.tuna.tsinghua.edu.cn/simple/uv/" + url
        wheel = self.runtime_dir / "uv.whl"
        self._curl(
            ["curl", "-sL", "-o", str(wheel), "--max-time", "300", url], timeout=360
        )
        with zipfile.ZipFile(wheel) as archive:
            for name in archive.namelist():
                if name.endswith("uv.exe"):
                    target = self.runtime_dir / "uv.exe"
                    target.write_bytes(archive.read(name))
                    break
        wheel.unlink(missing_ok=True)
        if not self.uv_exe.is_file():
            raise RuntimeError("uv.exe 解压失败")
        self._set(percent=self._progress_for(index, 1))

    def _find_system_python(self) -> str:
        candidates = ["python3.12", "python3.11", "python3.10", "python3.13", "python"]
        for name in candidates:
            path = shutil.which(name)
            if not path:
                continue
            try:
                result = subprocess.run(
                    [path, "-c", "import sys; print('%d.%d' % sys.version_info[:2])"],
                    capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
                )
            except Exception:  # noqa: BLE001
                continue
            version = (result.stdout or "").strip()
            if version in {"3.10", "3.11", "3.12", "3.13"}:
                return path
        return ""

    def _step_python(self, index: int) -> None:
        system = self._find_system_python()
        if system:
            self._log("system python: " + system)
            self._set(detail="使用系统 Python", percent=self._progress_for(index, 1))
            self.system_python = system
            return
        self._set(detail="下载独立 Python（约 30 MB）", percent=self._progress_for(index, 0.2))
        env = dict(os.environ)
        if platform_layer.IS_WINDOWS:
            env.setdefault(
                "UV_PYTHON_INSTALL_MIRROR",
                "https://mirrors.tuna.tsinghua.edu.cn/github-release/astral-sh/python-build-standalone/20241016",
            )
        result = subprocess.run(
            [str(self.uv_exe), "python", "install", "3.11"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800, env=env,
        )
        self._log("uv python install: " + (result.stdout or "")[-500:] + (result.stderr or "")[-500:])
        installed = self.runtime_dir / "python-3.11"
        if result.returncode != 0:
            raise RuntimeError("Python 下载失败，请检查网络或手动安装 Python 3.11")
        self.system_python = "3.11"
        self._set(percent=self._progress_for(index, 1))

    def _step_venv(self, index: int) -> None:
        if self.python_exe().is_file():
            self._set(percent=self._progress_for(index, 1))
            return
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        python = getattr(self, "system_python", "python")
        result = subprocess.run(
            [str(self.uv_exe), "venv", str(self.venv), "--python", python],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600,
        )
        self._log("uv venv: " + (result.stdout or "")[-300:] + (result.stderr or "")[-300:])
        if not self.python_exe().is_file():
            raise RuntimeError("创建虚拟环境失败")
        self._set(percent=self._progress_for(index, 1))

    def _has_nvidia(self) -> bool:
        try:
            result = subprocess.run(
                ["nvidia-smi", "-L"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20
            )
            return result.returncode == 0 and "GPU" in (result.stdout or "")
        except Exception:  # noqa: BLE001
            return False

    def _uv_pip(self, index: int, packages: list[str], mirrors: list[str], extra: list[str] | None = None) -> bool:
        for mirror in mirrors:
            self._set(detail=f"来源 {mirror.split('/')[2]}")
            command = [
                str(self.uv_exe), "pip", "install", "--python", str(self.python_exe()),
                "--index-url", mirror,
            ]
            if extra:
                command += extra
            command += packages
            self._log("uv pip " + " ".join(command[-6:]))
            expect = 3_000_000_000 if "cuda" in " ".join(mirrors) or "cu124" in " ".join(mirrors) else 900_000_000
            result = self._long_run(index, command, expect, 5400)
            if result.returncode == 0:
                return True
            self._log("pip failed: " + (result.stderr or "")[-400:])
        return False

    def _torch_command(self, cuda: bool, mirror: str) -> list[str]:
        command = [
            str(self.uv_exe), "pip", "install", "--python", str(self.python_exe()),
            "--index-url", PYPI,
        ]
        if cuda:
            # 阿里云的 pytorch-wheels 是文件列表页，用 --find-links 而不是 index
            command += ["--find-links", mirror, "torch==2.4.0", "torchvision==0.19.0"]
        else:
            command += ["torch", "torchvision"]
        return command

    def _step_torch(self, index: int) -> None:
        if self._venv_has("torch"):
            self._set(percent=self._progress_for(index, 1))
            return
        if not platform_layer.IS_WINDOWS:
            # macOS：PyPI 的 arm64 轮子自带 MPS，直接装，不走 Windows 的 wheel 解析
            self._set(detail="下载 PyTorch（macOS / MPS，约 120 MB）")
            command = [
                str(self.uv_exe), "pip", "install", "--python", str(self.python_exe()),
                "torch", "torchvision",
            ]
            result = self._long_run(index, command, 200_000_000, 5400)
            if result.returncode != 0 or not self._venv_has("torch"):
                raise RuntimeError("PyTorch 安装失败：" + (result.stderr or "")[-300:])
            self._set(percent=self._progress_for(index, 1))
            return
        cuda = self._has_nvidia() and os.getenv("SEN_TORCH_CUDA") == "1"
        attempts = (
            [(True, mirror) for mirror in TORCH_CUDA_MIRRORS] + [(False, PYPI)]
            if cuda
            else [(False, PYPI)]
        )
        for want_cuda, mirror in attempts:
            label = "GPU 版（约 2.5 GB）" if want_cuda else "CPU 版（约 250 MB）"
            self._set(detail=f"下载 PyTorch {label}")
            wheel_dir = self.runtime_dir / "wheels"
            wheels: list[Path] = []
            try:
                for package in ("torch", "torchvision"):
                    url = self._wheel_url(package, mirror)
                    if not url:
                        continue
                    target = wheel_dir / url.split("/")[-1].split("?")[0]
                    if not target.is_file() or target.stat().st_size < 1_000_000:
                        self._fetch_resumable(url, target)
                    wheels.append(target)
            except Exception as error:  # noqa: BLE001
                self._log(f"wheel resolve failed: {error!r}")
            if wheels:
                command = [
                    str(self.uv_exe), "pip", "install", "--python", str(self.python_exe()),
                    "--index-url", PYPI,
                ] + [str(item) for item in wheels]
                result = self._long_run(index, command, 400_000_000, 3600)
                if result.returncode == 0 and self._venv_has("torch"):
                    for item in wheels:
                        item.unlink(missing_ok=True)
                    self._set(percent=self._progress_for(index, 1))
                    return
                self._log(f"torch install failed ({label}): " + (result.stderr or "")[-300:])
            command = self._torch_command(want_cuda, mirror)
            result = self._long_run(index, command, 400_000_000, 3600)
            if result.returncode == 0 and self._venv_has("torch"):
                self._set(percent=self._progress_for(index, 1))
                return
            self._log(f"torch attempt failed ({label}): " + (result.stderr or "")[-300:])
        raise RuntimeError("PyTorch 安装失败，请检查网络后重试")

    def _venv_has(self, module: str) -> bool:
        if not self.python_exe().is_file():
            return False
        result = subprocess.run(
            [str(self.python_exe()), "-c", f"import {module}"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
        )
        return result.returncode == 0

    def _step_deps(self, index: int) -> None:
        if self._venv_has("diffusers"):
            self._set(percent=self._progress_for(index, 1))
            return
        packages = [
            "diffusers==0.35.1",
            "transformers>=4.44,<5",
            "accelerate",
            "safetensors",
            "pillow",
            "huggingface-hub>=0.34,<1.0",
        ]
        if not self._uv_pip(index, packages, [PYPI]):
            raise RuntimeError("依赖安装失败，请检查网络")
        self._set(percent=self._progress_for(index, 1))


    def _wheel_url(self, package: str, mirror: str) -> str:
        """从 PEP 503 索引里找出当前 Python 版本对应的 Windows wheel。"""
        tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
        with urllib.request.urlopen(mirror.rstrip("/") + f"/{package}/", timeout=60) as response:
            html = response.read().decode("utf-8", "replace")
        # 只认 cp313-cp313（排除 cp313t 无 GIL 版本），并取版本号最大的
        pattern = re.compile(
            r'href="([^"]*' + re.escape(package) + r'-(\d+\.\d+\.\d+)([^"]*?)'
            + re.escape(f"-{tag}-{tag}-win_amd64.whl") + r'[^"]*)"'
        )
        candidates = [(tuple(int(x) for x in m.group(2).split(".")), m.group(1)) for m in pattern.finditer(html)]
        found = [url for _version, url in sorted(candidates)]
        if not found:
            return ""
        url = found[-1].split("#")[0]
        if url.startswith("http"):
            return url
        from urllib.parse import urljoin

        return urljoin(mirror.rstrip("/") + f"/{package}/", url)

    def _fetch_resumable(self, url: str, dest: Path, expect_min: int = 1) -> Path:
        """curl 断点续传；每次只给 90 秒，断了立刻接着下。"""
        dest.parent.mkdir(parents=True, exist_ok=True)
        stalled = 0
        for attempt in range(200):
            before = dest.stat().st_size if dest.is_file() else 0
            self._set(detail=f"{dest.name}（已下载 {before // 1048576} MB）")
            subprocess.run(
                ["curl", "-sL", "-C", "-", "-o", str(dest), "--max-time", "90", url],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
            )
            after = dest.stat().st_size if dest.is_file() else 0
            self._log(f"wheel {dest.name}: {before // 1048576} -> {after // 1048576} MB")
            if after > expect_min and after == before:
                stalled += 1
                if stalled >= 3:
                    break
            else:
                stalled = 0
        return dest

    def _step_model(self, index: int) -> None:
        if self.model_ready():
            self._set(percent=self._progress_for(index, 1))
            return
        self.models.mkdir(parents=True, exist_ok=True)
        for relative in MODEL_FILES:
            target = self.models / relative
            if target.is_file() and target.stat().st_size > 0:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            url = f"{MODEL_BASE}/{relative}"
            self._set(detail=f"{relative}（{self._model_bytes() // 1048576} MB）")
            partial = target.with_suffix(target.suffix + ".part")
            self._curl(
                ["curl", "-sL", "-o", str(partial), "--max-time", "1800", url], timeout=1860
            )
            partial.replace(target)
            self._set(percent=self._progress_for(index, min(1.0, self._model_bytes() / MODEL_APPROX_BYTES)))

    def _model_bytes(self) -> int:
        total = 0
        for item in self.models.rglob("*"):
            if item.is_file():
                total += item.stat().st_size
        return total


def installer_for(data_root: Path) -> RuntimeInstaller:
    return RuntimeInstaller(data_root)
