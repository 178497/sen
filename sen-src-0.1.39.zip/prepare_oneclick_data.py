"""Build a mixed, reproducible dataset for the one-click retraining run."""

from __future__ import annotations

import json
import random
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
CODE_DATA = BASE_DIR / "data" / "online_train.jsonl"
SEED_DATA = BASE_DIR / "data" / "assistant_seed.jsonl"
EXAMPLE_DATA = BASE_DIR / "data" / "train.example.jsonl"
OUTPUT_DATA = BASE_DIR / "data" / "train_oneclick.jsonl"


def read_rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def main() -> None:
    code_source = CODE_DATA
    if not code_source.exists():
        local_data = BASE_DIR / "data" / "train.jsonl"
        code_source = local_data if local_data.exists() else EXAMPLE_DATA
    code_rows = read_rows(code_source)[:500]
    seed_rows = read_rows(SEED_DATA) + read_rows(EXAMPLE_DATA)
    if not code_rows:
        raise SystemExit(f"Missing code samples: {code_source}")
    if not seed_rows:
        raise SystemExit(f"Missing assistant behavior samples: {SEED_DATA}")

    behavior_target = 120
    behavior_rows = [
        dict(seed_rows[index % len(seed_rows)])
        for index in range(behavior_target)
    ]
    rows = code_rows + behavior_rows
    random.Random(42).shuffle(rows)

    OUTPUT_DATA.write_text(
        "\n".join(
            json.dumps(row, ensure_ascii=False) for row in rows
        )
        + "\n",
        encoding="utf-8",
    )
    summary = {
        "total": len(rows),
        "coding": len(code_rows),
        "behavior": len(behavior_rows),
        "output": str(OUTPUT_DATA),
    }
    (BASE_DIR / "data" / "train_oneclick_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
