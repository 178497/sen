"""Local text-to-image service backed by a persistent diffusers worker."""

from __future__ import annotations

import base64
import json
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path

import platform_layer
from typing import Any


class LocalImageService:
    """Keeps one diffusers process warm and feeds it prompts over a pipe."""

    def __init__(self, base_dir: Path, model: str) -> None:
        self.base_dir = base_dir
        self.model = model
        import os

        train_root = Path(os.getenv("CHAT_VENV_TRAIN", str(base_dir / ".venv-train")))
        self.python = platform_layer.venv_python(train_root)
        self.worker_script = base_dir / "image_worker.py"
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def _start(self) -> None:
        if not self.python.exists():
            raise RuntimeError(
                "本地生图需要训练环境（.venv-train），请先运行 setup_train.ps1"
            )
        if not self._model_cached():
            raise RuntimeError(
                "本地生图模型尚未下载完成（后台下载中，完成后会自动可用）"
            )
        creation_flags = 0x08000000 if sys.platform == "win32" else 0
        self._process = subprocess.Popen(
            [
                str(self.python),
                str(self.worker_script),
                "--model",
                self.model,
                "--local-files-only",
            ],
            cwd=str(self.base_dir),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            creationflags=creation_flags,
        )
        ready = self._read_line(300)
        if not ready or "ready" not in ready:
            self.stop()
            raise RuntimeError("本地生图模型加载失败，请检查 diffusers 环境")

    def _model_cached(self) -> bool:
        local = Path(self.model)
        if local.is_dir():
            unet = local / "unet"
            return unet.is_dir() and any(
                item.stat().st_size > 100 * 1024 * 1024
                for item in unet.glob("*.safetensors")
            )
        slug = "models--" + self.model.replace("/", "--")
        roots = [
            Path.home() / ".cache" / "huggingface" / "hub" / slug / "snapshots",
            Path(os.getenv("HF_HOME", "")) / "hub" / slug / "snapshots"
            if os.getenv("HF_HOME")
            else Path.home() / ".cache" / "huggingface" / "hub" / slug / "snapshots",
        ]
        for root in roots:
            if not root.exists():
                continue
            for snapshot in root.iterdir():
                unet = snapshot / "unet"
                if not unet.is_dir():
                    continue
                weights = [
                    item
                    for item in unet.glob("*.safetensors")
                    if item.stat().st_size > 100 * 1024 * 1024
                ]
                if weights:
                    return True
        return False

    def _read_line(self, timeout: float) -> str:
        process = self._process
        if process is None or process.stdout is None:
            raise RuntimeError("本地生图进程未启动")
        bucket: queue.Queue[str] = queue.Queue()

        def reader() -> None:
            try:
                bucket.put(process.stdout.readline())
            except Exception:
                bucket.put("")

        threading.Thread(target=reader, daemon=True).start()
        try:
            return bucket.get(timeout=timeout)
        except queue.Empty as error:
            raise RuntimeError("本地生图超时（模型可能仍在加载）") from error

    def stop(self) -> None:
        process = self._process
        self._process = None
        if process is None:
            return
        try:
            if process.stdin:
                process.stdin.close()
        except Exception:
            pass
        try:
            process.terminate()
        except Exception:
            pass

    def generate(
        self,
        prompt: str,
        out_path: Path,
        size: int = 512,
        steps: int = 4,
    ) -> dict[str, Any]:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._start()
            process = self._process
            assert process is not None and process.stdin is not None
            request = {
                "prompt": prompt,
                "size": size,
                "steps": steps,
                "out": str(out_path),
            }
            process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
            process.stdin.flush()
            raw = self._read_line(300)
            try:
                result = json.loads(raw)
            except (TypeError, ValueError):
                self.stop()
                raise RuntimeError("本地生图进程返回了无法解析的内容")
            if not result.get("ok"):
                raise RuntimeError(result.get("error") or "本地生图失败")
            data = Path(result["path"]).read_bytes()
            return {
                "ok": True,
                "path": str(result["path"]),
                "data_url": "data:image/png;base64,"
                + base64.b64encode(data).decode("ascii"),
                "model": self.model,
                "prompt": prompt,
                "ms": result.get("ms", 0),
            }


_SERVICE: LocalImageService | None = None
_SERVICE_LOCK = threading.Lock()


def local_image_service(base_dir: Path, model: str) -> LocalImageService:
    global _SERVICE
    with _SERVICE_LOCK:
        if _SERVICE is None or _SERVICE.model != model:
            if _SERVICE is not None:
                _SERVICE.stop()
            _SERVICE = LocalImageService(base_dir, model)
    return _SERVICE
