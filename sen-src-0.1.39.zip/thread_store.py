"""Persistent conversation store for the desktop shell."""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any

MAX_THREADS = 300
MAX_MESSAGES_PER_THREAD = 400


class ThreadStore:
    """Keeps conversations in a JSON file next to the app data."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()

    @staticmethod
    def _clean_thread(thread: Any) -> dict[str, Any] | None:
        if not isinstance(thread, dict):
            return None
        thread_id = thread.get("id")
        if not isinstance(thread_id, str) or not thread_id:
            return None
        messages = thread.get("messages")
        if not isinstance(messages, list):
            messages = []
        cleaned: list[Any] = []
        for message in messages[-MAX_MESSAGES_PER_THREAD:]:
            if isinstance(message, dict) and isinstance(message.get("content"), str):
                cleaned.append(message)
        return {
            "id": thread_id,
            "title": str(thread.get("title") or "新对话")[:120],
            "mode": str(thread.get("mode") or "knowledge"),
            "messages": cleaned,
            "createdAt": thread.get("createdAt") or 0,
            "updatedAt": thread.get("updatedAt") or 0,
        }

    def load(self) -> dict[str, Any]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"threads": [], "active": "", "savedAt": 0}
        if not isinstance(raw, dict):
            return {"threads": [], "active": "", "savedAt": 0}
        threads = [
            cleaned
            for cleaned in (self._clean_thread(item) for item in raw.get("threads", []))
            if cleaned
        ]
        return {
            "threads": threads[:MAX_THREADS],
            "active": str(raw.get("active") or ""),
            "savedAt": int(raw.get("savedAt") or 0),
        }

    def save(self, payload: dict[str, Any]) -> dict[str, Any]:
        threads = payload.get("threads")
        if not isinstance(threads, list):
            threads = []
        cleaned = [
            item
            for item in (self._clean_thread(thread) for thread in threads)
            if item
        ]
        cleaned.sort(key=lambda item: float(item.get("updatedAt") or 0), reverse=True)
        active = payload.get("active")
        data = {
            "threads": cleaned[:MAX_THREADS],
            "active": active if isinstance(active, str) else "",
            "savedAt": int(time.time() * 1000),
        }
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".json.tmp")
            temporary.write_text(
                json.dumps(data, ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(temporary, self.path)
        return {
            "ok": True,
            "threads": len(data["threads"]),
            "savedAt": data["savedAt"],
        }
