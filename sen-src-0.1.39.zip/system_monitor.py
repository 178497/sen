"""Lightweight Windows system metrics sampler (no third-party dependencies)."""

from __future__ import annotations

import ctypes
import subprocess
import sys
import threading
import time
from typing import Any

IS_WINDOWS = sys.platform == "win32"
CREATE_NO_WINDOW = 0x08000000


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", ctypes.c_ulong), ("dwHighDateTime", ctypes.c_ulong)]

    @property
    def value(self) -> int:
        return (self.dwHighDateTime << 32) | self.dwLowDateTime


def _filetime_total(kernel: _FILETIME, user: _FILETIME) -> int:
    return kernel.value + user.value


class SystemMonitor:
    """Samples CPU / RAM / GPU usage on a background thread."""

    def __init__(self, interval: float = 2.0) -> None:
        self.interval = max(1.0, float(interval))
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_cpu: tuple[int, int] | None = None
        self._gpu_available = True
        self._data: dict[str, Any] = {
            "cpu_percent": 0.0,
            "ram_used_gb": 0.0,
            "ram_total_gb": 0.0,
            "ram_percent": 0.0,
            "gpu_percent": None,
            "vram_used_mb": None,
            "vram_total_mb": None,
            "gpu_temp_c": None,
            "gpu_name": "",
            "process_mb": 0.0,
            "sampled_at": 0.0,
        }

    # -- lifecycle -------------------------------------------------
    def start(self) -> None:
        if not IS_WINDOWS:
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._data)

    # -- sampling --------------------------------------------------
    def _loop(self) -> None:
        self._last_cpu = self._read_cpu_times()
        tick = 0
        while not self._stop.wait(self.interval):
            tick += 1
            self._sample(with_gpu=tick % 2 == 0)

    def _sample(self, with_gpu: bool = True) -> None:
        cpu = self._read_cpu_percent()
        ram_used, ram_total, ram_percent = self._read_memory()
        gpu = self._read_gpu() if with_gpu or not self._data.get("gpu_name") else {}
        process_mb = self._read_process_memory()
        with self._lock:
            self._data.update(
                {
                    "cpu_percent": cpu,
                    "ram_used_gb": ram_used,
                    "ram_total_gb": ram_total,
                    "ram_percent": ram_percent,
                    "process_mb": process_mb,
                    "sampled_at": time.time(),
                }
            )
            self._data.update(gpu)

    def _read_cpu_times(self) -> tuple[int, int] | None:
        if not IS_WINDOWS:
            try:
                import psutil

                times = psutil.cpu_times()
                idle = times.idle
                total = idle + times.user + times.system + getattr(times, "nice", 0.0)
                return int(idle * 1000), int(total * 1000)
            except Exception:  # noqa: BLE001
                return None
        idle = _FILETIME()
        kernel = _FILETIME()
        user = _FILETIME()
        ok = ctypes.windll.kernel32.GetSystemTimes(  # type: ignore[attr-defined]
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
        )
        if not ok:
            return None
        return idle.value, _filetime_total(kernel, user)

    def _read_cpu_percent(self) -> float:
        current = self._read_cpu_times()
        previous = self._last_cpu
        self._last_cpu = current
        if not current or not previous:
            return 0.0
        idle_delta = current[0] - previous[0]
        total_delta = current[1] - previous[1]
        if total_delta <= 0:
            return 0.0
        busy = max(0.0, min(1.0, 1.0 - idle_delta / total_delta))
        return round(busy * 100, 1)

    @staticmethod
    def _read_memory() -> tuple[float, float, float]:
        if not IS_WINDOWS:
            try:
                import psutil

                info = psutil.virtual_memory()
                total = info.total / (1024 ** 3)
                used = (info.total - info.available) / (1024 ** 3)
                return round(used, 2), round(total, 2), float(info.percent)
            except Exception:  # noqa: BLE001
                return 0.0, 0.0, 0.0
        status = _MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        ok = ctypes.windll.kernel32.GlobalMemoryStatusEx(  # type: ignore[attr-defined]
            ctypes.byref(status)
        )
        if not ok:
            return 0.0, 0.0, 0.0
        total = status.ullTotalPhys / (1024 ** 3)
        used = (status.ullTotalPhys - status.ullAvailPhys) / (1024 ** 3)
        return round(used, 2), round(total, 2), float(status.dwMemoryLoad)

    def _read_gpu(self) -> dict[str, Any]:
        if not IS_WINDOWS:
            if not getattr(self, "_mac_gpu_name", None):
                try:
                    import subprocess as _sp

                    out = _sp.run(
                        ["system_profiler", "SPDisplaysDataType"],
                        capture_output=True, text=True, timeout=8,
                    ).stdout or ""
                    for line in out.splitlines():
                        if "Chipset Model" in line:
                            self._mac_gpu_name = line.split(":", 1)[1].strip()
                            break
                except Exception:  # noqa: BLE001
                    pass
            name = getattr(self, "_mac_gpu_name", "") or "Apple GPU"
            return {"gpu_name": name, "gpu_util": None, "gpu_mem_used": None, "gpu_mem_total": None, "gpu_temp": None}
        if not self._gpu_available:
            return {}
        try:
            completed = subprocess.run(
                [
                    "nvidia-smi",
                    "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                    "--format=csv,noheader,nounits",
                ],
                capture_output=True,
                text=True,
                timeout=3,
                creationflags=CREATE_NO_WINDOW,
            )
        except (OSError, subprocess.SubprocessError):
            self._gpu_available = False
            return {}
        line = (completed.stdout or "").strip().splitlines()
        if not line:
            self._gpu_available = False
            return {}
        parts = [part.strip() for part in line[0].split(",")]
        if len(parts) < 5:
            return {}
        try:
            return {
                "gpu_name": parts[0],
                "gpu_percent": float(parts[1]),
                "vram_used_mb": float(parts[2]),
                "vram_total_mb": float(parts[3]),
                "gpu_temp_c": float(parts[4]),
            }
        except ValueError:
            return {}

    @staticmethod
    def _read_process_memory() -> float:
        if not IS_WINDOWS:
            return 0.0
        try:
            import ctypes.wintypes as wintypes

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", wintypes.DWORD),
                    ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
            handle = ctypes.windll.kernel32.GetCurrentProcess()  # type: ignore[attr-defined]
            for dll_name, func_name in (
                ("kernel32", "K32GetProcessMemoryInfo"),
                ("psapi", "GetProcessMemoryInfo"),
            ):
                try:
                    dll = ctypes.WinDLL(dll_name)
                    func = getattr(dll, func_name)
                except (AttributeError, OSError):
                    continue
                func.argtypes = [
                    wintypes.HANDLE,
                    ctypes.POINTER(PROCESS_MEMORY_COUNTERS),
                    wintypes.DWORD,
                ]
                func.restype = wintypes.BOOL
                counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
                if func(handle, ctypes.byref(counters), counters.cb):
                    return round(counters.WorkingSetSize / (1024 ** 2), 1)
            return 0.0
        except Exception:
            return 0.0
