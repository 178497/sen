#!/bin/bash
# 双击运行：在 Mac 上构建森，并自动打开产物所在文件夹。
cd "$(dirname "$0")/.." || exit 1

clear
echo "=============================="
echo "  森 · macOS 构建"
echo "=============================="
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "没有找到 python3。"
  echo "请先安装：https://www.python.org/downloads/macos/"
  echo
  read -r -p "按回车关闭…"
  exit 1
fi

VERSION="$(cat VERSION 2>/dev/null || echo 0.1.27)"
echo "将构建版本：$VERSION"
echo "首次运行需要下载依赖，约 3-5 分钟。"
echo

read -r -p "开始？(y/N) " go
case "$go" in
  y|Y) ;;
  *) echo "已取消"; read -r -p "按回车关闭…"; exit 0 ;;
esac

bash release/build_mac.sh "$VERSION" || {
  echo
  echo "构建失败，请把上面的报错发给我。"
  read -r -p "按回车关闭…"
  exit 1
}

open release
echo
echo "完成。zip 在 release/ 目录里。"
read -r -p "按回车关闭…"
