#!/bin/bash
# 收集诊断信息，打包成一个 zip 便于发回。
cd "$(dirname "$0")" || exit 1

DATA="$HOME/Library/Application Support/Sen"
OUT="$HOME/Desktop/sen-diagnostics-$(date +%Y%m%d-%H%M%S).zip"
TMP="$(mktemp -d)"

echo "收集信息…"

mkdir -p "$TMP/meta"
{
  echo "macOS: $(sw_vers -productVersion 2>/dev/null)"
  echo "arch: $(uname -m)"
  echo "python3: $(python3 --version 2>&1)"
  echo "ollama: $(command -v ollama || echo 'not found')"
  echo "app: $(ls -d /Applications/Sen.app 2>/dev/null || echo 'not installed')"
  if [ -d "/Applications/Sen.app" ]; then
    echo "app version: $(cat /Applications/Sen.app/Contents/Resources/VERSION 2>/dev/null || echo '?')"
    echo "codesign: $(codesign -dv /Applications/Sen.app 2>&1 | head -3)"
  fi
} > "$TMP/meta/env.txt"

if [ -d "$DATA" ]; then
  mkdir -p "$TMP/sen"
  cp "$DATA/desktop-error.log" "$TMP/sen/" 2>/dev/null
  cp "$DATA/data/boot.log" "$TMP/sen/" 2>/dev/null
  cp "$DATA/data/runtime-install.log" "$TMP/sen/" 2>/dev/null
  cp "$DATA/training.log" "$TMP/sen/" 2>/dev/null
  cp "$DATA/model_config.json" "$TMP/sen/" 2>/dev/null
  # 配置里有 API key，去掉再打包
  if [ -f "$DATA/provider_config.json" ]; then
    python3 - "$DATA/provider_config.json" "$TMP/sen/provider_config.json" <<'PY'
import json, sys
src, dst = sys.argv[1], sys.argv[2]
try:
    data = json.load(open(src, encoding="utf-8"))
except Exception:
    sys.exit(0)
if isinstance(data, dict):
    data["api_key"] = "<redacted>" if data.get("api_key") else ""
json.dump(data, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
PY
  fi
fi

if [ -d "/Applications/Sen.app" ]; then
  mkdir -p "$TMP/app"
  find "/Applications/Sen.app/Contents" -maxdepth 2 -name "*.sh" -o -maxdepth 2 -name "*.py" \
    -o -maxdepth 2 -name "VERSION" 2>/dev/null | head -30 > "$TMP/app/files.txt"
  ls -la "/Applications/Sen.app/Contents/MacOS" > "$TMP/app/macos.txt" 2>&1
  ls -la "/Applications/Sen.app/Contents/Resources" >> "$TMP/app/macos.txt" 2>&1
fi

(cd "$TMP" && zip -qr "$OUT" .)
rm -rf "$TMP"
echo
echo "已生成：$OUT"
open "$HOME/Desktop" 2>/dev/null
read -r -p "按回车关闭…"
