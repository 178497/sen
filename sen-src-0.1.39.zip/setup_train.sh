#!/bin/bash
# macOS / Linux 训练环境安装（对应 Windows 的 setup_train.ps1）
set -euo pipefail
cd "$(dirname "$0")"

if [[ -n "${CHAT_VENV_TRAIN:-}" ]]; then
  VENV_ROOT="$CHAT_VENV_TRAIN"
else
  VENV_ROOT="$(pwd)/.venv-train"
fi

echo "训练环境目录: $VENV_ROOT"
if [[ ! -x "$VENV_ROOT/bin/python" ]]; then
  python3 -m venv "$VENV_ROOT"
fi

PY="$VENV_ROOT/bin/python"
"$PY" -m pip install --upgrade pip >/dev/null

# 与 Windows 共用 requirements-train.txt，只是去掉 bitsandbytes
# （它没有 macOS 轮子；训练脚本会自动退到 fp16 LoRA）
REQ_TMP="$(mktemp -t sen-train-req)"
grep -v -i "bitsandbytes" requirements-train.txt > "$REQ_TMP"

install_all() {
  "$PY" -m pip install torch torchvision
  "$PY" -m pip install -r "$REQ_TMP"
  "$PY" -m pip install gguf mistral-common
}

echo "==> 安装依赖（直连 PyPI）"
if ! install_all; then
  echo "==> 直连失败，改用清华镜像重试"
  MIRROR="-i https://pypi.tuna.tsinghua.edu.cn/simple"
  "$PY" -m pip install $MIRROR torch torchvision
  "$PY" -m pip install $MIRROR -r "$REQ_TMP"
  "$PY" -m pip install $MIRROR gguf mistral-common
fi
rm -f "$REQ_TMP"

"$PY" - <<'EOF'
import torch, transformers, peft, accelerate
mps = getattr(torch.backends, "mps", None)
print("torch", torch.__version__)
print("transformers", transformers.__version__, "| peft", peft.__version__)
print("mps available:", bool(mps and mps.is_available()))
EOF
echo "完成。可以用 train.sh 开始训练。"
