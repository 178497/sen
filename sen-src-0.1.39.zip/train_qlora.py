"""Efficient 4-bit QLoRA fine-tuning for a local Chinese assistant."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path
from typing import Any

import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    DataCollatorForSeq2Seq,
    EarlyStoppingCallback,
    Trainer,
    TrainerCallback,
    TrainingArguments,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a Qwen QLoRA adapter.")
    parser.add_argument("--model", type=str, default="Qwen/Qwen3-1.7B")
    parser.add_argument("--data", type=Path, default=Path("data/train.jsonl"))
    parser.add_argument("--output", type=Path, default=Path("outputs/lora-adapter"))
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--epochs", type=float, default=2.0)
    parser.add_argument("--max-steps", type=int, default=-1)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--micro-batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation", type=int, default=16)
    parser.add_argument("--lora-rank", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--save-steps", type=int, default=50)
    parser.add_argument(
        "--pause-file",
        type=Path,
        default=None,
        help="Training stops and saves a checkpoint when this file appears.",
    )
    parser.add_argument(
        "--resume-from",
        type=str,
        default="",
        help="Checkpoint directory to resume training from.",
    )
    parser.add_argument("--logging-steps", type=int, default=10)
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        help="auto / cuda / mps（macOS 用 mps，需配合 --no-4bit）",
    )
    parser.add_argument(
        "--no-4bit",
        action="store_true",
        help="Use regular fp16/bf16 LoRA instead of 4-bit QLoRA.",
    )
    parser.add_argument(
        "--optim",
        choices=["paged_adamw_8bit", "adamw_torch_fused"],
        default="paged_adamw_8bit",
        help="Optimizer backend. Fused AdamW is faster for small LoRA tensors.",
    )
    parser.add_argument(
        "--gradient-checkpointing",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Trade compute for VRAM. Disable for ~25%% faster steps if VRAM allows.",
    )
    parser.add_argument(
        "--throttle",
        type=int,
        default=100,
        help="Duty cycle 10-100%%: fraction of free machine capacity to use.",
    )
    parser.add_argument(
        "--throttle-file",
        type=Path,
        default=None,
        help="Re-read the throttle percentage from this file every step.",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=0 if os.name == "nt" else 2,
        help="Dataloader worker processes (0 = load in the main process).",
    )
    return parser.parse_args()


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Training file does not exist: {path}")

    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(
                    f"Invalid JSON on line {line_number} of {path}: {error}"
                ) from error
            validate_row(row, line_number)
            rows.append(row)
    if not rows:
        raise ValueError(f"No training samples found in {path}")
    return rows


def validate_row(row: dict[str, Any], line_number: int) -> None:
    messages = row.get("messages")
    if not isinstance(messages, list) or len(messages) < 2:
        raise ValueError(f"Line {line_number}: messages must contain at least two turns")

    for message in messages:
        if not isinstance(message, dict):
            raise ValueError(f"Line {line_number}: each message must be an object")
        if message.get("role") not in {"system", "user", "assistant"}:
            raise ValueError(f"Line {line_number}: invalid message role")
        if not isinstance(message.get("content"), str) or not message["content"].strip():
            raise ValueError(f"Line {line_number}: message content cannot be empty")

    if messages[-1]["role"] != "assistant":
        raise ValueError(f"Line {line_number}: the final turn must be from assistant")
    if messages[-2]["role"] != "user":
        raise ValueError(f"Line {line_number}: assistant must follow a user turn")


def render_chat(
    tokenizer: AutoTokenizer,
    messages: list[dict[str, str]],
    add_generation_prompt: bool,
) -> str:
    kwargs = {
        "tokenize": False,
        "add_generation_prompt": add_generation_prompt,
        "enable_thinking": False,
    }
    try:
        return tokenizer.apply_chat_template(messages, **kwargs)
    except TypeError:
        kwargs.pop("enable_thinking")
        return tokenizer.apply_chat_template(messages, **kwargs)


class SenProgressCallback(TrainerCallback):
    def __init__(
        self,
        pause_file: Path | None = None,
        throttle: int = 100,
        throttle_file: Path | None = None,
    ) -> None:
        self.total_steps = 0
        self.latest_loss: float | None = None
        self.started_at = time.monotonic()
        self.pause_file = pause_file
        self.paused = False
        self.throttle = max(10, min(100, int(throttle)))
        self.throttle_file = throttle_file
        self._step_started = time.monotonic()

    def current_throttle(self) -> int:
        if self.throttle_file is not None:
            try:
                value = int(
                    self.throttle_file.read_text(encoding="utf-8").strip()
                )
                self.throttle = max(10, min(100, value))
            except (OSError, ValueError):
                pass
        return self.throttle

    def on_step_begin(
        self,
        args: TrainingArguments,
        state: Any,
        control: Any,
        **kwargs: Any,
    ) -> None:
        del args, state, control, kwargs
        self._step_started = time.monotonic()

    def emit(
        self,
        state: Any,
        stage: str,
        current_override: int | None = None,
    ) -> None:
        current = int(
            current_override
            if current_override is not None
            else state.global_step or 0
        )
        total = int(self.total_steps or 0)
        elapsed = max(0.0, time.monotonic() - self.started_at)
        percent = min(100.0, 100.0 * current / total) if total else 0.0
        eta = (
            elapsed * (total - current) / current
            if current > 0 and total > current
            else 0.0
        )
        payload = {
            "type": "sen_progress",
            "stage": stage,
            "step": current,
            "total_steps": total,
            "percent": round(percent, 2),
            "loss": self.latest_loss,
            "elapsed_seconds": round(elapsed, 1),
            "eta_seconds": round(eta, 1),
            "throttle": self.current_throttle(),
        }
        print("SEN_EVENT " + json.dumps(payload), flush=True)

    def on_train_begin(
        self,
        args: TrainingArguments,
        state: Any,
        control: Any,
        **kwargs: Any,
    ) -> None:
        del args, control, kwargs
        self.total_steps = int(state.max_steps or 0)
        self.started_at = time.monotonic()
        self.emit(state, "training")

    def on_log(
        self,
        args: TrainingArguments,
        state: Any,
        control: Any,
        logs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        del args, control, kwargs
        if logs and logs.get("loss") is not None:
            self.latest_loss = float(logs["loss"])
            self.emit(state, "training")

    def on_step_end(
        self,
        args: TrainingArguments,
        state: Any,
        control: Any,
        **kwargs: Any,
    ) -> None:
        del args, kwargs
        if self.pause_file is not None and self.pause_file.exists():
            try:
                self.pause_file.unlink()
            except OSError:
                pass
            self.paused = True
            control.should_save = True
            control.should_training_stop = True
            print("SEN_PAUSE_REQUESTED", flush=True)
        self.emit(state, "training")
        throttle = self.current_throttle()
        if throttle < 100:
            elapsed = max(0.001, time.monotonic() - self._step_started)
            idle_for = elapsed * (100.0 / throttle - 1.0)
            if idle_for > 0.002:
                time.sleep(min(idle_for, 30.0))

    def on_train_end(
        self,
        args: TrainingArguments,
        state: Any,
        control: Any,
        **kwargs: Any,
    ) -> None:
        del args, control, kwargs
        if self.paused:
            self.emit(state, "paused")
        else:
            self.emit(
                state,
                "training_complete",
                current_override=self.total_steps,
            )


def main() -> None:
    args = parse_args()
    device = args.device
    if device == "auto":
        if torch.cuda.is_available():
            device = "cuda"
        elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            device = "mps"
        else:
            device = "cpu"
    if device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA is not available. Run check_env.py first.")
    if device == "mps" and not (getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()):
        raise SystemExit("MPS is not available on this machine.")
    if device == "cpu":
        raise SystemExit(
            "CPU training is not supported (too slow). Use a CUDA GPU, or an Apple Silicon Mac."
        )
    print(f"Training device: {device}")
    if args.max_length < 128:
        raise ValueError("--max-length must be at least 128")

    if device == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    if args.throttle < 100:
        try:
            import ctypes

            BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
            handle = ctypes.windll.kernel32.GetCurrentProcess()
            ctypes.windll.kernel32.SetPriorityClass(
                handle, BELOW_NORMAL_PRIORITY_CLASS
            )
        except Exception:
            pass
        torch.set_num_threads(max(1, (os.cpu_count() or 4) // 2))
    torch.manual_seed(args.seed)
    rows = load_jsonl(args.data)
    print(f"Loaded {len(rows)} training samples from {args.data}")

    tokenizer = AutoTokenizer.from_pretrained(
        args.model,
        use_fast=True,
        trust_remote_code=True,
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    quantization_config = None
    if device != "cuda" and not args.no_4bit:
        print("4-bit quantization needs CUDA; falling back to fp16 LoRA (--no-4bit).")
        args.no_4bit = True
    if not args.no_4bit:
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
        )

    print(f"Loading model: {args.model}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        quantization_config=quantization_config,
        torch_dtype=torch.float16 if device == "mps" else torch.bfloat16,
        device_map="auto" if device == "cuda" else None,
        trust_remote_code=True,
        attn_implementation="sdpa",
    )
    model.config.use_cache = False

    if not args.no_4bit:
        model = prepare_model_for_kbit_training(
            model,
            use_gradient_checkpointing=args.gradient_checkpointing,
        )
    elif args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    lora_config = LoraConfig(
        task_type="CAUSAL_LM",
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    def tokenize_example(example: dict[str, Any]) -> dict[str, list[int]]:
        messages = example["messages"]
        prompt_messages = messages[:-1]
        answer = messages[-1]["content"].strip()
        prompt_text = render_chat(tokenizer, prompt_messages, True)
        if tokenizer.eos_token_id is None:
            raise ValueError("Tokenizer must define an EOS token")

        answer_ids = tokenizer(
            answer,
            add_special_tokens=False,
        )["input_ids"]
        max_answer_length = max(1, args.max_length - 8)
        answer_ids = answer_ids[:max_answer_length]
        if not answer_ids or answer_ids[-1] != tokenizer.eos_token_id:
            if len(answer_ids) >= max_answer_length:
                answer_ids[-1] = tokenizer.eos_token_id
            else:
                answer_ids.append(tokenizer.eos_token_id)

        prompt_ids = tokenizer(
            prompt_text,
            add_special_tokens=False,
        )["input_ids"]
        prompt_budget = max(1, args.max_length - len(answer_ids))
        if len(prompt_ids) > prompt_budget:
            # Keep the end of the chat template, including the assistant marker.
            prompt_ids = prompt_ids[-prompt_budget:]

        input_ids = prompt_ids + answer_ids
        labels = list(input_ids)
        prompt_length = len(prompt_ids)
        labels[:prompt_length] = [-100] * prompt_length

        if all(label == -100 for label in labels):
            raise ValueError(
                "A sample has no supervised answer tokens. "
                "Increase --max-length or shorten its prompt."
            )
        return {
            "input_ids": input_ids,
            "attention_mask": [1] * len(input_ids),
            "labels": labels,
            "length": len(input_ids),
        }

    raw_dataset = Dataset.from_list(rows)
    eval_dataset = None
    val_samples = 0
    if len(rows) >= 20 and args.val_ratio > 0:
        split = raw_dataset.train_test_split(
            test_size=args.val_ratio,
            seed=args.seed,
        )
        training_rows = split["train"]
        validation_rows = split["test"]
        val_samples = len(validation_rows)
    else:
        training_rows = raw_dataset
        validation_rows = None

    tokenized_dataset = training_rows.map(
        tokenize_example,
        remove_columns=training_rows.column_names,
        desc="Tokenizing and masking user prompts",
    )
    if validation_rows is not None:
        eval_dataset = validation_rows.map(
            tokenize_example,
            remove_columns=validation_rows.column_names,
            desc="Tokenizing validation data",
        )

    bf16_supported = torch.cuda.is_bf16_supported()
    training_arguments = TrainingArguments(
        output_dir=str(args.output / "checkpoints"),
        num_train_epochs=args.epochs,
        max_steps=args.max_steps,
        per_device_train_batch_size=args.micro_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation,
        learning_rate=args.learning_rate,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        logging_steps=args.logging_steps,
        save_steps=args.save_steps,
        save_total_limit=2,
        bf16=bf16_supported,
        fp16=not bf16_supported,
        gradient_checkpointing=args.gradient_checkpointing,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        optim=args.optim,
        max_grad_norm=1.0,
        report_to="none",
        remove_unused_columns=False,
        dataloader_num_workers=max(0, args.num_workers),
        dataloader_persistent_workers=args.num_workers > 0,
        dataloader_pin_memory=True,
        group_by_length=True,
        eval_strategy="steps" if eval_dataset is not None else "no",
        eval_steps=args.save_steps if eval_dataset is not None else None,
        save_strategy="steps",
        load_best_model_at_end=eval_dataset is not None,
        metric_for_best_model="eval_loss" if eval_dataset is not None else None,
        greater_is_better=False,
        seed=args.seed,
        data_seed=args.seed,
    )

    data_collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        padding=True,
        label_pad_token_id=-100,
        return_tensors="pt",
    )
    trainer = Trainer(
        model=model,
        args=training_arguments,
        train_dataset=tokenized_dataset,
        eval_dataset=eval_dataset,
        data_collator=data_collator,
        processing_class=tokenizer,
    )
    progress_callback = SenProgressCallback(
        args.pause_file,
        throttle=args.throttle,
        throttle_file=args.throttle_file,
    )
    trainer.add_callback(progress_callback)
    if eval_dataset is not None:
        trainer.add_callback(
            EarlyStoppingCallback(early_stopping_patience=2)
        )

    print(
        "Starting training with "
        f"effective batch size {args.micro_batch_size * args.gradient_accumulation}"
    )
    trainer.train(resume_from_checkpoint=args.resume_from or None)
    print(
        (
            f"Peak GPU memory: {torch.cuda.max_memory_allocated() / 1024 ** 3:.2f} GiB"
            if device == "cuda"
            else f"Training device: {device}"
        ),
        flush=True,
    )
    if progress_callback.paused:
        print(
            "Training paused at step "
            f"{trainer.state.global_step}; checkpoint saved for resume.",
            flush=True,
        )
        return
    args.output.mkdir(parents=True, exist_ok=True)
    trainer.save_model(str(args.output))
    tokenizer.save_pretrained(str(args.output))

    summary = {
        "base_model": args.model,
        "samples": len(rows),
        "validation_samples": val_samples,
        "max_length": args.max_length,
        "lora_rank": args.lora_rank,
        "quantized_training": not args.no_4bit,
        "output": str(args.output),
    }
    (args.output / "training_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Adapter saved to {args.output}")


if __name__ == "__main__":
    main()
