param()

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Resolve-Python {
    $knownPath = Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"
    if (Test-Path -LiteralPath $knownPath) {
        return $knownPath
    }

    $command = Get-Command python -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        return $command.Source
    }

    throw "Python was not found. Install Python 3.11 or newer and add it to PATH."
}

$python = Resolve-Python
& $python -m venv .venv-train
if ($LASTEXITCODE -ne 0) {
    throw "Could not create .venv-train."
}

$venvPython = Join-Path $PSScriptRoot ".venv-train\Scripts\python.exe"
& $venvPython -m pip install --upgrade pip

Write-Host "Installing CUDA 12.8 PyTorch..."
& $venvPython -m pip install --index-url https://download.pytorch.org/whl/cu128 "torch>=2.7.0"
if ($LASTEXITCODE -ne 0) {
    throw "CUDA PyTorch installation failed."
}

Write-Host "Installing the remaining training dependencies..."
& $venvPython -m pip install -r requirements-train.txt
if ($LASTEXITCODE -ne 0) {
    throw "Training dependency installation failed."
}

& $venvPython check_env.py
if ($LASTEXITCODE -ne 0) {
    throw "Environment verification failed."
}
