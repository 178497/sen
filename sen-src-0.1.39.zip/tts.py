"""朗读：优先用微软神经语音（自然），失败时由前端回退到系统语音。"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import threading
from pathlib import Path

try:
    import edge_tts
except Exception:  # noqa: BLE001
    edge_tts = None


VOICES = [
    ("zh-CN-XiaoxiaoNeural", "晓晓 · 女声"),
    ("zh-CN-YunxiNeural", "云希 · 男声"),
    ("zh-CN-YunjianNeural", "云健 · 男声沉稳"),
    ("zh-CN-XiaoyiNeural", "晓伊 · 女声活泼"),
    ("zh-CN-YunyangNeural", "云扬 · 男声播报"),
    ("zh-CN-liaoning-XiaobeiNeural", "晓北 · 东北口音"),
    ("zh-CN-shaanxi-XiaoniNeural", "晓妮 · 陕西口音"),
]
DEFAULT_VOICE = VOICES[0][0]


def available() -> bool:
    return edge_tts is not None


def voices() -> list[dict]:
    return [{"id": key, "label": label} for key, label in VOICES]


def _cache_dir(cache_root: Path) -> Path:
    path = cache_root / "tts"
    path.mkdir(parents=True, exist_ok=True)
    return path


async def _stream(text: str, voice: str, rate: str) -> bytes:
    communicate = edge_tts.Communicate(text, voice, rate=rate)
    buffer = bytearray()
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            buffer.extend(chunk["data"])
    return bytes(buffer)


def synthesize(
    text: str,
    voice: str = DEFAULT_VOICE,
    rate: str = "+0%",
    cache_root: Path | None = None,
) -> bytes:
    """把文字合成为 mp3 字节；同一段文字会命中缓存。"""
    if edge_tts is None:
        raise RuntimeError("edge-tts 不可用")

    clean = " ".join((text or "").split())
    if not clean:
        return b""
    if len(clean) > 400:
        clean = clean[:400]

    if voice not in {key for key, _ in VOICES}:
        voice = DEFAULT_VOICE

    digest = hashlib.sha1(f"{voice}|{rate}|{clean}".encode("utf-8")).hexdigest()
    cache_path = _cache_dir(cache_root).joinpath(digest + ".mp3") if cache_root else None
    if cache_path and cache_path.is_file():
        return cache_path.read_bytes()

    audio = _run_async(_stream(clean, voice, rate))
    if cache_path and audio:
        try:
            cache_path.write_bytes(audio)
        except OSError:
            pass
    return audio


def _run_async(coro):
    """在可能已有事件循环的线程里安全地跑协程。"""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    result: dict = {}

    def runner():
        try:
            result["value"] = asyncio.run(coro)
        except Exception as error:  # noqa: BLE001
            result["error"] = error

    thread = threading.Thread(target=runner)
    thread.start()
    thread.join()
    if "error" in result:
        raise result["error"]
    return result["value"]


def synthesize_data_url(
    text: str,
    voice: str = DEFAULT_VOICE,
    cache_root: Path | None = None,
) -> str:
    audio = synthesize(text, voice, cache_root=cache_root)
    if not audio:
        return ""
    return "data:audio/mpeg;base64," + base64.b64encode(audio).decode("ascii")
