#!/bin/bash
# 在 macOS 上构建森的 .app 并打成可分发的 zip。
# 用法：./release/build_mac.sh 0.1.27
set -euo pipefail

VERSION="${1:-0.0.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "==> 版本 $VERSION"
echo "==> 架构 $(uname -m) / $(sw_vers -productVersion 2>/dev/null || echo macOS)"
if [ "$(uname -m)" = "x86_64" ]; then
  echo "  提示：Intel Mac 上能构建，但本地模型推理会很慢"
fi

# 优先用 3.12（pyobjc / PyInstaller 在它上面最稳），其次 3.11 / 3.13 / 3.10
PY_BIN=""
for candidate in python3.12 python3.11 python3.13 python3.10 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    ver="$("$candidate" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
    case "$ver" in
      3.1[0-3]) PY_BIN="$candidate"; break ;;
    esac
  fi
done
if [ -z "$PY_BIN" ]; then
  echo "需要 Python 3.10-3.13，没找到可用的 python3。" >&2
  echo "安装：https://www.python.org/downloads/macos/" >&2
  exit 1
fi
echo "==> 使用 $PY_BIN ($("$PY_BIN" -c 'import sys;print(sys.version.split()[0])'))"

ARCH="$("$PY_BIN" -c 'import platform;print(platform.machine())')"
if [ "$ARCH" != "$(uname -m)" ]; then
  echo "  ! 解释器架构是 $ARCH，系统是 $(uname -m)"
  echo "    （Rosetta 下构建会产出不匹配的包，建议用原生 python3）"
fi

if ! xcode-select -p >/dev/null 2>&1; then
  echo "提示：没有检测到 Xcode Command Line Tools，venv 可能创建失败。"
  echo "      执行 xcode-select --install 后重试。"
  echo
fi

# 1. 虚拟环境（首次）
if [ ! -d ".venv-mac" ]; then
  echo "==> 创建 .venv-mac"
  "$PY_BIN" -m venv .venv-mac || {
    echo "创建 venv 失败。请确认已安装 Command Line Tools：xcode-select --install" >&2
    exit 1
  }
fi
# shellcheck disable=SC1091
source .venv-mac/bin/activate

# 2. 依赖
echo "==> 安装依赖"
python -m pip install --upgrade pip >/dev/null
install_deps() {
  python -m pip install -r requirements-desktop.txt && python -m pip install "pyinstaller==6.16.0"
}
if ! install_deps; then
  echo "==> 直连 PyPI 失败，改用清华镜像重试"
  python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements-desktop.txt
  python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple "pyinstaller==6.16.0"
fi

# 3. 版本号与更新地址
printf '%s\n' "$VERSION" > VERSION
cat > update_url.txt <<EOF
https://178497.github.io/sen/latest.json
https://178497.github.io/sen/manifest/latest.json
https://raw.githubusercontent.com/178497/sen/main/latest.json
EOF

# 4. 图标（png -> icns）
if [ -f "static/assistant-256.png" ] && [ ! -f "static/assistant.icns" ]; then
  echo "==> 生成 icns"
  ICONSET="build/assistant.iconset"
  mkdir -p "$ICONSET"
  for size in 16 32 64 128 256 512; do
    sips -z $size $size static/assistant-256.png --out "$ICONSET/icon_${size}x${size}.png" >/dev/null
    double=$((size * 2))
    sips -z $double $double static/assistant-256.png --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o static/assistant.icns
fi

# 5. 打包
echo "==> PyInstaller"
rm -rf build dist
python -m PyInstaller sen_mac.spec --noconfirm --clean --log-level=WARN || {
  echo "PyInstaller 失败，完整日志见 build/Sen/warn-Sen.txt" >&2
  exit 1
}

if [ ! -d "dist/Sen.app" ]; then
  echo "打包失败：没有生成 dist/Sen.app" >&2
  exit 1
fi

# 6. 自检：外部脚本是否都进包（BUNDLE 的目录布局可能变，直接全盘找文件名）
MISSING=0
for f in train.sh setup_train.sh select_model.py check_env.py merge_adapter.py \
         image_worker.py train_qlora.py prepare_oneclick_data.py; do
  if ! find dist/Sen.app -name "$f" -print -quit 2>/dev/null | grep -q .; then
    echo "  ! 缺少 $f"
    MISSING=1
  fi
done
if [ "$MISSING" = "1" ]; then
  echo "打包不完整，请检查 sen_mac.spec 的 datas" >&2
  exit 1
fi
echo "  外部脚本齐全"

if [ ! -x "dist/Sen.app/Contents/MacOS/Sen" ]; then
  echo "  ! 可执行文件缺失或不可执行" >&2
  ls -la "dist/Sen.app/Contents/MacOS" || true
  exit 1
fi
echo "  可执行文件就绪"

# 7. ad-hoc 签名（不公证，用户首次需右键打开）
echo "==> ad-hoc 签名"
if codesign --force --deep --sign - dist/Sen.app; then
  codesign --verify --deep --strict dist/Sen.app && echo "  签名校验通过"
else
  echo "  ! 签名失败，仍可手动右键打开"
fi

# 8. 打 zip
NAME="Sen-macOS-$VERSION.zip"
rm -f "release/$NAME"
ditto -c -k --sequesterRsrc --keepParent dist/Sen.app "release/$NAME"
echo "==> 完成：release/$NAME ($(du -h "release/$NAME" | cut -f1))"
