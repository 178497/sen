"""一键发布：打包 → 计算校验值 → 生成 latest.json → 汇总到 release/upload。

用法：
    python release/build_release.py --version 0.1.1
    python release/build_release.py --version 0.1.1 --skip-build
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import time
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RELEASE = ROOT / "release"
UPLOAD = RELEASE / "upload"
DEFAULT_BASE = "https://cdn.jsdelivr.net/gh/YOURNAME/sen@main/release/upload"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def mb(path: Path) -> float:
    return round(path.stat().st_size / (1024 * 1024), 1)



def verify_external_scripts() -> list[str]:
    """检查被 subprocess 以文件方式调用的脚本是否真的打进了 dist。"""
    import re as _re

    pattern = _re.compile(r'base_dir / "([A-Za-z0-9_]+\.(?:py|ps1|sh|command))"')
    referenced: set[str] = set()
    for source in ROOT.glob("*.py"):
        try:
            text = source.read_text(encoding="utf-8")
        except OSError:
            continue
        referenced.update(pattern.findall(text))

    internal = ROOT / "dist" / "Sen" / "_internal"
    missing = []
    for name in sorted(referenced):
        if not (ROOT / name).exists():
            continue  # 源码里没有，说明是可选脚本
        if not (internal / name).exists():
            missing.append(name)
    return missing


def copy_with_retry(src: Path, dst: Path, attempts: int = 6) -> bool:
    """文件被占用时（预览窗口/杀软）重试几次。"""
    for attempt in range(attempts):
        try:
            shutil.copy2(src, dst)
            return True
        except (PermissionError, OSError):
            time.sleep(1.5 * (attempt + 1))
    print(f"  ! 跳过（文件被占用）: {src.name}")
    return False


def run(cmd: list[str]) -> None:
    print("  $", " ".join(cmd))
    subprocess.run(cmd, cwd=str(ROOT), check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", default="0.1.0")
    parser.add_argument("--base-url", default=DEFAULT_BASE)
    parser.add_argument("--skip-build", action="store_true")
    parser.add_argument("--notes", default="更新说明请在这里填写。")
    args = parser.parse_args()

    python = ROOT / ".venv-desktop" / "Scripts" / "python.exe"
    iscc = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Inno Setup 6" / "ISCC.exe"

    UPLOAD.mkdir(parents=True, exist_ok=True)

    (ROOT / "VERSION").write_text(args.version + chr(10), encoding="utf-8")

    if not args.skip_build:
        print("[1/4] 编译程序…")
        run([str(python), "-m", "PyInstaller", "--noconfirm", "sen.spec"])
        missing = verify_external_scripts()
        if missing:
            print("  ! 以下脚本没被打进 dist，运行时会报“文件不存在”：")
            for name in missing:
                print(f"    - {name}")
            raise SystemExit("打包不完整，请在 sen.spec 的 datas 里补上这些脚本")

        print("[2/4] 写入更新地址并编译安装包…")
        dist_dir = ROOT / "dist" / "Sen"
        if dist_dir.exists():
            # 多源：CDN 优先，raw 与 Release 资产兜底（0.1.1+ 的 updater 支持逐行读取）
            urls = [
                "https://178497.github.io/sen/latest.json",
                "https://raw.githubusercontent.com/178497/sen/main/latest.json",
                "https://github.com/178497/sen/releases/download/manifest/latest.json",
            ]
            (dist_dir / "update_url.txt").write_text(
                chr(10).join(urls) + chr(10), encoding="utf-8"
            )
        run([str(iscc), f"/DAppVersion={args.version}", "installer.iss"])
        print("[3/4] 打包便携版…")
        portable = RELEASE / f"Sen-{args.version}-portable.zip"
        portable.unlink(missing_ok=True)
        shutil.make_archive(
            str(portable.with_suffix("")), "zip", root_dir=str(ROOT / "dist" / "Sen")
        )

    print("[4/4] 计算校验值并生成清单…")
    setups = sorted(RELEASE.glob("Sen-Setup-*.exe"), key=lambda p: p.stat().st_mtime)
    if not setups:
        print("错误：release 目录里没有安装包，请先构建。", file=sys.stderr)
        return 1
    setup = setups[-1]
    portable = RELEASE / f"Sen-{args.version}-portable.zip"
    if not portable.exists():
        print(f"错误：找不到便携版 {portable.name}", file=sys.stderr)
        return 1

    manifest_path = RELEASE / "latest.json"
    previous: dict = {}
    if manifest_path.exists():
        try:
            previous = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            previous = {}

    manifest = {
        "version": args.version,
        "channel": "beta",
        "url": f"{args.base_url}/{setup.name}",
        "sha256": sha256(setup),
        "size_mb": mb(setup),
        "portable_url": f"{args.base_url}/{portable.name}",
        "portable_sha256": sha256(portable),
        "portable_size_mb": mb(portable),
        "min_version": "0.1.0",
        "notes": args.notes,
    }
    # 保留上一版的 macOS 字段：这些不在 build_release 的固定字段里，不带着走会被重置
    for key, value in previous.items():
        if key.startswith("macos_") and key not in manifest:
            manifest[key] = value
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    for stale in UPLOAD.iterdir():
        if stale.is_file():
            stale.unlink()

    # 演示版：把界面和静态资源一起发布，供网页在线体验
    demo_dir = UPLOAD / "demo"
    shutil.rmtree(demo_dir, ignore_errors=True)
    demo_dir.mkdir(parents=True, exist_ok=True)
    static_dir = ROOT / "static"
    copy_with_retry(static_dir / "index.html", demo_dir / "index.html")
    for name in ("assistant-icon.svg", "assistant-256.png"):
        if (static_dir / name).exists():
            copy_with_retry(static_dir / name, demo_dir / name)
    cursors_src = static_dir / "cursors"
    if cursors_src.is_dir():
        shutil.copytree(cursors_src, demo_dir / "cursors", dirs_exist_ok=True)

    changelog_path = ROOT / "release" / "changelog.json"
    if changelog_path.exists():
        copy_with_retry(changelog_path, UPLOAD / "changelog.json")

    for item in (setup, portable, manifest_path, ROOT / "site" / "index.html",
                 UPLOAD / "changelog.json"):
        if item.exists():
            copy_with_retry(item, UPLOAD / item.name)

    print()
    print(f"完成：{UPLOAD}")
    print(f"  安装包 {setup.name}  {mb(setup)} MB")
    print(f"  便携版 {portable.name}  {mb(portable)} MB")
    print(f"  清单   latest.json → {manifest['url']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
