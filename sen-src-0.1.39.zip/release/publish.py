"""把 release/upload 发布到 GitHub。

策略：
  - 安装包、便携版等大文件 → GitHub Releases（二进制直传，快且稳定）
  - latest.json、index.html  → 仓库内容（jsDelivr 可直出，国内访问快）

只需要一个 GitHub Personal Access Token（scope: repo）。

用法：
    python release/publish.py
    python release/publish.py --rebuild      # 先用真实地址重新打包再发布
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
UPLOAD = ROOT / "release" / "upload"
API = "https://api.github.com"
UPLOADS = "https://uploads.github.com"
BRANCH = "main"
LARGE_LIMIT = 1_000_000  # 大于 1 MB 走 Release


def request(
    token: str,
    method: str,
    url: str,
    payload=None,
    raw: bytes | None = None,
    content_type: str = "application/json",
) -> tuple[int, dict | list | None]:
    """所有 GitHub 调用都走 curl：urllib 在弱网下会长时间挂住。"""
    full = url if url.startswith("http") else f"{API}{url}"
    curl = shutil.which("curl") or "curl.exe"
    command = [
        curl, "-s", "-X", method,
        "-H", f"Authorization: token {token}",
        "-H", "Accept: application/vnd.github+json",
        "-H", "User-Agent: Sen-Publisher",
        "--max-time", "120",
        "-w", chr(10) + "%{http_code}",
    ]
    # 请求体走临时文件：Windows 命令行有 32 KB 上限，base64 会超
    temp_path = None
    body = raw if raw is not None else (json.dumps(payload).encode("utf-8") if payload is not None else None)
    if body is not None:
        import tempfile

        handle = tempfile.NamedTemporaryFile(delete=False, suffix=".bin")
        handle.write(body)
        handle.close()
        temp_path = handle.name
        mime = content_type if raw is not None else "application/json"
        command += ["-H", f"Content-Type: {mime}", "--data-binary", "@" + temp_path]
    command.append(full)
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=180,
        )
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass
    body, _, code = result.stdout.rpartition(chr(10))
    try:
        status = int(code.strip() or 0)
    except ValueError:
        status = 0
    try:
        parsed = json.loads(body) if body.strip() else None
    except json.JSONDecodeError:
        parsed = {"message": body[:300]}
    return status, parsed


def load_token(explicit: str | None) -> str:
    if explicit:
        return explicit.strip()
    env = os.getenv("GITHUB_TOKEN", "").strip()
    if env:
        return env
    token_file = Path.home() / ".sen-gh-token"
    if token_file.is_file():
        return token_file.read_text(encoding="utf-8").strip()
    return ""


def sha256_file(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_version() -> str:
    manifest = ROOT / "release" / "latest.json"
    try:
        return str(json.loads(manifest.read_text(encoding="utf-8"))["version"])
    except Exception:
        return "0.0.0"


def content_sha(token: str, owner: str, repo: str, path: str) -> str | None:
    status, data = request(token, "GET", f"/repos/{owner}/{repo}/contents/{path}?ref={BRANCH}")
    if status == 200 and isinstance(data, dict):
        return str(data.get("sha") or "") or None
    return None


def upload_small(token: str, owner: str, repo: str, path: Path, remote: str = "") -> bool:
    payload = {
        "message": f"release: {path.name}",
        "content": base64.b64encode(path.read_bytes()).decode("ascii"),
        "branch": BRANCH,
    }
    remote = remote or path.name
    sha = content_sha(token, owner, repo, remote)
    if sha:
        payload["sha"] = sha
    status, data = request(token, "PUT", f"/repos/{owner}/{repo}/contents/{remote}", payload)
    ok = status in (200, 201)
    print(f"  {'OK  ' if ok else 'FAIL'} {remote}" + ("" if ok else f"  {status} {data}"))
    return ok


def ensure_release(token: str, owner: str, repo: str, version: str) -> int | None:
    tag = f"v{version}"
    status, release = request(token, "GET", f"/repos/{owner}/{repo}/releases/tags/{tag}")
    if status == 200 and isinstance(release, dict):
        return int(release["id"])
    status, release = request(
        token,
        "POST",
        f"/repos/{owner}/{repo}/releases",
        {
            "tag_name": tag,
            "name": f"森 {version}",
            "body": "自动发布。",
            "draft": False,
            "prerelease": False,
        },
    )
    if status in (200, 201) and isinstance(release, dict):
        return int(release["id"])
    print(f"  FAIL 创建 release: {status} {release}")
    return None


def upload_asset(token: str, owner: str, repo: str, release_id: int, path: Path) -> str | None:
    status, existing = request(
        token, "GET", f"/repos/{owner}/{repo}/releases/{release_id}/assets?per_page=100"
    )
    if status == 200 and isinstance(existing, list):
        for asset in existing:
            if asset.get("name") == path.name and asset.get("state") == "uploaded":
                print(f"  SKIP {path.name}（已存在）")
                return str(asset.get("browser_download_url") or "")

    # urllib 在部分网络下会长时间卡住，改用系统自带的 curl
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    curl = shutil.which("curl") or "curl.exe"
    url = (
        f"{UPLOADS}/repos/{owner}/{repo}/releases/{release_id}/assets"
        f"?name={urllib.parse.quote(path.name)}"
    )
    command = [
        curl, "-s", "-X", "POST",
        "-H", f"Authorization: token {token}",
        "-H", f"Content-Type: {mime}",
        "--data-binary", f"@{path}",
        "--max-time", "300",
        "-w", chr(10) + "%{http_code}",
        url,
    ]
    body = ""
    code = ""
    result = None
    for attempt in range(3):
        result = subprocess.run(command, capture_output=True, text=True, timeout=360)
        body, _, code = result.stdout.rpartition(chr(10))
        if code.strip() in ("200", "201"):
            break
        print(f"  重试 {path.name}（第 {attempt + 1} 次失败，code={code.strip() or 'timeout'}）")
    if code.strip() in ("200", "201"):
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            data = {}
        print(f"  OK   {path.name}  ({round(path.stat().st_size / 1048576, 1)} MB)")
        return str(data.get("browser_download_url") or "")
    print(f"  FAIL {path.name}: {code.strip()} {body[:200]} {result.stderr[:200]}")
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token", default=None)
    parser.add_argument("--repo", default="sen")
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    version = read_version()

    def relevant(path: Path) -> bool:
        if path.suffix in {".json", ".html"}:
            return True
        return version in path.name

    files = sorted((p for p in UPLOAD.glob("*") if p.is_file() and relevant(p)),
                   key=lambda item: (item.suffix in {".json", ".html"}, item.name))
    if not files:
        print("错误：release/upload 是空的，先运行 build_release.py")
        return 1

    token = load_token(args.token)
    if not token:
        print("需要一个 GitHub Token（scope: repo），存到 %USERPROFILE%\\.sen-gh-token")
        return 2

    status, user = request(token, "GET", "/user")
    if status != 200 or not isinstance(user, dict):
        print(f"Token 无效：{status} {user}")
        return 3
    owner = user["login"]
    print(f"账号：{owner}")

    status, repo = request(token, "GET", f"/repos/{owner}/{args.repo}")
    if status == 404:
        print(f"创建仓库 {args.repo}…")
        status, repo = request(
            token,
            "POST",
            "/user/repos",
            {
                "name": args.repo,
                "description": "森 · 本地 AI 助手 发行文件",
                "private": False,
                "auto_init": True,
            },
        )
        if status not in (200, 201):
            print(f"创建失败：{status} {repo}")
            return 4

    cdn = f"https://cdn.jsdelivr.net/gh/{owner}/{args.repo}@{BRANCH}"

    if args.rebuild:
        print("用真实地址重新打包…")
        import subprocess

        subprocess.run(
            [
                sys.executable,
                str(ROOT / "release" / "build_release.py"),
                "--version",
                version,
                "--base-url",
                cdn,
            ],
            cwd=str(ROOT),
            check=True,
        )
        files = sorted(p for p in UPLOAD.glob("*") if p.is_file())

    if args.dry_run:
        for item in files:
            print(f"  {item.name}  {round(item.stat().st_size / 1048576, 1)} MB")
        return 0

    release_id = ensure_release(token, owner, args.repo, version)
    if release_id is None:
        return 5

    asset_urls: dict[str, str] = {}
    print("上传大文件（Releases）…")
    failed = 0
    for item in files:
        if item.stat().st_size >= LARGE_LIMIT:
            url = upload_asset(token, owner, args.repo, release_id, item)
            if url:
                asset_urls[item.name] = url
            else:
                failed += 1

    # jsDelivr 会拦截 .exe，改成 zip 放仓库
    import zipfile

    setup_asset = None
    for item in files:
        if item.suffix.lower() == ".exe" and version in item.name:
            setup_asset = item
            break
    setup_zip_url = ""
    setup_zip = None
    if setup_asset is not None:
        setup_zip = setup_asset.with_suffix(".zip")
        with zipfile.ZipFile(setup_zip, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(setup_asset, setup_asset.name)
        print(f"打包 {setup_zip.name} ({round(setup_zip.stat().st_size / 1048576, 1)} MB)")
        if upload_small(token, owner, args.repo, setup_zip):
            setup_zip_url = f"{cdn}/{setup_zip.name}"

    manifest_path = ROOT / "release" / "latest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if setup_zip_url:
        # url 保持 GitHub 安装包（兼容 0.1.1 及更早版本的更新器）
        manifest["url"] = asset_urls.get(setup_asset.name, manifest.get("url", ""))
        manifest["sha256"] = sha256_file(setup_asset)
        # 新版本优先用 CDN 上的 zip（jsDelivr 只放行 zip）
        manifest["url_zip"] = setup_zip_url
        manifest["url_zip_pages"] = f"https://{owner}.github.io/{args.repo}/{setup_zip.name}"
        manifest["zip_sha256"] = sha256_file(setup_zip)
    manifest["update_url"] = f"{cdn}/latest.json"
    notes_text = str(manifest.get("notes") or "")
    manifest["highlights"] = [part.strip() for part in re.split(r"[；;]", notes_text) if part.strip()]
    for key in ("url", "portable_url", "macos_url", "macos_command_url"):
        name = Path(manifest.get(key, "")).name
        if name in asset_urls:
            manifest[key] = asset_urls[name]
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (UPLOAD / "latest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # 备用更新源：把 latest.json 也挂到固定 tag 的 release 上
    print("上传备用清单（release: manifest）…")
    status, manifest_release = request(token, "GET", f"/repos/{owner}/{args.repo}/releases/tags/manifest")
    if status != 200:
        status, manifest_release = request(
            token, "POST", f"/repos/{owner}/{args.repo}/releases",
            {"tag_name": "manifest", "name": "更新清单镜像", "body": "备用更新源，勿删。",
             "draft": False, "prerelease": False},
        )
    if isinstance(manifest_release, dict) and manifest_release.get("id"):
        rel_id = int(manifest_release["id"])
        for asset in manifest_release.get("assets") or []:
            if asset.get("name") == "latest.json":
                request(token, "DELETE", f"/repos/{owner}/{args.repo}/releases/assets/{asset['id']}")
        upload_asset(token, owner, args.repo, rel_id, UPLOAD / "latest.json")

    print("上传小文件（仓库）…")
    for item in files:
        if item.stat().st_size < LARGE_LIMIT:
            if not upload_small(token, owner, args.repo, item):
                failed += 1

    # 备用清单路径：某些镜像/CDN 只缓存根路径时还能兜底
    manifest_copy = UPLOAD / "latest.json"
    if manifest_copy.is_file() and not upload_small(
        token, owner, args.repo, manifest_copy, "manifest/latest.json"
    ):
        failed += 1
        print("  ! manifest/latest.json 上传失败，备用更新源会停在旧版本")

    # 更新日志：保证当前版本有一条记录
    changelog_path = UPLOAD / "changelog.json"
    if changelog_path.is_file():
        try:
            entries = json.loads(changelog_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            entries = []
        if not any(entry.get("version") == version for entry in entries):
            entries.insert(0, {
                "version": version,
                "date": time.strftime("%Y-%m-%d"),
                "highlights": manifest.get("highlights") or [],
            })
            changelog_path.write_text(
                json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        upload_small(token, owner, args.repo, changelog_path, "changelog.json")

    # 在线体验页（demo/ 目录）与更新日志
    demo_root = UPLOAD / "demo"
    if demo_root.is_dir():
        print("上传在线体验页…")
        for path in sorted(demo_root.rglob("*")):
            if path.is_file():
                relative = path.relative_to(demo_root).as_posix()
                upload_small(token, owner, args.repo, path, f"demo/{relative}")

    url_file = Path(os.getenv("LOCALAPPDATA", "")) / "Sen" / "update_url.txt"
    url_file.parent.mkdir(parents=True, exist_ok=True)
    url_file.write_text(f"{cdn}/latest.json", encoding="utf-8")

    # 清掉 CDN 缓存，否则 latest.json 可能还指向上一版
    purge = shutil.which("curl") or "curl.exe"
    for name in ("latest.json", "index.html", Path(manifest.get("url_zip", "")).name):
        if not name:
            continue
        try:
            subprocess.run(
                [purge, "-s", f"https://purge.jsdelivr.net/gh/{owner}/{args.repo}@{BRANCH}/{name}"],
                capture_output=True, timeout=30,
            )
        except Exception:
            pass
    print("已请求清理 jsDelivr 缓存")

    print("校验远端清单…")
    check_url = f"https://{owner}.github.io/{args.repo}/latest.json"
    served = ""
    for _attempt in range(6):
        try:
            with urllib.request.urlopen(check_url, timeout=20) as response:
                served = str(json.loads(response.read().decode("utf-8")).get("version") or "")
        except Exception:  # noqa: BLE001
            served = ""
        if served == version:
            break
        time.sleep(10)
    if served == version:
        print(f"  远端已是 v{served}")
    else:
        print(f"  ! 远端仍是 v{served or '未知'}（Pages 可能还在构建，稍等几分钟）")

    print()
    print("发布完成")
    print(f"  下载页   {cdn}/index.html")
    print(f"  Release  https://github.com/{owner}/{args.repo}/releases/tag/v{version}")
    print(f"  安装包   {manifest.get('url')}")
    print(f"  清单     {cdn}/latest.json")
    print(f"  已写入   {url_file}")
    if failed:
        print(f"\n有 {failed} 个文件失败。")
        return 6
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
