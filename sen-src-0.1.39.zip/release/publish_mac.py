"""把 macOS 构建产物上传到 Release，并写入 latest.json。

用法：
    python release/publish_mac.py path\\to\\Sen-macOS-0.1.32.zip
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOKEN_PATH = Path.home() / ".sen-gh-token"
API = "https://api.github.com/repos/178497/sen"


def token() -> str:
    raw = os.getenv("SEN_GH_TOKEN")
    if raw:
        return raw.strip()
    return TOKEN_PATH.read_text(encoding="utf-8").strip()


def sha256_of(path: Path) -> tuple[str, float]:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest(), round(path.stat().st_size / (1024 * 1024), 1)


def curl_json(method: str, url: str, body: dict | None = None, timeout: int = 120) -> dict:
    args = ["curl", "-s", "-X", method, "-H", f"Authorization: token {token()}",
            "-H", "Content-Type: application/json", "-H", "User-Agent: Sen", url]
    if body is not None:
        handle = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8")
        json.dump(body, handle)
        handle.close()
        args[args.index("-s") + 1: args.index("-s") + 1] = []
        args += ["--data-binary", f"@{handle.name}"]
    result = subprocess.run(args + ["--max-time", str(timeout)], capture_output=True, text=True)
    text = result.stdout.strip()
    try:
        return json.loads(text) if text else {}
    except json.JSONDecodeError:
        return {"raw": text[:300]}


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry_run = "--dry-run" in sys.argv

    if not args:
        print("用法：python release/publish_mac.py <Sen-macOS-x.y.z.zip> [--dry-run]")
        return 2
    archive = Path(args[0]).expanduser().resolve()
    if not archive.is_file():
        print(f"找不到文件：{archive}")
        return 2
    if archive.suffix.lower() != ".zip":
        print("需要 .zip（build_mac.sh 的产物）")
        return 2

    version = archive.stem.split("-")[-1]
    if not version[:1].isdigit():
        print(f"文件名里取不到版本号：{archive.name}，应为 Sen-macOS-x.y.z.zip")
        return 2

    digest, size_mb = sha256_of(archive)
    print(f"版本 {version} · {size_mb} MB · sha256 {digest[:12]}…")

    if dry_run:
        local_manifest = ROOT / "release" / "latest.json"
        current = json.loads(local_manifest.read_text(encoding="utf-8")) if local_manifest.is_file() else {}
        print()
        print("[dry-run] 将写入 latest.json")
        print(f"  macos_url      = https://github.com/178497/sen/releases/download/v{version}/{archive.name}")
        print(f"  macos_size_mb  = {size_mb}")
        print(f"  macos_sha256   = {digest}")
        current_version = current.get("version", "?")
        print(f"  (当前清单版本 {current_version})")
        print("未上传，未修改任何文件")
        return 0

    tag = f"v{version}"
    release = curl_json("GET", f"{API}/releases/tags/{tag}")
    if "id" not in release:
        release = curl_json("POST", f"{API}/releases", {
            "tag_name": tag, "name": f"森 {version}", "draft": False, "prerelease": False,
            "body": "macOS 版（未签名）",
        })
    if "id" not in release:
        print("创建 Release 失败：", release)
        return 1

    existing = {asset["name"]: asset for asset in release.get("assets", [])}
    if archive.name in existing:
        curl_json("DELETE", f"{API}/releases/assets/{existing[archive.name]['id']}")
        print("已删除同名的旧资产")

    upload = subprocess.run(
        ["curl", "-s", "-o", os.devnull, "-w", "%{http_code}", "-X", "POST",
         "-H", f"Authorization: token {token()}",
         "-H", "Content-Type: application/octet-stream",
         "--data-binary", f"@{archive}",
         "--max-time", "900",
         f"https://uploads.github.com/repos/178497/sen/releases/{release['id']}/assets?name={archive.name}"],
        capture_output=True, text=True,
    )
    code = upload.stdout.strip()
    print(f"上传 {archive.name} -> {code}")
    if code not in {"201", "200"}:
        return 1

    url = f"https://github.com/178497/sen/releases/download/{tag}/{archive.name}"

    local_manifest = ROOT / "release" / "latest.json"
    manifest = json.loads(local_manifest.read_text(encoding="utf-8"))
    manifest.update({
        "macos_url": url,
        "macos_size_mb": size_mb,
        "macos_sha256": digest,
    })
    local_manifest.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    remote = curl_json("GET", f"{API}/contents/latest.json")
    body = {
        "message": f"release: {version} (macOS)",
        "content": __import__("base64").b64encode(local_manifest.read_bytes()).decode(),
        "branch": "main",
    }
    if remote.get("sha"):
        body["sha"] = remote["sha"]
    result = curl_json("PUT", f"{API}/contents/latest.json", body, timeout=180)
    print("清单更新:", "OK" if result.get("commit") else result)

    print("等待 Pages 生效…")
    for _ in range(20):
        time.sleep(15)
        try:
            with urllib.request.urlopen(
                "https://178497.github.io/sen/latest.json?t=" + str(int(time.time())), timeout=15
            ) as response:
                live = json.loads(response.read().decode("utf-8"))
            if live.get("macos_url"):
                print("已上线：", live["macos_url"])
                return 0
        except Exception:  # noqa: BLE001
            continue
    print("清单还没生效，稍后再检查  https://178497.github.io/sen/latest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
