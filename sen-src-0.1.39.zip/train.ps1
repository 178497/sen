param(
    [string]$Data = ".\data\train.jsonl",
    [int]$Epochs = 3,
    [switch]$Smoke,
    [string]$ResumeFrom = "",
    [string]$PauseFile = "",
    [int]$SaveSteps = 50,
    [int]$Throttle = 100,
    [string]$ThrottleFile = "",
    [string]$Output = ""
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# 打包版把训练环境放在 LOCALAPPDATA 下的 runtime 目录，由 CHAT_VENV_TRAIN 指定
$venvRoot = if ($env:CHAT_VENV_TRAIN) { $env:CHAT_VENV_TRAIN } else { Join-Path $PSScriptRoot ".venv-train" }
$python = Join-Path $venvRoot "Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
    throw "Training environment is missing: $venvRoot. Run setup_train.ps1 first."
}
if (-not (Test-Path -LiteralPath $Data)) {
    throw "Training data is missing: $Data. Copy .\data\train.example.jsonl to .\data\train.jsonl and edit it first."
}

if ($Smoke) {
    Write-Host "Running a 10-step compatibility test..."
    & $python train_qlora.py --data $Data --max-steps 10 --max-length 512
} else {
    Write-Host "Starting QLoRA training for $Epochs epochs..."
    $extra = @()
    if ($ResumeFrom) { $extra += @("--resume-from", $ResumeFrom) }
    if ($PauseFile) { $extra += @("--pause-file", $PauseFile) }
    if ($SaveSteps -gt 0) { $extra += @("--save-steps", "$SaveSteps") }
    if ($Throttle -gt 0) { $extra += @("--throttle", "$Throttle") }
    if ($ThrottleFile) { $extra += @("--throttle-file", $ThrottleFile) }
    if ($Output) { $extra += @("--output", $Output) }
    & $python train_qlora.py `
        --data $Data `
        --epochs $Epochs `
        --max-length 1024 `
        --gradient-accumulation 8 `
        @extra
}

exit $LASTEXITCODE
