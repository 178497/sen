# -*- mode: python ; coding: utf-8 -*-
"""macOS 打包配置（在 macOS 上执行 `pyinstaller sen_mac.spec`）。

Windows 用 sen.spec。差异：
- 产物是 Sen.app（BUNDLE），不是单文件 exe
- 不打包 pythonnet / clr（仅 Windows 需要）
- 训练脚本同时带上 .sh 版本
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(SPECPATH)

datas: list[tuple[str, str]] = []
for folder in ("static", "knowledge"):
    if (ROOT / folder).is_dir():
        datas.append((str(ROOT / folder), folder))
for single in ("model_config.json", "VERSION", "update_url.txt", "requirements-train.txt"):
    if (ROOT / single).is_file():
        datas.append((str(ROOT / single), "."))

for script in (
    "image_worker.py",
    "train_qlora.py",
    "merge_adapter.py",
    "prepare_oneclick_data.py",
    "select_model.py",
    "check_env.py",
    "train.sh",
    "setup_train.sh",
    "train.ps1",
    "setup_train.ps1",
):
    source = ROOT / script
    if source.exists():
        datas.append((str(source), "."))

hiddenimports = [
    "bottle",
    "webview",
    "webview.platforms.cocoa",
    "edge_tts",
    "runtime_setup",
    "training_plans",
    "platform_layer",
]

a = Analysis(
    [str(ROOT / "desktop.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "pythonnet", "clr", "clr_loader"],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Sen",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="Sen",
)

app = BUNDLE(
    coll,
    name="Sen.app",
    icon=str(ROOT / "static" / "assistant.icns") if (ROOT / "static" / "assistant.icns").exists() else None,
    bundle_identifier="com.sen.assistant",
    info_plist={
        "CFBundleName": "Sen",
        "CFBundleDisplayName": "森",
        "CFBundleShortVersionString": (ROOT / "VERSION").read_text(encoding="utf-8").strip()
        if (ROOT / "VERSION").exists()
        else "0.1.0",
        "CFBundleVersion": "1",
        "LSMinimumSystemVersion": "11.0",
        "NSHighResolutionCapable": True,
        "NSRequiresAquaSystemAppearance": False,
        "LSApplicationCategoryType": "public.app-category.productivity",
    },
)
