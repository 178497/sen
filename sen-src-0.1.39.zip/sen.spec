# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the portable 森 build (one-folder)."""

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH)

datas = [
    (str(ROOT / "static"), "static"),
]
if (ROOT / "knowledge").exists():
    datas.append((str(ROOT / "knowledge"), "knowledge"))
if (ROOT / "model_config.json").exists():
    datas.append((str(ROOT / "model_config.json"), "."))
if (ROOT / "VERSION").exists():
    datas.append((str(ROOT / "VERSION"), "."))
datas.append((str(ROOT / "requirements-train.txt"), "."))

# 这些脚本由外部 Python 以"文件路径"方式调用，必须作为数据文件随包
for script in (
    "image_worker.py",
    "train_qlora.py",
    "merge_adapter.py",
    "prepare_oneclick_data.py",
    "train.ps1",
    "setup_train.ps1",
    "train.sh",
    "setup_train.sh",
    "select_model.py",
    "check_env.py",
):
    if (ROOT / script).exists():
        datas.append((str(ROOT / script), "."))

hiddenimports = [
    "webview.platforms.winforms",
    "webview.platforms.edgechromium",
    "clr_loader",
    "pythonnet",
    "System",
    "System.Windows.Forms",
    "System.Drawing",
    "tts",
    "edge_tts",
    "runtime_setup",
    "training_plans",
]

hiddenimports += collect_submodules("webview")
hiddenimports += collect_submodules("clr_loader")

datas += collect_data_files("webview")

a = Analysis(
    ["desktop.py"],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "torch",
        "transformers",
        "diffusers",
        "numpy",
        "pandas",
        "matplotlib",
        "PIL",
        "tkinter",
        "pytest",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Sen",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon=str(ROOT / "static" / "assistant.ico"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="Sen",
)
