#!/bin/bash
# 从源码直接运行森（不打包）。出错时能看到完整 traceback，方便定位问题。
# 用法：./run-from-source.command
cd "$(dirname "$0")" || exit 1

echo "=============================="
echo "  森 · 源码模式运行"
echo "=============================="
echo

PY_BIN=""
for candidate in python3.12 python3.11 python3.13 python3.10 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    ver="$("$candidate" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
    case "$ver" in
      3.1[0-3]) PY_BIN="$candidate"; break ;;
    esac
  fi
done
if [ -z "$PY_BIN" ]; then
  echo "需要 Python 3.10-3.13，没找到。安装：https://www.python.org/downloads/macos/"
  read -r -p "按回车关闭…"
  exit 1
fi
echo "使用 $PY_BIN"

if [ ! -d ".venv-mac" ]; then
  echo "首次运行，创建 .venv-mac 并安装依赖（约 1-3 分钟）…"
  "$PY_BIN" -m venv .venv-mac || { echo "创建 venv 失败"; read -r -p "按回车关闭…"; exit 1; }
fi

# shellcheck disable=SC1091
source .venv-mac/bin/activate

if ! python -c "import webview, objc" >/dev/null 2>&1; then
  echo "安装依赖…"
  python -m pip install --upgrade pip >/dev/null
  if ! python -m pip install -r requirements-desktop.txt; then
    echo "直连失败，改用清华镜像"
    python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements-desktop.txt
  fi
fi

echo "启动（关闭窗口即退出）…"
echo "----------------------------------------------"
python desktop.py
code=$?
echo "----------------------------------------------"

err="$HOME/Library/Application Support/Sen/desktop-error.log"
if [ -f "$err" ]; then
  echo "错误日志（最后 20 行）："
  tail -n 20 "$err"
  echo
fi

echo "退出码：$code"
read -r -p "按回车关闭…"
