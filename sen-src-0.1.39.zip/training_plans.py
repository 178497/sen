"""把「你想让森学什么」翻译成几个可执行的训练方案（面向学生场景）。

纯本地启发式，不依赖模型或网络：先按关键词判断领域，再给三档强度。
"""

from __future__ import annotations

import math
import re
from typing import Any

SECONDS_PER_STEP = 8.5  # 8.5s/step，实测（1024 长度、梯度累积 8、80% 限速）
GRAD_ACCUM = 8

DOMAINS: list[dict[str, Any]] = [
    {
        "key": "subject",
        "label": "学科答疑",
        "focus": "把题目讲清楚，按步骤给答案",
        "keywords": [
            "数学", "物理", "化学", "生物", "地理", "历史", "政治", "语文", "英语题",
            "解题", "讲题", "做题", "作业", "习题", "知识点", "公式", "定理", "证明",
            "函数", "几何", "方程", "化学式", "受力分析", "化学方程式", "背诵课文",
        ],
        "search_query": "chinese math word problems",
        "samples": 400,
        "max_length": 1024,
        "tone": "先给答案再讲步骤，别绕圈子",
    },
    {
        "key": "exam",
        "label": "考试 / 刷题",
        "focus": "按考试标准答题，格式和得分点对齐",
        "keywords": [
            "高考", "中考", "考研", "四六级", "四级", "六级", "雅思", "托福", "教资",
            "公务员", "公考", "刷题", "真题", "模拟卷", "选择题", "填空题", "大题",
            "得分点", "评分标准", "冲刺", "押题",
        ],
        "search_query": "chinese exam questions",
        "samples": 450,
        "max_length": 1024,
        "tone": "按评分标准写，得分点要露出来",
    },
    {
        "key": "paper",
        "label": "论文 / 学术",
        "focus": "学术表达、结构规范和文献综述口吻",
        "keywords": [
            "论文", "文献", "综述", "开题", "答辩", "摘要", "引言", "参考文献", "查重",
            "学术", "研究", "实验设计", "期刊", "毕业设计", "课程论文", "文献综述",
        ],
        "search_query": "chinese academic writing",
        "samples": 350,
        "max_length": 1024,
        "tone": "客观、书面，不要口语化",
    },
    {
        "key": "code",
        "label": "编程 / 作业",
        "focus": "学会你的代码风格、常用库和写注释的习惯",
        "keywords": [
            "代码", "编程", "脚本", "函数", "报错", "调试", "bug", "python", "java",
            "c语言", "c++", "前端", "后端", "算法", "数据结构", "爬虫", "sql", "接口",
            "课程设计", "大作业", "leetcode",
        ],
        "search_query": "chinese code programming instruction",
        "samples": 500,
        "max_length": 1024,
        "tone": "直接给能跑的代码，解释放在后面",
    },
    {
        "key": "english",
        "label": "英语 / 翻译",
        "focus": "统一译法，句式自然，不中式英语",
        "keywords": [
            "翻译", "英语", "英文", "英译中", "中译英", "单词", "背单词", "语法",
            "口语", "作文模板", "长难句", "术语", "双语",
        ],
        "search_query": "chinese english translation",
        "samples": 350,
        "max_length": 768,
        "tone": "术语统一，别每次换说法",
    },
    {
        "key": "writing",
        "label": "写作 / 文案",
        "focus": "模仿你的文风、句式和用词习惯",
        "keywords": [
            "写作", "作文", "文案", "公众号", "小说", "润色", "语气", "标题", "小红书",
            "短视频", "演讲稿", "推文", "记叙文", "议论文", "读后感",
        ],
        "search_query": "chinese writing instruction",
        "samples": 350,
        "max_length": 1024,
        "tone": "保持你的语气，不要写成公文",
    },
    {
        "key": "summary",
        "label": "笔记 / 总结",
        "focus": "压缩长文本、抓重点、按固定结构输出",
        "keywords": [
            "总结", "摘要", "提炼", "笔记", "纪要", "长文", "课堂笔记", "复习提纲",
            "思维导图", "重点", "划重点", "整理",
        ],
        "search_query": "chinese summarization",
        "samples": 300,
        "max_length": 1024,
        "tone": "先给结论，再列要点",
    },
    {
        "key": "experiment",
        "label": "实验 / 数据",
        "focus": "实验报告结构、数据处理和结论怎么写",
        "keywords": [
            "实验报告", "数据分析", "统计", "图表", "excel", "spss", "误差", "结论",
            "数据处理", "调研", "问卷", "建模", "matlab",
        ],
        "search_query": "chinese data analysis",
        "samples": 300,
        "max_length": 1024,
        "tone": "数据先行，结论要有依据",
    },
    {
        "key": "speech",
        "label": "演讲 / 面试",
        "focus": "口语化表达、有节奏、不背书感",
        "keywords": [
            "演讲", "辩论", "面试", "自我介绍", "答辩", "汇报", "pre", "presentation",
            "路演", "竞选", "发言稿",
        ],
        "search_query": "chinese dialogue instruction",
        "samples": 250,
        "max_length": 768,
        "tone": "像在讲话，不要写成文章",
    },
    {
        "key": "persona",
        "label": "树洞 / 陪伴",
        "focus": "情绪回应、称呼和语气稳定",
        "keywords": [
            "树洞", "陪伴", "心情", "焦虑", "压力", "鼓励", "安慰", "倾诉", "人设",
            "女友", "男友", "宝宝", "撒娇", "口吻", "称呼", "情绪价值", "聊得来",
        ],
        "search_query": "chinese emotional dialogue",
        "samples": 250,
        "max_length": 512,
        "tone": "先接住情绪，再给建议",
    },
    {
        "key": "planning",
        "label": "学习规划",
        "focus": "把目标拆成可执行的每日计划",
        "keywords": [
            "学习方法", "时间管理", "计划", "规划", "拖延", "复习", "备考", "打卡",
            "效率", "作息", "自律", "番茄钟", "周计划",
        ],
        "search_query": "chinese instruction",
        "samples": 250,
        "max_length": 768,
        "tone": "给具体到小时的安排，别讲大道理",
    },
]

GENERIC = {
    "key": "general",
    "label": "通用助手",
    "focus": "整体更像你要的那个助手",
    "keywords": [],
    "search_query": "chinese instruction",
    "samples": 300,
    "max_length": 768,
    "tone": "先跑通，再逐步补样本",
}

TIERS = [
    {"key": "fast", "name": "先试一下", "epochs": 1, "ratio": 0.5, "note": "半小时内看到效果，用来判断方向对不对"},
    {"key": "standard", "name": "标准训练", "epochs": 2, "ratio": 1.0, "note": "日常推荐，效果和耗时比较平衡"},
    {"key": "fine", "name": "练得更细", "epochs": 4, "ratio": 1.2, "note": "样本多、想明显改变说话方式时用"},
]


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower())


def _pick_domain(text: str) -> tuple[dict[str, Any], list[str]]:
    normalised = _normalise(text)
    best = None
    best_hits: list[str] = []
    for domain in DOMAINS:
        hits = [word for word in domain["keywords"] if word.lower() in normalised]
        if len(hits) > len(best_hits):
            best = domain
            best_hits = hits
    if best is None:
        return GENERIC, []
    return best, best_hits


def estimate_minutes(samples: int, epochs: int, throttle: int = 80) -> int:
    steps_per_epoch = max(1, math.ceil(samples / GRAD_ACCUM))
    steps = steps_per_epoch * epochs
    factor = 80 / max(40, min(100, throttle))
    return max(1, round(steps * SECONDS_PER_STEP * factor / 60))


def suggest(description: str, available_samples: int = 0, throttle: int = 80) -> dict[str, Any]:
    domain, hits = _pick_domain(description)
    base_samples = int(domain.get("samples") or 300)
    samples = available_samples or base_samples
    plans = []
    for tier in TIERS:
        target = int(min(samples, base_samples * tier["ratio"]) or base_samples)
        epochs = tier["epochs"]
        minutes = estimate_minutes(max(target, GRAD_ACCUM), epochs, throttle)
        plans.append(
            {
                "id": f"{domain['key']}-{tier['key']}",
                "name": tier["name"],
                "summary": tier["note"],
                "domain": domain["label"],
                "focus": domain["focus"],
                "samples": target,
                "epochs": epochs,
                "max_length": domain["max_length"],
                "minutes": minutes,
                "search_query": domain.get("search_query", "chinese instruction"),
                "params": {
                    "epochs": epochs,
                    "samples": target,
                    "max_length": domain["max_length"],
                },
            }
        )
    return {
        "domain": domain["label"],
        "focus": domain["focus"],
        "tone": domain.get("tone", ""),
        "search_query": domain.get("search_query", "chinese instruction"),
        "matched": hits[:5],
        "generated_plans_note": f"约 {samples} 条样本可用" if available_samples else "按推荐样本量估算",
        "plans": plans,
    }
