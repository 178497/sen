#!/bin/bash
# 构建前环境自检：双击运行，或 ./doctor-mac.command
cd "$(dirname "$0")" || exit 1

pass=0
fail=0

ok()   { echo "  ✓ $1"; pass=$((pass+1)); }
bad()  { echo "  ✗ $1"; echo "      → $2"; fail=$((fail+1)); }
warn() { echo "  ! $1"; }

echo "=============================="
echo "  森 · macOS 环境自检"
echo "=============================="
echo

echo "系统"
echo "  macOS $(sw_vers -productVersion 2>/dev/null || echo '?') · $(uname -m)"
if [ "$(uname -m)" = "arm64" ]; then
  ok "Apple Silicon（推荐）"
else
  warn "Intel Mac：能构建，但本地大模型推理会很慢"
fi
echo

echo "构建依赖"
if command -v python3 >/dev/null 2>&1; then
  ver="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
  case "$ver" in
    3.1[0-9]) ok "python3 $ver" ;;
    *) bad "python3 $ver 版本偏低" "安装 3.11+：https://www.python.org/downloads/macos/" ;;
  esac
else
  bad "没有 python3" "安装：https://www.python.org/downloads/macos/"
fi

if xcode-select -p >/dev/null 2>&1; then
  ok "Xcode Command Line Tools"
else
  bad "缺少 Command Line Tools" "在终端执行：xcode-select --install"
fi

free_gb=$(df -g . | awk 'NR==2 {print $4}')
if [ "${free_gb:-0}" -ge 5 ]; then
  ok "磁盘剩余 ${free_gb} GB"
else
  bad "磁盘只剩 ${free_gb} GB" "构建+依赖大约需要 3 GB，建议留 5 GB"
fi
echo

echo "网络"
if curl -sI --max-time 8 https://pypi.org/simple/ >/dev/null 2>&1; then
  ok "PyPI 可访问"
else
  warn "PyPI 直连超时，构建脚本会自动改用清华镜像"
fi
echo

echo "推理引擎（Ollama）"
if [ -d "/Applications/Ollama.app" ] || command -v ollama >/dev/null 2>&1; then
  ok "已安装 Ollama"
  if curl -s --max-time 3 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    ok "Ollama 服务在运行"
  else
    warn "Ollama 已安装但没运行，森启动时会尝试拉起"
  fi
else
  bad "没有安装 Ollama" "下载：https://ollama.com/download/mac"
fi
echo

echo "------------------------------"
echo "通过 $pass 项，失败 $fail 项"
if [ "$fail" -eq 0 ]; then
  echo "可以开始构建：./build-mac.command"
else
  echo "先解决上面标 ✗ 的项目，再构建。"
fi
echo
read -r -p "按回车关闭…"
