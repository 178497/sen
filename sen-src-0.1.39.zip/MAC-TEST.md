# macOS 首次验证清单

按顺序做，每步都记下结果。哪一步断了就停在那里，把报错发回来。

## 0. 环境自检

```bash
./doctor-mac.command
```

期望：`通过 8 项，失败 0 项`

---

## 1. 构建

```bash
./build-mac.command
```

期望最后几行：

```
==> ad-hoc 签名
  签名校验通过
  外部脚本齐全
  可执行文件就绪
==> 完成：release/Sen-macOS-<版本>.zip (xx MB)
```

**要留意的**：

- 如果卡在 `pip install` → 一般是网络，脚本会自动切清华镜像
- 如果 `PyInstaller` 报 missing module → 记下模块名
- 如果自检报「缺少 xxx」 → 说明这个文件没在 spec 里，正好被拦下来了

---

## 2. 安装

```bash
cd release && unzip Sen-macOS-*.zip -d /tmp/sen-app
cp -R /tmp/sen-app/Sen.app /Applications/
xattr -dr com.apple.quarantine /Applications/Sen.app
open -a Sen
```

期望：出现启动动画（约 3 秒）→ 进入主界面。

---

## 3. 首屏检查

| 检查项 | 期望 |
|---|---|
| 窗口尺寸 | 约占屏幕 90%，不是 900×600 的小窗 |
| 背景 | 深色 + 荧光绿主色，不是白屏 |
| 右上角 | 显示 `CORE ONLINE · <模型名>` 或离线提示 |
| 左下 | 三个模式可切换 |
| 启动日志 | `~/Library/Application Support/Sen/data/boot.log` 里有 `resources .../static` |

白屏的话，看 boot.log 里 `resources` 那一行指向哪里。

---

## 4. 推理

如果是第一次装 Ollama，应用会弹「准备本地推理环境」：

1. 点「已安装，启动」→ 应能拉起 Ollama
2. 点「开始下载模型」→ 下载 qwen3:1.7b（约 1.4 GB）

然后发一句「你好」，期望 3-10 秒内有回复。

**慢是正常的**：M 系列跑 1.7B 大约 20-30 tok/s。

---

## 5. 主题与声音

1. 设置 → 主题 → 切 2-3 套（全息 / 糖果 / 午夜）
2. 确认音乐按钮能出声音，SFX 有点击音

---

## 6. 生图（可选，要下 2.5 GB）

设置里点「安装生图运行时」，走完约 10-20 分钟。然后让森画一张：

> 生成一张图片：赛博朋克城市夜景

期望：M 系列 3-8 秒出图（比 NVIDIA 慢，但不该是 40 秒）。

---

## 7. 训练（可选，最耗时）

训练舱 → 说一句需求 → 选「先试一下」（1 轮）。

首个检查点出现后可暂停，**不必跑完**——我们只验证：

- 环境能装起来（`.venv-train` 出现在 `~/Library/Application Support/Sen/runtime/`）
- 训练进程能启动、能出 step 进度
- 暂停后能续训

跑完的话会 merge 成 GGUF 并 `ollama create`，最后自动切模型。

---

## 8. 出问题时的取证

```bash
./collect-mac-logs.command
```

桌面会生成 `sen-diagnostics-*.zip`，包含系统信息、签名信息、各日志（API key 已脱敏）。

源码模式对照：

```bash
./run-from-source.command
```

源码能起、打包版起不来 = 打包问题；两个都起不来 = 代码/环境问题。
