"""Windows desktop shell for the local knowledge assistant."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

import platform_layer
from typing import Any

import webview


def resource_candidates() -> list[Path]:
    """打包后资源可能在 _MEIPASS，也可能在 .app 的 Resources / Frameworks。

    macOS 的 .app 布局在不同 PyInstaller 版本里有差异，全部列出来按顺序找。
    """
    if not getattr(sys, "frozen", False):
        return [Path(__file__).resolve().parent]

    bases: list[Path] = []
    meipass = getattr(sys, "_MEIPASS", "")
    if meipass:
        bases.append(Path(meipass))
    exe_dir = Path(sys.executable).resolve().parent
    bases.append(exe_dir)
    bases.append(exe_dir.parent / "Resources")
    bases.append(exe_dir.parent / "Frameworks")
    bases.append(exe_dir / "_internal")
    if platform_layer.IS_MAC:
        bases.append(exe_dir.parent / "Frameworks" / "_internal")

    unique: list[Path] = []
    for base in bases:
        if base not in unique:
            unique.append(base)
    return unique


def resource_path(*parts: str) -> Path:
    candidates = resource_candidates()
    for base in candidates:
        target = base.joinpath(*parts)
        if target.exists():
            return target
    return candidates[0].joinpath(*parts)


def application_data_path() -> Path:
    if getattr(sys, "frozen", False):
        if platform_layer.IS_MAC:
            base = Path.home() / "Library" / "Application Support" / "Sen"
        elif platform_layer.IS_WINDOWS:
            base = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "Sen"
        else:
            base = Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "Sen"
    else:
        base = Path(__file__).resolve().parent
    base.mkdir(parents=True, exist_ok=True)
    return base


DATA_ROOT = application_data_path()
if getattr(sys, "frozen", False):
    KNOWLEDGE_DIR = DATA_ROOT / "knowledge"
    INDEX_PATH = DATA_ROOT / "data" / "knowledge_index.json"
    KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    bundled_knowledge = resource_path("knowledge")
    if bundled_knowledge.exists():
        for source in bundled_knowledge.iterdir():
            target = KNOWLEDGE_DIR / source.name
            if source.is_file() and not target.exists():
                shutil.copy2(source, target)
else:
    KNOWLEDGE_DIR = DATA_ROOT / "knowledge"
    INDEX_PATH = DATA_ROOT / "data" / "knowledge_index.json"

os.environ["CHAT_KNOWLEDGE_DIR"] = str(KNOWLEDGE_DIR)
os.environ["CHAT_INDEX_PATH"] = str(INDEX_PATH)
os.environ["CHAT_MODEL_CONFIG"] = str(DATA_ROOT / "model_config.json")
os.environ["CHAT_PROVIDER_CONFIG"] = str(DATA_ROOT / "provider_config.json")
os.environ["CHAT_OUTPUT_DIR"] = str(DATA_ROOT / "outputs")
if getattr(sys, "frozen", False):
    os.environ.setdefault("CHAT_VENV_TRAIN", str(DATA_ROOT / "runtime" / "venv-train"))

def _read_version() -> str:
    try:
        return resource_path("VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


APP_VERSION = _read_version()
OLLAMA_DOWNLOAD_URL = "https://ollama.com/download"
_UPDATE_STATE = {
    "running": False,
    "percent": 0,
    "path": "",
    "error": "",
    "done": False,
    "version": "",
}
_MODEL_PULL = {
    "running": False,
    "percent": 0,
    "line": "",
    "error": "",
    "done": False,
    "model": "",
}


def ollama_exe() -> Path:
    if platform_layer.IS_MAC:
        for candidate in (
            Path("/Applications/Ollama.app/Contents/Resources/ollama"),
            Path("/usr/local/bin/ollama"),
            Path("/opt/homebrew/bin/ollama"),
        ):
            if candidate.exists():
                return candidate
        return Path("/Applications/Ollama.app/Contents/Resources/ollama")
    return Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "Programs" / "Ollama" / "ollama.exe"


def ollama_app_exe() -> Path:
    if platform_layer.IS_MAC:
        return Path("/Applications/Ollama.app")
    return Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "Programs" / "Ollama" / "ollama app.exe"


def ollama_reachable(timeout: float = 1.5) -> bool:
    import json
    import urllib.request

    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=timeout) as response:
            json.loads(response.read().decode("utf-8"))
        return True
    except Exception:
        return False


def start_ollama() -> dict[str, Any]:
    app = ollama_app_exe()
    exe = ollama_exe()
    if ollama_reachable():
        return {"ok": True, "running": True, "detail": "已在运行"}
    if app.exists():
        if platform_layer.IS_MAC:
            # .app 是目录，不能直接 Popen，用 open 交给 LaunchServices
            subprocess.Popen(["open", "-a", str(app)], close_fds=True)
        else:
            subprocess.Popen([str(app)], close_fds=True)
    elif exe.exists():
        subprocess.Popen(
            [str(exe), "serve"],
            close_fds=True,
            creationflags=platform_layer.hidden_flags(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        return {"ok": False, "running": False, "detail": "未找到 Ollama，请先安装"}
    deadline = time.time() + 25
    while time.time() < deadline:
        if ollama_reachable():
            return {"ok": True, "running": True, "detail": "已启动"}
        time.sleep(0.8)
    return {"ok": False, "running": False, "detail": "启动超时，可手动打开 Ollama 后重试"}


def start_model_pull(model: str) -> dict[str, Any]:
    if _MODEL_PULL["running"]:
        return {"ok": True, "started": False, "detail": "正在下载中"}
    exe = ollama_exe()
    if not exe.exists():
        return {"ok": False, "error": "未找到 ollama 命令，请先安装 Ollama"}
    _MODEL_PULL.update(
        {"running": True, "percent": 0, "line": "准备下载…", "error": "", "done": False, "model": model}
    )

    def worker() -> None:
        try:
            process = subprocess.Popen(
                [str(exe), "pull", model],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=platform_layer.hidden_flags(),
            )
            assert process.stdout is not None
            for raw in process.stdout:
                line = raw.strip()
                if not line:
                    continue
                _MODEL_PULL["line"] = line[-120:]
                marker = line.find("%")
                if marker > 0:
                    digits = ""
                    index = marker - 1
                    while index >= 0 and (line[index].isdigit() or line[index] == "."):
                        digits = line[index] + digits
                        index -= 1
                    try:
                        _MODEL_PULL["percent"] = min(99, int(float(digits)))
                    except ValueError:
                        pass
            process.wait()
            if process.returncode == 0:
                _MODEL_PULL.update({"percent": 100, "line": "下载完成", "done": True})
            else:
                _MODEL_PULL.update({"error": f"ollama pull 退出码 {process.returncode}"})
        except Exception as error:  # noqa: BLE001
            _MODEL_PULL.update({"error": str(error)})
        finally:
            _MODEL_PULL["running"] = False

    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, "started": True}


def model_pull_status() -> dict[str, Any]:
    return dict(_MODEL_PULL)


from rag import build_index  # noqa: E402
from server import (  # noqa: E402
    build_chat_response,
    chat_job_status,
    get_health,
    generate_image,
    public_provider_config,
    reindex_documents,
    save_provider_config,
    start_chat_job,
    test_provider,
)
from training_manager import TrainingManager  # noqa: E402
from system_monitor import SystemMonitor  # noqa: E402
from thread_store import ThreadStore  # noqa: E402
from updater import DEFAULT_UPDATE_URL, check_for_update, download_installer  # noqa: E402


class DesktopApi:
    def __setattr__(self, name: str, value: object) -> None:
        # pywebview reflects over public attributes when it builds the JS bridge.
        # A public non-callable attribute (Window, manager, thread...) makes that
        # reflection walk an unbounded object graph and freezes the window.
        if not name.startswith("_") and not callable(value):
            raise AttributeError(
                f"DesktopApi.{name} must be private (leading underscore) or callable"
            )
        super().__setattr__(name, value)

    def __init__(self) -> None:
        self._window: webview.Window | None = None
        # 脚本从安装目录读（只读），日志/数据/产物写到数据目录。
        # Windows 保持原行为（产物留在安装目录，历史训练结果仍可见）。
        work_dir = (DATA_ROOT / "training") if platform_layer.IS_MAC else None
        self._training = TrainingManager(
            Path(__file__).resolve().parent, work_dir=work_dir
        )
        self._monitor = SystemMonitor(interval=2.0)
        self._monitor.start()
        self._threads = ThreadStore(DATA_ROOT / "data" / "threads.json")

    def runtime_status(self) -> dict[str, Any]:
        """本地生图运行时的安装状态。"""
        try:
            import runtime_setup

            installer = runtime_setup.installer_for(DATA_ROOT)
            status = installer.status()
            # 如果配置里已经有可用的模型目录，就不必再下载
            try:
                config_path = Path(os.getenv("CHAT_PROVIDER_CONFIG") or DATA_ROOT / "provider_config.json")
                if config_path.is_file():
                    config = json.loads(config_path.read_text(encoding="utf-8"))
                    model = Path(str(config.get("image_model") or ""))
                    unet = model / "unet"
                    if unet.is_dir() and any(
                        item.stat().st_size > 100 * 1024 * 1024
                        for item in unet.glob("*.safetensors")
                    ):
                        status["model_ready"] = True
                        status["ready"] = bool(status.get("venv_ready"))
            except Exception:  # noqa: BLE001
                pass
            return status
        except Exception as error:  # noqa: BLE001
            return {"ready": False, "running": False, "error": str(error), "percent": 0}

    def runtime_resume(self) -> dict[str, Any]:
        """启动时调用：上次没装完就后台继续。"""
        try:
            import runtime_setup

            installer = runtime_setup.installer_for(DATA_ROOT)
            if installer.resume_if_pending():
                threading.Thread(target=self._point_image_config, daemon=True).start()
                return {"ok": True, "resumed": True}
            return {"ok": True, "resumed": False}
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "error": str(error)}

    def runtime_install(self) -> dict[str, Any]:
        """开始下载并安装本地生图运行时。"""
        try:
            import runtime_setup

            installer = runtime_setup.installer_for(DATA_ROOT)
            result = installer.start()
            if result.get("ok"):
                threading.Thread(target=self._point_image_config, daemon=True).start()
            return result
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "error": str(error)}

    def _point_image_config(self) -> None:
        """安装完成后把生图模型指向新下载的目录。"""
        import runtime_setup

        model_dir = runtime_setup.installer_for(DATA_ROOT).models
        for _ in range(3600):
            if model_dir.joinpath("model_index.json").is_file():
                try:
                    config_path = Path(os.getenv("CHAT_PROVIDER_CONFIG", "")) or DATA_ROOT / "provider_config.json"
                    config = {}
                    if config_path.is_file():
                        config = json.loads(config_path.read_text(encoding="utf-8"))
                    config["image_backend"] = "local"
                    config["image_model"] = str(model_dir)
                    # 装完立刻生效，不用重启
                    os.environ["CHAT_VENV_TRAIN"] = str(model_dir.parent.parent / "runtime" / "venv-train")
                    config_path.parent.mkdir(parents=True, exist_ok=True)
                    config_path.write_text(
                        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                except Exception:  # noqa: BLE001
                    pass
                return
            time.sleep(2)

    def tts_status(self) -> dict[str, Any]:
        """朗读能力：是否可用、可选的神经音色。"""
        try:
            import tts as tts_module

            return {
                "ok": True,
                "neural": tts_module.available(),
                "voices": tts_module.voices() if tts_module.available() else [],
            }
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "neural": False, "voices": [], "error": str(error)}

    def tts_speak(self, text: str = "", voice: str = "") -> dict[str, Any]:
        """把一段文字合成为音频，返回可直接播放的 data URL。"""
        try:
            import tts as tts_module

            if not tts_module.available():
                return {"ok": False, "error": "neural-tts-unavailable"}
            data_url = tts_module.synthesize_data_url(
                text,
                voice or tts_module.DEFAULT_VOICE,
                cache_root=DATA_ROOT,
            )
            return {"ok": bool(data_url), "audio": data_url}
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "error": str(error)}

    def app_version(self) -> dict[str, Any]:
        return {"version": APP_VERSION}

    def check_update(self) -> dict[str, Any]:
        boot_mark("update-check " + DEFAULT_UPDATE_URL)
        result = check_for_update(APP_VERSION)
        boot_mark(
            "update-result ok=%s available=%s error=%s"
            % (result.get("ok"), result.get("available"), result.get("error", ""))
        )
        return result

    def start_update_download(self, info: dict[str, Any] | None = None) -> dict[str, Any]:
        if _UPDATE_STATE["running"]:
            return {"ok": True, "started": False}
        manifest = info if isinstance(info, dict) and info.get("url") else None
        if manifest is None:
            found = check_for_update(APP_VERSION)
            if not found.get("available"):
                return {"ok": False, "error": found.get("error") or "已是最新版本"}
            manifest = found
        candidates = []
        if platform_layer.IS_MAC:
            mac_url = str(manifest.get("macos_url") or "")
            if mac_url:
                candidates.append((mac_url, str(manifest.get("macos_sha256") or "")))
            if not candidates:
                return {"ok": False, "error": "这个版本还没有提供 macOS 安装包"}
        zipped = str(manifest.get("url_zip") or "")
        if zipped:
            candidates.append((zipped, str(manifest.get("zip_sha256") or "")))
        mirror = str(manifest.get("url_zip_pages") or "")
        if mirror:
            candidates.append((mirror, str(manifest.get("zip_sha256") or "")))
        primary = str(manifest.get("url") or "")
        if primary and not platform_layer.IS_MAC:
            candidates.append((primary, str(manifest.get("sha256") or "")))
        _UPDATE_STATE.update(
            {"running": True, "percent": 0, "path": "", "error": "", "done": False,
             "version": str(manifest.get("version") or "")}
        )

        def worker() -> None:
            try:
                path = download_installer(
                    candidates,
                    "",
                    lambda value: _UPDATE_STATE.__setitem__("percent", value),
                )
                _UPDATE_STATE.update({"path": str(path), "done": True, "percent": 100})
            except Exception as error:  # noqa: BLE001
                _UPDATE_STATE.update({"error": str(error)})
            finally:
                _UPDATE_STATE["running"] = False

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True, "started": True}

    def update_progress(self) -> dict[str, Any]:
        return dict(_UPDATE_STATE)

    def apply_update(self) -> dict[str, Any]:
        path = _UPDATE_STATE.get("path")
        if not path or not Path(path).exists():
            return {"ok": False, "error": "安装包尚未下载完成"}
        if platform_layer.IS_MAC:
            # macOS 不能静默覆盖运行中的 .app，打开解压目录让用户拖进去
            try:
                target = Path(path)
                folder = target if target.is_dir() else target.parent
                platform_layer.open_path(folder)
            except Exception as error:  # noqa: BLE001
                return {"ok": False, "error": str(error)}
            return {
                "ok": True,
                "manual": True,
                "detail": "已解压到访达，请把 Sen.app 拖进「应用程序」替换旧版本",
            }
        try:
            subprocess.Popen(
                [str(path), "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/SP-"],
                close_fds=True,
            )
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "error": str(error)}
        window = getattr(self, "_window", None)
        if window is not None:
            window.destroy()
        return {"ok": True}

    def setup_status(self) -> dict[str, Any]:
        health = get_health()
        return {
            "ollama_installed": ollama_exe().exists() or ollama_app_exe().exists(),
            "ollama_running": ollama_reachable(),
            "model": health.get("model", ""),
            "model_ready": health.get("model_ready", False),
            "remote_mode": health.get("provider_mode") == "remote",
            "download_url": OLLAMA_DOWNLOAD_URL,
            "pull": model_pull_status(),
        }

    def start_ollama(self) -> dict[str, Any]:
        return start_ollama()

    def open_ollama_download(self) -> dict[str, Any]:
        import webbrowser

        webbrowser.open(OLLAMA_DOWNLOAD_URL)
        return {"ok": True}

    def start_model_pull(self, model: str) -> dict[str, Any]:
        return start_model_pull(str(model))

    def model_pull_status(self) -> dict[str, Any]:
        return model_pull_status()

    def boot_mark(self, label: str) -> dict[str, Any]:
        boot_mark(str(label))
        return {"ok": True}

    def load_conversations(self) -> dict[str, Any]:
        return self._threads.load()

    def save_conversations(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._threads.save(payload)

    def health(self) -> dict[str, Any]:
        return get_health()

    def chat(self, payload: dict[str, Any]) -> dict[str, Any]:
        return build_chat_response(payload)

    def start_chat(self, payload: dict[str, Any]) -> dict[str, Any]:
        return start_chat_job(payload)

    def chat_status(self, job_id: str) -> dict[str, Any]:
        return chat_job_status(str(job_id))

    def get_provider_config(self) -> dict[str, Any]:
        return public_provider_config()

    def save_provider_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        return save_provider_config(payload)

    def test_provider(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return test_provider(payload)

    def generate_image(self, prompt: str, size: str = "1024x1024") -> dict[str, Any]:
        return generate_image(str(prompt), str(size))

    def reindex(self) -> dict[str, int]:
        return reindex_documents()

    def open_knowledge_folder(self) -> bool:
        platform_layer.open_path(KNOWLEDGE_DIR)
        return True

    def system_stats(self) -> dict[str, Any]:
        return self._monitor.snapshot()

    def training_history(self, limit: int = 20) -> dict[str, Any]:
        return self._training.history(int(limit))

    def training_status(self) -> dict[str, Any]:
        return self._training.status()

    def training_logs(self, cursor: int = 0) -> dict[str, Any]:
        return self._training.read_logs(int(cursor))

    def choose_training_data(self) -> dict[str, Any]:
        if self._window is None:
            raise RuntimeError("Desktop window is not ready")
        result = self._window.create_file_dialog(
            webview.OPEN_DIALOG,
            directory=str(self._training.data_path.parent),
            allow_multiple=False,
            file_types=(
                "JSON Lines (*.jsonl;*.json)",
                "All files (*.*)",
            ),
        )
        if result:
            path = result[0] if isinstance(result, (list, tuple)) else result
            self._training.choose_data(str(path))
        return self._training.status()

    def open_training_data(self) -> dict[str, Any]:
        path = self._training.ensure_dataset_template()
        platform_layer.open_path(path)
        return self._training.status()

    def start_training(
        self,
        data_path: str,
        epochs: int,
        resume: bool = False,
        throttle: int | None = None,
    ) -> dict[str, Any]:
        return self._training.start(
            data_path,
            int(epochs),
            bool(resume),
            None if throttle is None else int(throttle),
        )

    def suggest_training_plan(self, description: str = "") -> dict[str, Any]:
        """根据用户描述的需求，给出几种训练方案。"""
        try:
            import training_plans

            status = self._training.status()
            summary = self._training.data_summary()
            samples = int(summary[0] or 0) if isinstance(summary, tuple) else 0
            throttle = int(status.get("throttle") or 80)
            result = training_plans.suggest(description, samples, throttle)
            result["ok"] = True
            return result
        except Exception as error:  # noqa: BLE001
            return {"ok": False, "error": str(error), "plans": []}

    def set_training_throttle(self, value: int) -> dict[str, Any]:
        return self._training.set_throttle(int(value))

    def pause_training(self) -> dict[str, Any]:
        return self._training.pause()

    def import_existing_adapter(self) -> dict[str, Any]:
        return self._training.import_existing_adapter()

    def rerun_training_diagnostics(self) -> dict[str, Any]:
        error = RuntimeError(self._training.status().get("last_error", ""))
        diagnostic = self._training.diagnose_failure(error)
        with self._training._lock:
            self._training._diagnostics = diagnostic
        return diagnostic

    def open_training_log(self) -> bool:
        if not self._training.log_path.exists():
            self._training.log_path.write_text("", encoding="utf-8")
        platform_layer.open_path(self._training.log_path)
        return True

    def search_training_datasets(self, query: str) -> dict[str, Any]:
        return {
            "results": self._training.search_datasets(str(query)),
        }

    def prepare_online_dataset(
        self,
        repo_id: str,
        max_samples: int = 1000,
    ) -> dict[str, Any]:
        return self._training.start_online_dataset(
            str(repo_id),
            int(max_samples),
        )


def check_api_surface(api: DesktopApi) -> None:
    """pywebview enumerates every public attribute of the js_api object.

    A public non-callable attribute (a Window, a manager, a thread...) makes
    that enumeration walk an unbounded object graph, which freezes the window
    on "未响应" before the page ever loads. Keep helpers private.
    """
    for name in dir(api):
        if name.startswith("_"):
            continue
        if not callable(getattr(api, name)):
            raise RuntimeError(
                f"DesktopApi.{name} must be private (leading underscore) or callable"
            )


def webview_storage_kwargs() -> dict[str, str]:
    """只有 Windows 的 EdgeChromium 需要指定存储目录；Cocoa 不认这个参数。"""
    if platform_layer.IS_MAC:
        return {}
    return {"storage_path": str(DATA_ROOT / ".webview-data")}


def configure_window(window: webview.Window, api: DesktopApi) -> None:
    boot_mark("webview-started")
    api._window = window
    check_api_surface(api)
    platform_layer.set_app_user_model_id("Sen.LocalAssistant")
    platform_layer.set_window_icon(window, resource_path("static", "assistant.ico"))




_BOOT_ORIGIN = time.perf_counter()


def boot_mark(label: str) -> dict[str, Any]:
    """记录启动阶段耗时，写入 data/boot.log（诊断启动慢的问题）。"""
    elapsed = time.perf_counter() - _BOOT_ORIGIN
    line = "%s %.3f %s\n" % (time.strftime("%H:%M:%S"), elapsed, label)
    try:
        path = DATA_ROOT / "data" / "boot.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(line)
    except OSError:
        pass
    return {"ok": True, "label": str(label), "elapsed": round(elapsed, 3)}


def work_area_size() -> tuple[int, int]:
    """可用桌面尺寸（逻辑像素），平台差异交给 platform_layer。"""
    return platform_layer.work_area_size()


def run_warmup() -> None:
    """在安装阶段预热 WebView2 配置目录，避免用户首次启动等待 20 秒。"""
    api = DesktopApi()
    window = webview.create_window(
        "森",
        url=resource_path("static", "index.html").as_uri(),
        js_api=api,
        width=900,
        height=600,
        hidden=True,
        background_color="#070907",
    )
    api._window = window

    def waiter() -> None:
        deadline = time.time() + 25
        loaded = False
        try:
            events = getattr(window, "events", None)
            loaded_event = getattr(events, "loaded", None) if events is not None else None
            if loaded_event is not None and hasattr(loaded_event, "wait"):
                loaded = bool(loaded_event.wait(15))
        except Exception:
            loaded = False
        if loaded:
            time.sleep(2.5)
        else:
            while time.time() < deadline and not loaded:
                time.sleep(0.5)
                loaded = True
            time.sleep(6)
        try:
            window.destroy()
        except Exception:
            pass

    webview.start(
        waiter,
        debug=False,
        private_mode=False,
        **webview_storage_kwargs(),
    )


def main() -> None:
    if "--warmup" in sys.argv:
        run_warmup()
        return
    if not INDEX_PATH.exists():
        build_index(KNOWLEDGE_DIR, INDEX_PATH)

    boot_mark("process-start")
    boot_mark(f"resources {resource_path('static')}")
    api = DesktopApi()
    check_api_surface(api)
    work_w, work_h = work_area_size()
    window = webview.create_window(
        "森",
        url=resource_path("static", "index.html").as_uri(),
        js_api=api,
        width=max(1180, int(work_w * 0.9)),
        height=max(760, int(work_h * 0.82)),
        min_size=(880, 600),
        background_color="#070907",
    )
    boot_mark("window-created")
    webview.start(
        configure_window,
        (window, api),
        debug=False,
        private_mode=False,
        **webview_storage_kwargs(),
    )


def run() -> None:
    try:
        main()
    except Exception:
        if getattr(sys, "frozen", False):
            log_root = Path(
                os.getenv("LOCALAPPDATA", str(Path.home()))
            ) / "Sen"
        else:
            log_root = Path(__file__).resolve().parent
        log_root.mkdir(parents=True, exist_ok=True)
        log_path = log_root / "desktop-error.log"
        log_path.write_text(traceback.format_exc(), encoding="utf-8")

        message = f"Desktop app failed to start.\n\nLog file:\n{log_path}"
        if sys.platform == "win32":
            import ctypes

            ctypes.windll.user32.MessageBoxW(  # type: ignore[attr-defined]
                None, message, "Local Knowledge Assistant", 0x10
            )
        elif sys.platform == "darwin":
            try:
                subprocess.run(
                    [
                        "osascript",
                        "-e",
                        f'display dialog "{message}" with title "森" buttons {{"好"}} default button 1 with icon stop',
                    ],
                    timeout=20,
                )
            except Exception:  # noqa: BLE001
                pass
        raise


if __name__ == "__main__":
    run()
