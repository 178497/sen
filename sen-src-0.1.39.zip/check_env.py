"""Check the local QLoRA training environment."""

from __future__ import annotations

import importlib
import sys


def main() -> None:
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or newer is required")

    import torch

    print(f"Python: {sys.version.split()[0]}")
    print(f"PyTorch: {torch.__version__}")
    print(f"PyTorch CUDA build: {torch.version.cuda}")
    print(f"CUDA available: {torch.cuda.is_available()}")

    if not torch.cuda.is_available():
        raise SystemExit(
            "CUDA is unavailable. Install the CUDA PyTorch wheel from "
            "https://download.pytorch.org/whl/cu128"
        )

    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GiB")

    for package in (
        "transformers",
        "peft",
        "datasets",
        "accelerate",
        "bitsandbytes",
    ):
        module = importlib.import_module(package)
        version = getattr(module, "__version__", "unknown")
        print(f"{package}: {version}")

    print("Environment check passed.")


if __name__ == "__main__":
    main()
