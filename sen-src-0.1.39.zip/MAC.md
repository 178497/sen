# macOS 版：构建与发布

> **明早三步走**
> 1. 打开 https://github.com/178497/sen-build ，下载 `sen-src.zip`
> 2. `unzip sen-src.zip -d sen && cd sen && chmod +x *.command release/*.sh`
> 3. `./doctor-mac.command` 自检 → `./build-mac.command` 构建
>
> 构建失败就跑 `./run-from-source.command` 看完整报错；
> 要发诊断就 `./collect-mac-logs.command`，把桌面上的 zip 发回来。


## 零、拿到源码

源码包放在私有仓库（不公开）：

    https://github.com/178497/sen-build

用你自己的 GitHub 账号打开，下载 `sen-src.zip`（约 440 KB），解压得到 `sen/` 文件夹。

## 一、在 Mac 上构建（3–5 分钟）

1. 把解压出来的 `sen/` 文件夹放到桌面（放哪都行）。
2. **先跑一次自检**（可选但推荐）：
   ```bash
   chmod +x doctor-mac.command
   ./doctor-mac.command
   ```
   它会检查 python3、Command Line Tools、磁盘、PyPI 连通性、Ollama 是否装好。
3. 双击 `build-mac.command`。
   - 如果提示「无法打开，因为来自身份不明的开发者」：右键 → 打开。
   - 或在终端里执行：
     ```bash
     chmod +x build-mac.command release/build_mac.sh
     ./build-mac.command
     ```
4. 结束时会自动打开 `release/` 文件夹，里面有 `Sen-macOS-<版本>.zip`。

构建过程会自动完成：

- 创建 `.venv-mac` 并安装依赖（pywebview / pyobjc / pyinstaller）
- 用 `sips` + `iconutil` 把 PNG 转成 `.icns`
- PyInstaller 打包成 `dist/Sen.app`
- ad-hoc 签名（`codesign --sign -`，不需要 Apple 开发者账号）
- 打包成可分发的 zip

## 一之二、想以后自动构建（可选，30 秒）

`sen-src.zip` 里有 `.github/workflows/build-mac.yml`。把它放进仓库就能让 GitHub 在
推 tag 时自动打 mac 包：

1. 浏览器打开 `https://github.com/178497/sen`
2. `Add file` → `Upload files`
3. 把 `.github/workflows/build-mac.yml` 拖进去（注意保持目录层级），提交
4. 之后推 `v*` tag，或在该仓库 Actions 页面手动 Run workflow

> 为什么不能自动放上去：当前 token 没有 `workflow` 权限，GitHub 会拒绝通过 API 写入
> `.github/workflows/`。浏览器上传不受这个限制。

## 一之三、出问题时怎么排查

如果打包失败或应用打不开，按这个顺序来：

### 先跑源码模式（能看到完整报错）

```bash
chmod +x run-from-source.command
./run-from-source.command
```

它会复用 `.venv-mac` 依赖、前台运行 `python desktop.py`，退出时自动打印
`~/Library/Application Support/Sen/desktop-error.log` 的最后 20 行。

源码模式能起来、打包版起不来 → 是打包问题（datas / 布局）。
源码模式也起不来 → 是代码或环境问题，报错会直接指到行号。

### 把诊断信息发回来

```bash
chmod +x collect-mac-logs.command
./collect-mac-logs.command
```

会在桌面生成 `sen-diagnostics-*.zip`，包含：

- 系统版本、架构、python 版本、Ollama 路径
- `Sen.app` 的签名信息和 `Contents` 目录结构
- `boot.log`、`desktop-error.log`、`training.log`、`runtime-install.log`
- `provider_config.json`（**API key 已替换为 `<redacted>`**）

## 二、装到 Mac 上

1. 解压 `Sen-macOS-<版本>.zip`，把 `Sen.app` 拖进「应用程序」。
2. **第一次打开**：在「应用程序」里右键点 `Sen.app` → 打开 → 再点「打开」。

   或者执行一次：

   ```bash
   xattr -dr com.apple.quarantine /Applications/Sen.app
   ```

   之后就能正常双击了。

## 三、Mac 上的功能差异

| 功能 | 状态 |
|---|---|
| 对话、知识库、看图 | 与 Windows 一致 |
| 朗读（edge-tts） | 一致 |
| 主题、音乐、音效 | 一致 |
| 生图 | 支持（MPS），比 NVIDIA 慢，首次要装运行时（约 2.5 GB） |
| 训练 | 支持，走 **fp16 LoRA + MPS**（不用 4-bit，因为 bitsandbytes 不支持 MPS） |
| 自动更新 | 检测到新版本后下载 zip，手动替换 .app |
| 数据位置 | `~/Library/Application Support/Sen` |

## 四、训练在 Mac 上的差异

Windows 用 `train.ps1` + 4-bit QLoRA（需要 CUDA）。
Mac 用 `train.sh` + fp16 LoRA（MPS）：

```bash
CHAT_VENV_TRAIN="$HOME/Library/Application Support/Sen/runtime/venv-train" \
  ./train.sh -Data data/train.jsonl -Epochs 2
```

首次训练前需要装训练环境：

```bash
./setup_train.sh
```

预期速度：8.5 秒/步（RTX 级）→ 约 30–45 秒/步（M1/M2）。500 条样本 2 轮大约 30–60 分钟。

## 五、把构建产物发布到下载页

构建完成后，把 `release/Sen-macOS-<版本>.zip` 传给我（或自己上传到 GitHub Release），
然后更新 `latest.json` 增加三个字段：

```json
{
  "macos_url": "https://github.com/178497/sen/releases/download/v0.1.27/Sen-macOS-0.1.27.zip",
  "macos_size_mb": 62.5,
  "macos_sha256": "..."
}
```

下载页会自动把「macOS 版」按钮从「内测」切换成带体积的正常下载链接，不用改页面代码。

## 六、后续可做（未实现）

- **自动构建**：把源码放进一个私有仓库 + 加 GitHub Actions（需要 token 有 `workflow` 权限），
  推 tag 就自动出 mac 包。当前 token 没有这个权限，所以暂时走本机构建。
- **公证**：有 Apple 开发者账号（$99/年）后，可以 `notarytool` 公证，用户双击即装。
