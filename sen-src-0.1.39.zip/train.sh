#!/bin/bash
# macOS / Linux 版训练入口（对应 Windows 的 train.ps1）
#
# 用法与 train.ps1 保持一致：
#   ./train.sh -Data data/train.jsonl -Epochs 2 -PauseFile ... -SaveSteps 50 -Throttle 80

set -euo pipefail
cd "$(dirname "$0")"

DATA="data/train.jsonl"
EPOCHS="2"
RESUME_FROM=""
PAUSE_FILE=""
SAVE_STEPS="50"
THROTTLE="100"
THROTTLE_FILE=""
OUTPUT="outputs/lora-adapter"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -Data) DATA="$2"; shift 2 ;;
    -Epochs) EPOCHS="$2"; shift 2 ;;
    -ResumeFrom) RESUME_FROM="$2"; shift 2 ;;
    -PauseFile) PAUSE_FILE="$2"; shift 2 ;;
    -SaveSteps) SAVE_STEPS="$2"; shift 2 ;;
    -Throttle) THROTTLE="$2"; shift 2 ;;
    -ThrottleFile) THROTTLE_FILE="$2"; shift 2 ;;
    -Output) OUTPUT="$2"; shift 2 ;;
    -Smoke) SMOKE=1; shift ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

# 打包版把训练环境放在 ~/Library/Application Support/Sen/runtime/venv-train
if [[ -n "${CHAT_VENV_TRAIN:-}" ]]; then
  VENV_ROOT="$CHAT_VENV_TRAIN"
else
  VENV_ROOT="$(pwd)/.venv-train"
fi

PYTHON="$VENV_ROOT/bin/python"
if [[ ! -x "$PYTHON" ]]; then
  echo "Training environment is missing: $VENV_ROOT" >&2
  exit 1
fi
if [[ ! -f "$DATA" ]]; then
  echo "Training data is missing: $DATA" >&2
  exit 1
fi

ARGS=(--data "$DATA" --output "$OUTPUT" --max-length 1024 --gradient-accumulation 8 --no-4bit --device mps)

if [[ "${SMOKE:-0}" == "1" ]]; then
  ARGS+=(--max-steps 10)
else
  ARGS+=(--epochs "$EPOCHS")
  [[ -n "$RESUME_FROM" ]] && ARGS+=(--resume-from "$RESUME_FROM")
  [[ -n "$PAUSE_FILE" ]] && ARGS+=(--pause-file "$PAUSE_FILE")
  [[ "$SAVE_STEPS" -gt 0 ]] && ARGS+=(--save-steps "$SAVE_STEPS")
  [[ "$THROTTLE" -gt 0 ]] && ARGS+=(--throttle "$THROTTLE")
  [[ -n "$THROTTLE_FILE" ]] && ARGS+=(--throttle-file "$THROTTLE_FILE")
fi

exec "$PYTHON" train_qlora.py "${ARGS[@]}"
