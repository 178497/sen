"""Tiny self-update client for the packaged 森 build."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
import tempfile
import urllib.request
from pathlib import Path

import platform_layer
from typing import Any, Callable

BUILTIN_UPDATE_URL = "https://cdn.jsdelivr.net/gh/178497/sen@main/latest.json"

# 备用源：jsDelivr 偶尔会连不上，GitHub 自身通常可达
FALLBACK_UPDATE_URLS = [
    "https://178497.github.io/sen/manifest/latest.json",
    "https://178497.github.io/sen/latest.json",
    "https://raw.githubusercontent.com/178497/sen/main/latest.json",
    "https://github.com/178497/sen/releases/download/manifest/latest.json",
]


def _read_url_file() -> list[str]:
    candidates = []
    if platform_layer.IS_MAC:
        candidates.append(Path.home() / "Library" / "Application Support" / "Sen" / "update_url.txt")
    local = os.getenv("LOCALAPPDATA")
    if local:
        candidates.append(Path(local) / "Sen" / "update_url.txt")
    if getattr(sys, "frozen", False):
        candidates.append(Path(sys.executable).parent / "update_url.txt")
    candidates.append(Path(__file__).resolve().parent / "update_url.txt")
    for candidate in candidates:
        try:
            if candidate.is_file():
                text = candidate.read_text(encoding="utf-8")
                urls = [line.strip() for line in text.splitlines() if line.strip().startswith("http")]
                if urls:
                    return urls
        except OSError:
            continue
    return []


def resolve_update_urls() -> list[str]:
    env = os.getenv("SEN_UPDATE_URL", "").strip()
    if env.startswith("http"):
        return [env]
    file_urls = _read_url_file()
    ordered = list(file_urls) if file_urls else [BUILTIN_UPDATE_URL]
    for extra in FALLBACK_UPDATE_URLS:
        if extra not in ordered:
            ordered.append(extra)
    return ordered


DEFAULT_UPDATE_URL = resolve_update_urls()[0]


def parse_version(text: str) -> tuple[int, ...]:
    parts: list[int] = []
    for chunk in str(text).strip().lstrip("v").split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) or (0,)


def is_newer(candidate: str, current: str) -> bool:
    return parse_version(candidate) > parse_version(current)


def fetch_manifest(url: str = DEFAULT_UPDATE_URL, timeout: float = 8.0) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": "Sen-Updater"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("更新清单格式不正确")
    return payload


def check_for_update(current: str, url: str | None = None) -> dict[str, Any]:
    urls = [url] if url else resolve_update_urls()
    manifest: dict[str, Any] | None = None
    last_error = ""
    for candidate in urls:
        try:
            fetched = fetch_manifest(candidate)
        except Exception as error:  # noqa: BLE001
            last_error = str(error)
            continue
        # 有的源会缓存旧清单，这里取版本号最大的那个
        if manifest is None or parse_version(str(fetched.get("version") or "0")) > parse_version(
            str(manifest.get("version") or "0")
        ):
            manifest = fetched
    if manifest is None:
        return {"ok": False, "available": False, "error": last_error or "无法连接更新服务器"}
    latest = str(manifest.get("version") or "")
    if not latest:
        return {"ok": False, "available": False, "error": "清单缺少 version 字段"}
    return {
        "ok": True,
        "available": is_newer(latest, current),
        "version": latest,
        "current": current,
        "notes": str(manifest.get("notes") or ""),
        "url": str(manifest.get("url") or ""),
        "sha256": str(manifest.get("sha256") or "").lower(),
        "size_mb": manifest.get("size_mb") or 0,
    }


def download_installer(
    url: str | list[tuple[str, str]],
    sha256: str = "",
    progress: Callable[[int], None] | None = None,
) -> Path:
    if isinstance(url, list):
        candidates = [(u, h) for u, h in url if u]
    else:
        candidates = [(url, sha256)]
    if not candidates:
        raise ValueError("更新清单没有提供下载地址")
    errors: list[str] = []
    for candidate_url, candidate_hash in candidates:
        for attempt in range(3):
            try:
                return _download_one(candidate_url, candidate_hash, progress)
            except Exception as error:  # noqa: BLE001
                if attempt == 2:
                    errors.append(f"{candidate_url}: {error}")
                else:
                    time.sleep(1.5 * (attempt + 1))
    raise ValueError("所有下载地址都失败：" + " | ".join(errors))


def _download_one(
    url: str,
    sha256: str,
    progress: Callable[[int], None] | None,
) -> Path:
    target_dir = Path(tempfile.gettempdir()) / "sen-update"
    target_dir.mkdir(parents=True, exist_ok=True)
    default_name = "Sen-Setup.exe" if platform_layer.IS_WINDOWS else "Sen-macOS.zip"
    target = target_dir / (Path(url.split("?")[0]).name or default_name)
    digest = hashlib.sha256()
    with urllib.request.urlopen(url, timeout=60) as response, target.open("wb") as handle:
        total = int(response.headers.get("Content-Length") or 0)
        received = 0
        while True:
            chunk = response.read(262144)
            if not chunk:
                break
            handle.write(chunk)
            digest.update(chunk)
            received += len(chunk)
            if progress and total:
                progress(min(99, int(received * 100 / total)))
    if sha256 and digest.hexdigest().lower() != sha256:
        target.unlink(missing_ok=True)
        raise ValueError("下载文件的校验值与清单不一致，已删除")
    if progress:
        progress(100)
    if target.suffix.lower() == ".zip":
        import zipfile

        with zipfile.ZipFile(target) as archive:
            # macOS 的包是 Sen.app 目录，整体解压
            if any(".app/" in name for name in archive.namelist()):
                archive.extractall(target.parent / "Sen-mac")
                return target.parent / "Sen-mac"
            for name in archive.namelist():
                if name.lower().endswith(".exe"):
                    extracted = target.parent / Path(name).name
                    extracted.write_bytes(archive.read(name))
                    return extracted
        raise ValueError("压缩包里没有找到安装程序")
    return target
